exports.ids = [3];
exports.modules = {

/***/ "./src/components/pages/home.tsx":
/*!***************************************!*\
  !*** ./src/components/pages/home.tsx ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../languages */ "./src/languages/index.ts");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\home.tsx";



 // import {
//     DesktopOutlined,
//     PieChartOutlined,
//     FileOutlined,
//     TeamOutlined,
//     SampleNextArrow,
//   } from "@ant-design/icons";

 // import { SET_LANGUAGE } from "../../languages";

function Home({}) {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_4__["Context"]);
  const {
    0: isLoad,
    1: setisLoad
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  const {
    0: lang,
    1: setlang
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])();
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_5__["Language"])(state.language));
    setisLoad(true);
  }, [state.language]);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {}, [lang]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: isLoad && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Contents, {
      theme: state.theme,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Carousel"], {
        autoplay: true,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              // maxWidth: 800,
              // minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              minWidth: 800,
              minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              minWidth: 800,
              minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: lang.RecommendedProducts
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Carousel"], {
        autoplay: true,
        children: [1, 2, 3, 4, 5, 6].map((item, index) => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 100,
                  columnNumber: 23
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 23
                }, this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 106,
                  columnNumber: 23
                }, this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 105,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 109,
                  columnNumber: 23
                }, this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 112,
                  columnNumber: 23
                }, this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 115,
                  columnNumber: 23
                }, this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 21
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 19
            }, this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 97,
            columnNumber: 17
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E22\u0E2D\u0E14\u0E19\u0E34\u0E22\u0E21"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 122,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        gutter: [8, 8],
        style: {
          padding: 16
        },
        children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((item, index) => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
            span: 4,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title={'product'+item}
            , {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                src: "./images/product1.png"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 145,
                columnNumber: 21
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  width: "100%",
                  padding: 5
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Buys, {
                  theme: state.theme,
                  children: "2500.00"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 147,
                  columnNumber: 23
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Rate"], {
                  allowHalf: true,
                  defaultValue: 3,
                  style: {
                    color: state.theme.primary
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 148,
                  columnNumber: 23
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 146,
                columnNumber: 21
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 19
            }, this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 141,
            columnNumber: 17
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 138,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        style: {
          justifyContent: "center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Paginations, {
          theme: state.theme,
          defaultCurrent: 10,
          total: 50
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E42\u0E1B\u0E23\u0E42\u0E21\u0E0A\u0E31\u0E48\u0E19"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        gutter: [16, 16],
        style: {
          padding: 16
        },
        children: [1, 2, 3, 4].map((item, index) => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
            span: 24,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title="Default size card"
            // extra={<a href="#">More{item}</a>}
            , {
              style: {
                padding: 5,
                width: "100%"
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(ColImages, {
                  span: 12,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
                    src: "./images/product1.png",
                    style: {
                      width: "100%"
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 25
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 23
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
                  span: 12,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 25
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E23\u0E32\u0E04\u0E32"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 181,
                    columnNumber: 25
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 182,
                    columnNumber: 25
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 179,
                  columnNumber: 23
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 172,
                columnNumber: 21
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 167,
              columnNumber: 19
            }, this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 166,
            columnNumber: 17
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 163,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 9
    }, this)
  }, void 0, false);
}
const ColImages = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Col"]).withConfig({
  displayName: "home__ColImages",
  componentId: "sc-1mqvku9-0"
})(["display:flex;justify-content:center;align-items:center;.ant-image{width:50%;}"]);
const Contents = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "home__Contents",
  componentId: "sc-1mqvku9-1"
})(["height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}"], ({
  theme
}) => theme.primary);
const Carousels = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Carousel"]).withConfig({
  displayName: "home__Carousels",
  componentId: "sc-1mqvku9-2"
})(["box-shadow:0px 0px 3px #546e7a;"]);
const Cards = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Card"]).withConfig({
  displayName: "home__Cards",
  componentId: "sc-1mqvku9-3"
})([".ant-card-body{padding:5px;}box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"]);
const Buys = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "home__Buys",
  componentId: "sc-1mqvku9-4"
})(["position:absolute;top:0px;right:0;background-color:", ";color:#fff;padding:5px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;"], ({
  theme
}) => theme.primary);
const TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "home__TextHeader",
  componentId: "sc-1mqvku9-5"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], ({
  theme
}) => theme.primary);
const Paginations = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Pagination"]).withConfig({
  displayName: "home__Paginations",
  componentId: "sc-1mqvku9-6"
})([".ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-pagination-item-active a{color:#fff !important;}"], ({
  theme
}) => theme.primary);

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wYWdlcy9ob21lLnRzeCJdLCJuYW1lcyI6WyJIb21lIiwic3RhdGUiLCJkaXNwYXRjaCIsInVzZUNvbnRleHQiLCJDb250ZXh0IiwiaXNMb2FkIiwic2V0aXNMb2FkIiwidXNlU3RhdGUiLCJsYW5nIiwic2V0bGFuZyIsInVzZUVmZmVjdCIsIkxhbmd1YWdlIiwibGFuZ3VhZ2UiLCJ0aGVtZSIsIndpZHRoIiwiaGVpZ2h0Iiwib2JqZWN0Rml0IiwibWFyZ2luIiwibWluV2lkdGgiLCJtaW5IZWlnaHQiLCJSZWNvbW1lbmRlZFByb2R1Y3RzIiwibWFwIiwiaXRlbSIsImluZGV4IiwicGFkZGluZyIsImNvbG9yIiwicHJpbWFyeSIsImp1c3RpZnlDb250ZW50IiwiQ29sSW1hZ2VzIiwic3R5bGVkIiwiQ29sIiwiQ29udGVudHMiLCJkaXYiLCJDYXJvdXNlbHMiLCJDYXJvdXNlbCIsIkNhcmRzIiwiQ2FyZCIsIkJ1eXMiLCJUZXh0SGVhZGVyIiwiUGFnaW5hdGlvbnMiLCJQYWdpbmF0aW9uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztDQUdBOztBQUllLFNBQVNBLElBQVQsQ0FBYyxFQUFkLEVBQXVDO0FBQ3BELFFBQU07QUFBRUMsU0FBRjtBQUFTQztBQUFULE1BQXNCQyx3REFBVSxDQUFDQyxnREFBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDQyxNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQkMsc0RBQVEsQ0FBQyxLQUFELENBQXBDO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCRixzREFBUSxFQUFoQztBQUVBRyx5REFBUyxDQUFDLE1BQU07QUFDZEQsV0FBTyxDQUFDRSwyREFBUSxDQUFDVixLQUFLLENBQUNXLFFBQVAsQ0FBVCxDQUFQO0FBQ0FOLGFBQVMsQ0FBQyxJQUFELENBQVQ7QUFDRCxHQUhRLEVBR04sQ0FBQ0wsS0FBSyxDQUFDVyxRQUFQLENBSE0sQ0FBVDtBQUlBRix5REFBUyxDQUFDLE1BQU0sQ0FBRSxDQUFULEVBQVcsQ0FBQ0YsSUFBRCxDQUFYLENBQVQ7QUFDQSxzQkFDRTtBQUFBLGNBQ0dILE1BQU0saUJBQ0wscUVBQUMsUUFBRDtBQUFVLFdBQUssRUFBRUosS0FBSyxDQUFDWSxLQUF2QjtBQUFBLDhCQUNFLHFFQUFDLDZDQUFEO0FBQVUsZ0JBQVEsTUFBbEI7QUFBQSxnQ0FDRSxxRUFBQyx3Q0FBRDtBQUFBLGlDQUNFLHFFQUFDLDBDQUFEO0FBQ0UsbUJBQU8sRUFBRSxLQURYO0FBRUUsZUFBRyxFQUFDLHdCQUZOO0FBR0UsaUJBQUssRUFBRTtBQUNMO0FBQ0E7QUFDQUMsbUJBQUssRUFBRSxNQUhGO0FBSUxDLG9CQUFNLEVBQUUsTUFKSDtBQUtMQyx1QkFBUyxFQUFFLE9BTE47QUFNTEMsb0JBQU0sRUFBRTtBQU5IO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFlRSxxRUFBQyx3Q0FBRDtBQUFBLGlDQUNFLHFFQUFDLDBDQUFEO0FBQ0UsbUJBQU8sRUFBRSxLQURYO0FBRUUsZUFBRyxFQUFDLHdCQUZOO0FBR0UsaUJBQUssRUFBRTtBQUNMQyxzQkFBUSxFQUFFLEdBREw7QUFFTEMsdUJBQVMsRUFBRSxHQUZOO0FBR0xMLG1CQUFLLEVBQUUsTUFIRjtBQUlMQyxvQkFBTSxFQUFFLE1BSkg7QUFLTEMsdUJBQVMsRUFBRSxPQUxOO0FBTUxDLG9CQUFNLEVBQUU7QUFOSDtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWZGLGVBNkJFLHFFQUFDLHdDQUFEO0FBQUEsaUNBQ0UscUVBQUMsMENBQUQ7QUFDRSxtQkFBTyxFQUFFLEtBRFg7QUFFRSxlQUFHLEVBQUMsd0JBRk47QUFHRSxpQkFBSyxFQUFFO0FBQ0xDLHNCQUFRLEVBQUUsR0FETDtBQUVMQyx1QkFBUyxFQUFFLEdBRk47QUFHTEwsbUJBQUssRUFBRSxNQUhGO0FBSUxDLG9CQUFNLEVBQUUsTUFKSDtBQUtMQyx1QkFBUyxFQUFFLE9BTE47QUFNTEMsb0JBQU0sRUFBRTtBQU5IO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBNkNFLHFFQUFDLFVBQUQ7QUFBWSxhQUFLLEVBQUVoQixLQUFLLENBQUNZLEtBQXpCO0FBQUEsa0JBQ0dMLElBQUksQ0FBQ1k7QUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBN0NGLGVBK0RFLHFFQUFDLDZDQUFEO0FBQVUsZ0JBQVEsTUFBbEI7QUFBQSxrQkFDRyxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCLENBQWhCLEVBQW1CQyxHQUFuQixDQUF1QixDQUFDQyxJQUFELEVBQU9DLEtBQVAsS0FBaUI7QUFDdkMsOEJBQ0U7QUFBQSxtQ0FDRSxxRUFBQyx3Q0FBRDtBQUFBLHNDQUNFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsdUNBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUFJRSxxRUFBQyx3Q0FBRDtBQUFLLG9CQUFJLEVBQUUsQ0FBWDtBQUFBLHdDQUNFLHFFQUFDLDBDQUFEO0FBQU8scUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsRUFDd0MsR0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUpGLGVBT0UscUVBQUMsd0NBQUQ7QUFBSyxvQkFBSSxFQUFFLENBQVg7QUFBQSx3Q0FDRSxxRUFBQywwQ0FBRDtBQUFPLHFCQUFHLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLEVBQ3dDLEdBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFQRixlQVVFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsd0NBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixFQUN3QyxHQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBVkYsZUFhRSxxRUFBQyx3Q0FBRDtBQUFLLG9CQUFJLEVBQUUsQ0FBWDtBQUFBLHdDQUNFLHFFQUFDLDBDQUFEO0FBQU8scUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsRUFDd0MsR0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWJGLGVBZ0JFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsd0NBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFERixFQUN3QyxHQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGFBQVVBLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQXdCRCxTQXpCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EvREYsZUEyRkUscUVBQUMsVUFBRDtBQUFZLGFBQUssRUFBRXRCLEtBQUssQ0FBQ1ksS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EzRkYsZUEyR0UscUVBQUMsd0NBQUQ7QUFBSyxjQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFiO0FBQXFCLGFBQUssRUFBRTtBQUFFVyxpQkFBTyxFQUFFO0FBQVgsU0FBNUI7QUFBQSxrQkFDRyxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLEVBQTRCLEVBQTVCLEVBQWdDLEVBQWhDLEVBQW9DLEVBQXBDLEVBQXdDSCxHQUF4QyxDQUE0QyxDQUFDQyxJQUFELEVBQU9DLEtBQVAsS0FBaUI7QUFDNUQsOEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxnQkFBSSxFQUFFLENBQVg7QUFBQSxtQ0FDRSxxRUFBQyxLQUFELENBQ0E7QUFEQTtBQUFBLHNDQUdFLHFFQUFDLDBDQUFEO0FBQU8sbUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSEYsZUFJRTtBQUFLLHFCQUFLLEVBQUU7QUFBRVQsdUJBQUssRUFBRSxNQUFUO0FBQWlCVSx5QkFBTyxFQUFFO0FBQTFCLGlCQUFaO0FBQUEsd0NBQ0UscUVBQUMsSUFBRDtBQUFNLHVCQUFLLEVBQUV2QixLQUFLLENBQUNZLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBRUUscUVBQUMseUNBQUQ7QUFDRSwyQkFBUyxNQURYO0FBRUUsOEJBQVksRUFBRSxDQUZoQjtBQUdFLHVCQUFLLEVBQUU7QUFBRVkseUJBQUssRUFBRXhCLEtBQUssQ0FBQ1ksS0FBTixDQUFZYTtBQUFyQjtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGFBQW1CSCxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGO0FBaUJELFNBbEJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTNHRixlQWdJRSxxRUFBQyx3Q0FBRDtBQUFLLGFBQUssRUFBRTtBQUFFSSx3QkFBYyxFQUFFO0FBQWxCLFNBQVo7QUFBQSwrQkFDRSxxRUFBQyxXQUFEO0FBQWEsZUFBSyxFQUFFMUIsS0FBSyxDQUFDWSxLQUExQjtBQUFpQyx3QkFBYyxFQUFFLEVBQWpEO0FBQXFELGVBQUssRUFBRTtBQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWhJRixlQW1JRSxxRUFBQyxVQUFEO0FBQVksYUFBSyxFQUFFWixLQUFLLENBQUNZLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbklGLGVBb0lFLHFFQUFDLHdDQUFEO0FBQUssY0FBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixhQUFLLEVBQUU7QUFBRVcsaUJBQU8sRUFBRTtBQUFYLFNBQTlCO0FBQUEsa0JBQ0csQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLEVBQWFILEdBQWIsQ0FBaUIsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ2pDLDhCQUNFLHFFQUFDLHdDQUFEO0FBQUssZ0JBQUksRUFBRSxFQUFYO0FBQUEsbUNBQ0UscUVBQUMsS0FBRCxDQUNFO0FBQ0E7QUFGRjtBQUdFLG1CQUFLLEVBQUU7QUFBRUMsdUJBQU8sRUFBRSxDQUFYO0FBQWNWLHFCQUFLLEVBQUU7QUFBckIsZUFIVDtBQUFBLHFDQUtFLHFFQUFDLHdDQUFEO0FBQUEsd0NBQ0UscUVBQUMsU0FBRDtBQUFXLHNCQUFJLEVBQUUsRUFBakI7QUFBQSx5Q0FDRSxxRUFBQywwQ0FBRDtBQUNFLHVCQUFHLEVBQUMsdUJBRE47QUFFRSx5QkFBSyxFQUFFO0FBQUVBLDJCQUFLLEVBQUU7QUFBVDtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBT0UscUVBQUMsd0NBQUQ7QUFBSyxzQkFBSSxFQUFFLEVBQVg7QUFBQSwwQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixhQUFvQlMsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQXVCRCxTQXhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkosbUJBREY7QUFzS0Q7QUFDRCxNQUFNSyxTQUFTLEdBQUdDLHdEQUFNLENBQUNDLHdDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEscUZBQWY7QUFRQSxNQUFNQyxRQUFRLEdBQUdGLHdEQUFNLENBQUNHLEdBQVY7QUFBQTtBQUFBO0FBQUEsNFRBaUJVLENBQUM7QUFBRW5CO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNhLE9BakIvQixDQUFkO0FBcUJBLE1BQU1PLFNBQVMsR0FBR0osd0RBQU0sQ0FBQ0ssNkNBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSx1Q0FBZjtBQUlBLE1BQU1DLEtBQUssR0FBR04sd0RBQU0sQ0FBQ08seUNBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxzT0FBWDtBQVFBLE1BQU1DLElBQUksR0FBR1Isd0RBQU0sQ0FBQ0csR0FBVjtBQUFBO0FBQUE7QUFBQSxxTUFJWSxDQUFDO0FBQUVuQjtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDYSxPQUpqQyxDQUFWO0FBV0EsTUFBTVksVUFBVSxHQUFHVCx3REFBTSxDQUFDRyxHQUFWO0FBQUE7QUFBQTtBQUFBLG9ZQUlMLENBQUM7QUFBRW5CO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNhLE9BSmhCLENBQWhCO0FBZ0JBLE1BQU1hLFdBQVcsR0FBR1Ysd0RBQU0sQ0FBQ1csK0NBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSwwZkFFTyxDQUFDO0FBQUUzQjtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDYSxPQUY1QixDQUFqQixDIiwiZmlsZSI6IjMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXJkLCBDYXJvdXNlbCwgQ29sLCBJbWFnZSwgUGFnaW5hdGlvbiwgUmF0ZSwgUm93IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuLy8gaW1wb3J0IHtcclxuLy8gICAgIERlc2t0b3BPdXRsaW5lZCxcclxuLy8gICAgIFBpZUNoYXJ0T3V0bGluZWQsXHJcbi8vICAgICBGaWxlT3V0bGluZWQsXHJcbi8vICAgICBUZWFtT3V0bGluZWQsXHJcbi8vICAgICBTYW1wbGVOZXh0QXJyb3csXHJcbi8vICAgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IFNhbXBsZU5leHRBcnJvdyBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9TaW1wbGVJY29uc1wiO1xyXG5pbXBvcnQgeyBMYW5ndWFnZSB9IGZyb20gXCIuLi8uLi9sYW5ndWFnZXNcIjtcclxuLy8gaW1wb3J0IHsgU0VUX0xBTkdVQUdFIH0gZnJvbSBcIi4uLy4uL2xhbmd1YWdlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3QgW2lzTG9hZCwgc2V0aXNMb2FkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRsYW5nKExhbmd1YWdlKHN0YXRlLmxhbmd1YWdlKSk7XHJcbiAgICBzZXRpc0xvYWQodHJ1ZSk7XHJcbiAgfSwgW3N0YXRlLmxhbmd1YWdlXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHt9LCBbbGFuZ10pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7aXNMb2FkICYmIChcclxuICAgICAgICA8Q29udGVudHMgdGhlbWU9e3N0YXRlLnRoZW1lfT5cclxuICAgICAgICAgIDxDYXJvdXNlbCBhdXRvcGxheT5cclxuICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgc3JjPVwiLi9pbWFnZXMvY2Fyb3VzZWwzLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAvLyBtYXhXaWR0aDogODAwLFxyXG4gICAgICAgICAgICAgICAgICAvLyBtaW5IZWlnaHQ6IDMwMCxcclxuICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICAgICAgICBvYmplY3RGaXQ6IFwiY292ZXJcIixcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+PC9JbWFnZT5cclxuICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICBwcmV2aWV3PXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHNyYz1cIi4vaW1hZ2VzL2Nhcm91c2VsMy5wbmdcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgbWluV2lkdGg6IDgwMCxcclxuICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0OiAzMDAsXHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcImF1dG9cIixcclxuICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0OiBcImNvdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgcHJldmlldz17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBzcmM9XCIuL2ltYWdlcy9jYXJvdXNlbDMucG5nXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIG1pbldpZHRoOiA4MDAsXHJcbiAgICAgICAgICAgICAgICAgIG1pbkhlaWdodDogMzAwLFxyXG4gICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogXCJhdXRvXCIsXHJcbiAgICAgICAgICAgICAgICAgIG9iamVjdEZpdDogXCJjb3ZlclwiLFxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW46IDAsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID48L0ltYWdlPlxyXG4gICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgIDwvQ2Fyb3VzZWw+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlxyXG4gICAgICAgICAgICB7bGFuZy5SZWNvbW1lbmRlZFByb2R1Y3RzfVxyXG4gICAgICAgICAgPC9UZXh0SGVhZGVyPlxyXG4gICAgICAgICAgey8qIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTAsXHJcbiAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAxNixcclxuICAgICAgICAgICAgZm9udFNpemU6IDIwLFxyXG4gICAgICAgICAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcInNvbGlkIDVweCBcIixcclxuICAgICAgICAgICAgYm9yZGVyQ29sb3I6IHN0YXRlLnRoZW1lLnByaW1hcnksXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIOC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1xyXG4gICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgIDxDYXJvdXNlbCBhdXRvcGxheT5cclxuICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2XS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi4vaW1hZ2VzL3Byb2R1Y3QxLnBuZ1wiIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvQ2Fyb3VzZWw+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PuC4quC4tOC4meC4hOC5ieC4suC4ouC4reC4lOC4meC4tOC4ouC4oTwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIHsvKiA8ZGl2XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDUwLFxyXG4gICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICBwYWRkaW5nTGVmdDogMTYsXHJcbiAgICAgICAgICAgIGZvbnRTaXplOiAyMCxcclxuICAgICAgICAgICAgZm9udFdlaWdodDogXCJib2xkXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckJvdHRvbTogXCJzb2xpZCA1cHggXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBzdGF0ZS50aGVtZS5wcmltYXJ5LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICDguKrguLTguJnguITguYnguLLguKLguK3guJTguJnguLTguKLguKFcclxuICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICA8Um93IGd1dHRlcj17WzgsIDhdfSBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cclxuICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyXS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkc1xyXG4gICAgICAgICAgICAgICAgICAvLyB0aXRsZT17J3Byb2R1Y3QnK2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogNSB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXlzIHRoZW1lPXtzdGF0ZS50aGVtZX0+MjUwMC4wMDwvQnV5cz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93SGFsZlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBzdGF0ZS50aGVtZS5wcmltYXJ5IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmRzPlxyXG4gICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgIDxSb3cgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgIDxQYWdpbmF0aW9ucyB0aGVtZT17c3RhdGUudGhlbWV9IGRlZmF1bHRDdXJyZW50PXsxMH0gdG90YWw9ezUwfSAvPlxyXG4gICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PuC4quC4tOC4meC4hOC5ieC4suC5guC4m+C4o+C5guC4oeC4iuC4seC5iOC4mTwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgcGFkZGluZzogMTYgfX0+XHJcbiAgICAgICAgICAgIHtbMSwgMiwgMywgNF0ubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezI0fSBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGl0bGU9XCJEZWZhdWx0IHNpemUgY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZXh0cmE9ezxhIGhyZWY9XCIjXCI+TW9yZXtpdGVtfTwvYT59XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogNSwgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbEltYWdlcyBzcGFuPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz1cIi4vaW1hZ2VzL3Byb2R1Y3QxLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbEltYWdlcz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD7guIrguLfguYjguK3guKrguLTguJnguITguYnguLI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPuC4o+C4suC4hOC4sjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+4Lij4Liy4Lii4Lil4Liw4LmA4Lit4Li14Lii4LiUPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZHM+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgIDwvQ29udGVudHM+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbmNvbnN0IENvbEltYWdlcyA9IHN0eWxlZChDb2wpYFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAuYW50LWltYWdlIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBDb250ZW50cyA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgfVxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNlY2VjO1xyXG4gIH1cclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IENhcm91c2VscyA9IHN0eWxlZChDYXJvdXNlbClgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCAzcHggIzU0NmU3YTtcclxuYDtcclxuXHJcbmNvbnN0IENhcmRzID0gc3R5bGVkKENhcmQpYFxyXG4gIC5hbnQtY2FyZC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICB9XHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG5jb25zdCBCdXlzID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwcHg7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBjb2xvcjogI2ZmZjtcclxuICBwYWRkaW5nOiA1cHg7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gIGJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG5gO1xyXG5jb25zdCBUZXh0SGVhZGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmctbGVmdDogMTZweDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICBib3gtc2hhZG93OiAwIDIuOHB4IDIuMnB4IHJnYigwIDAgMCAvIDMlKSwgMCA2LjdweCA1LjNweCByZ2IoMCAwIDAgLyA1JSksXHJcbiAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7XHJcbmA7XHJcblxyXG5jb25zdCBQYWdpbmF0aW9ucyA9IHN0eWxlZChQYWdpbmF0aW9uKWBcclxuICAuYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXHJcbiAgLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwNTg1ZTcgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlN2ViZWUgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6Zmlyc3QtY2hpbGQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSBhIHtcclxuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9