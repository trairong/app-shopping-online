exports.ids = [5];
exports.modules = {

/***/ "./src/components/pages/product.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/product.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Product; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\product.tsx";




function Product({}) {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_4__["Context"]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Tabss, {
      defaultActiveKey: "1",
      centered: true,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E01\u0E35\u0E15\u0E49\u0E32\u0E23\u0E4C",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, this)
      }, "1", false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E40\u0E2A\u0E37\u0E49\u0E2D\u0E1C\u0E49\u0E32",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 11
        }, this)
      }, "2", false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E40\u0E21\u0E35\u0E22\u0E19\u0E49\u0E2D\u0E22",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, this)
      }, "3", false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

const TabDetail = () => {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_4__["Context"]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
      gutter: [8, 8],
      style: {
        padding: 16
      },
      children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18].map((item, index) => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
          span: 4,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title={'product'+item}
          , {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Image"], {
              src: "./images/product1.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 19
            }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                width: "100%",
                padding: 5
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Buys, {
                theme: state.theme,
                children: "2500.00"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 21
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Rate"], {
                allowHalf: true,
                defaultValue: 3,
                style: {
                  color: state.theme.primary
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 42,
                columnNumber: 21
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 19
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 36,
            columnNumber: 17
          }, undefined)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 15
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
      style: {
        justifyContent: "center"
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Paginations, {
        theme: state.theme,
        defaultCurrent: 10,
        total: 50
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

const Paginations = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Pagination"]).withConfig({
  displayName: "product__Paginations",
  componentId: "sc-1261jbi-0"
})([".ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-pagination-item-active a{color:#fff !important;}"], ({
  theme
}) => theme.primary);
const TabPanes = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"].TabPane).withConfig({
  displayName: "product__TabPanes",
  componentId: "sc-1261jbi-1"
})(["height:calc(100vh - 143px);margin-top:-10px;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}"], ({
  theme
}) => theme.primary);
const Cards = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Card"]).withConfig({
  displayName: "product__Cards",
  componentId: "sc-1261jbi-2"
})([".ant-card-body{padding:5px;}-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"]);
const Tabss = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Tabs"]).withConfig({
  displayName: "product__Tabss",
  componentId: "sc-1261jbi-3"
})([".ant-tabs-nav{}.ant-tabs-nav-wrap{padding:15px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;}"]);
const Buys = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "product__Buys",
  componentId: "sc-1261jbi-4"
})(["position:absolute;top:0px;right:0;background-color:", ";color:#fff;padding:5px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;"], ({
  theme
}) => theme.primary);

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wYWdlcy9wcm9kdWN0LnRzeCJdLCJuYW1lcyI6WyJQcm9kdWN0Iiwic3RhdGUiLCJkaXNwYXRjaCIsInVzZUNvbnRleHQiLCJDb250ZXh0IiwidGhlbWUiLCJUYWJEZXRhaWwiLCJwYWRkaW5nIiwibWFwIiwiaXRlbSIsImluZGV4Iiwid2lkdGgiLCJjb2xvciIsInByaW1hcnkiLCJqdXN0aWZ5Q29udGVudCIsIlBhZ2luYXRpb25zIiwic3R5bGVkIiwiUGFnaW5hdGlvbiIsIlRhYlBhbmVzIiwiVGFicyIsIlRhYlBhbmUiLCJDYXJkcyIsIkNhcmQiLCJUYWJzcyIsIkJ1eXMiLCJkaXYiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUllLFNBQVNBLE9BQVQsQ0FBaUIsRUFBakIsRUFBMEM7QUFDdkQsUUFBTTtBQUFFQyxTQUFGO0FBQVNDO0FBQVQsTUFBc0JDLHdEQUFVLENBQUNDLGdEQUFELENBQXRDO0FBQ0Esc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxLQUFEO0FBQU8sc0JBQWdCLEVBQUMsR0FBeEI7QUFBNEIsY0FBUSxNQUFwQztBQUFBLDhCQUNFLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVILEtBQUssQ0FBQ0ksS0FBdkI7QUFBOEIsV0FBRyxFQUFDLG9FQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQW9ELEdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVKLEtBQUssQ0FBQ0ksS0FBdkI7QUFBOEIsV0FBRyxFQUFDLDBFQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQXFELEdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKRixlQU9FLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVKLEtBQUssQ0FBQ0ksS0FBdkI7QUFBOEIsV0FBRyxFQUFDLDBFQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQXFELEdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQWVEOztBQUVELE1BQU1DLFNBQVMsR0FBRyxNQUFNO0FBQ3RCLFFBQU07QUFBRUwsU0FBRjtBQUFTQztBQUFULE1BQXNCQyx3REFBVSxDQUFDQyxnREFBRCxDQUF0QztBQUNBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFiO0FBQXFCLFdBQUssRUFBRTtBQUFFRyxlQUFPLEVBQUU7QUFBWCxPQUE1QjtBQUFBLGdCQUNHLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsRUFBeUIsQ0FBekIsRUFBNEIsRUFBNUIsRUFBZ0MsRUFBaEMsRUFBb0MsRUFBcEMsRUFBd0MsRUFBeEMsRUFBNEMsRUFBNUMsRUFBZ0QsRUFBaEQsRUFBb0QsRUFBcEQsRUFBd0QsRUFBeEQsRUFBNEQsRUFBNUQsRUFBZ0VDLEdBQWhFLENBQ0MsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ2YsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxjQUFJLEVBQUUsQ0FBWDtBQUFBLGlDQUNFLHFFQUFDLEtBQUQsQ0FDQTtBQURBO0FBQUEsb0NBR0UscUVBQUMsMENBQUQ7QUFBTyxpQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRixFQUd3QyxHQUh4QyxlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFQyxxQkFBSyxFQUFFLE1BQVQ7QUFBaUJKLHVCQUFPLEVBQUU7QUFBMUIsZUFBWjtBQUFBLHNDQUNFLHFFQUFDLElBQUQ7QUFBTSxxQkFBSyxFQUFFTixLQUFLLENBQUNJLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBRUUscUVBQUMseUNBQUQ7QUFDRSx5QkFBUyxNQURYO0FBRUUsNEJBQVksRUFBRSxDQUZoQjtBQUdFLHFCQUFLLEVBQUU7QUFBRU8sdUJBQUssRUFBRVgsS0FBSyxDQUFDSSxLQUFOLENBQVlRO0FBQXJCO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsV0FBbUJILEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFpQkQsT0FuQkY7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBd0JFLHFFQUFDLHdDQUFEO0FBQUssV0FBSyxFQUFFO0FBQUVJLHNCQUFjLEVBQUU7QUFBbEIsT0FBWjtBQUFBLDZCQUNFLHFFQUFDLFdBQUQ7QUFBYSxhQUFLLEVBQUViLEtBQUssQ0FBQ0ksS0FBMUI7QUFBaUMsc0JBQWMsRUFBRSxFQUFqRDtBQUFxRCxhQUFLLEVBQUU7QUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeEJGLGVBMkJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBM0JGLGVBNEJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNUJGO0FBQUEsa0JBREY7QUFnQ0QsQ0FsQ0Q7O0FBbUNBLE1BQU1VLFdBQVcsR0FBR0Msd0RBQU0sQ0FBQ0MsK0NBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSwwZkFFTyxDQUFDO0FBQUVaO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNRLE9BRjVCLENBQWpCO0FBMkJBLE1BQU1LLFFBQVEsR0FBR0Ysd0RBQU0sQ0FBQ0cseUNBQUksQ0FBQ0MsT0FBTixDQUFUO0FBQUE7QUFBQTtBQUFBLDRWQW1CVSxDQUFDO0FBQUVmO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNRLE9BbkIvQixDQUFkO0FBc0JBLE1BQU1RLEtBQUssR0FBR0wsd0RBQU0sQ0FBQ00seUNBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSwyU0FBWDtBQVlBLE1BQU1DLEtBQUssR0FBR1Asd0RBQU0sQ0FBQ0cseUNBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxxS0FBWDtBQWdCQSxNQUFNSyxJQUFJLEdBQUdSLHdEQUFNLENBQUNTLEdBQVY7QUFBQTtBQUFBO0FBQUEscU1BSVksQ0FBQztBQUFFcEI7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1EsT0FKakMsQ0FBVixDIiwiZmlsZSI6IjUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXJkLCBDb2wsIEltYWdlLCBQYWdpbmF0aW9uLCBSYXRlLCBSb3csIFRhYnMgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50LCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dFwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9kdWN0KHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxUYWJzcyBkZWZhdWx0QWN0aXZlS2V5PVwiMVwiIGNlbnRlcmVkPlxyXG4gICAgICAgIDxUYWJQYW5lcyB0aGVtZT17c3RhdGUudGhlbWV9IHRhYj1cIuC4q+C4oeC4p+C4lOC4geC4teC4leC5ieC4suC4o+C5jFwiIGtleT1cIjFcIj5cclxuICAgICAgICAgIDxUYWJEZXRhaWwgLz5cclxuICAgICAgICA8L1RhYlBhbmVzPlxyXG4gICAgICAgIDxUYWJQYW5lcyB0aGVtZT17c3RhdGUudGhlbWV9IHRhYj1cIuC4q+C4oeC4p+C4lOC5gOC4quC4t+C5ieC4reC4nOC5ieC4slwiIGtleT1cIjJcIj5cclxuICAgICAgICAgIDxUYWJEZXRhaWwgLz5cclxuICAgICAgICA8L1RhYlBhbmVzPlxyXG4gICAgICAgIDxUYWJQYW5lcyB0aGVtZT17c3RhdGUudGhlbWV9IHRhYj1cIuC4q+C4oeC4p+C4lOC5gOC4oeC4teC4ouC4meC5ieC4reC4olwiIGtleT1cIjNcIj5cclxuICAgICAgICAgIDxUYWJEZXRhaWwgLz5cclxuICAgICAgICA8L1RhYlBhbmVzPlxyXG4gICAgICA8L1RhYnNzPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgVGFiRGV0YWlsID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8Um93IGd1dHRlcj17WzgsIDhdfSBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cclxuICAgICAgICB7WzEsIDIsIDMsIDQsIDUsIDYsIDcsIDgsIDksIDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNywgMThdLm1hcChcclxuICAgICAgICAgIChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICA8Q2FyZHNcclxuICAgICAgICAgICAgICAgIC8vIHRpdGxlPXsncHJvZHVjdCcraXRlbX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi4vaW1hZ2VzL3Byb2R1Y3QxLnBuZ1wiIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogNSB9fT5cclxuICAgICAgICAgICAgICAgICAgICA8QnV5cyB0aGVtZT17c3RhdGUudGhlbWV9PjI1MDAuMDA8L0J1eXM+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93SGFsZlxyXG4gICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXszfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IHN0YXRlLnRoZW1lLnByaW1hcnkgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZHM+XHJcbiAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9Sb3c+XHJcbiAgICAgIDxSb3cgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgPFBhZ2luYXRpb25zIHRoZW1lPXtzdGF0ZS50aGVtZX0gZGVmYXVsdEN1cnJlbnQ9ezEwfSB0b3RhbD17NTB9IC8+XHJcbiAgICAgIDwvUm93PlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5jb25zdCBQYWdpbmF0aW9ucyA9IHN0eWxlZChQYWdpbmF0aW9uKWBcclxuICAuYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXHJcbiAgLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwNTg1ZTcgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlN2ViZWUgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6Zmlyc3QtY2hpbGQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSBhIHtcclxuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuYDtcclxuY29uc3QgVGFiUGFuZXMgPSBzdHlsZWQoVGFicy5UYWJQYW5lKWBcclxuICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxNDNweCk7XHJcbiAgLyogcGFkZGluZzogMTBweDsgKi9cclxuICBtYXJnaW4tdG9wOiAtMTBweDtcclxuICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgIHdpZHRoOiAxNXB4O1xyXG4gICAgaGVpZ2h0OiAxNXB4O1xyXG4gIH1cclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMHB4IDVweCAjMDAwMDAwO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VjZWNlYztcclxuICB9XHJcblxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICB9XHJcbmA7XHJcbmNvbnN0IENhcmRzID0gc3R5bGVkKENhcmQpYFxyXG4gIC5hbnQtY2FyZC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICB9XHJcblxyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcblxyXG4gIGJveC1zaGFkb3c6IDAgMi44cHggMi4ycHggcmdiKDAgMCAwIC8gMyUpLCAwIDYuN3B4IDUuM3B4IHJnYigwIDAgMCAvIDUlKSxcclxuICAgIDAgMTIuNXB4IDEwcHggcmdiKDAgMCAwIC8gNiUpLCAwIDM5LjNweCAxNy45cHggcmdiKDAgMCAwIC8gMCUpLFxyXG4gICAgMCA0MS44cHggMzMuNHB4IHJnYigwIDAgMCAvIDAlKSwgMCAxMDBweCA4MHB4IHJnYigwIDAgMCAvIDAlKTtcclxuYDtcclxuY29uc3QgVGFic3MgPSBzdHlsZWQoVGFicylgXHJcbiAgLmFudC10YWJzLW5hdiB7XHJcbiAgICAvKiBwYWRkaW5nOiAyMHB4OyAqL1xyXG4gIH1cclxuICAuYW50LXRhYnMtbmF2LXdyYXAge1xyXG4gICAgcGFkZGluZzogMTVweDtcclxuICAgIC8qIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7ICovXHJcblxyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAgIC1tb3otYm94LXNoYWRvdzogMCAxMHB4IDZweCAtNnB4ICM3Nzc7XHJcbiAgICBib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAgIC8qIGJveC1zaGFkb3c6IDAgMi44cHggMi4ycHggcmdiKDAgMCAwIC8gMyUpLCAwIDYuN3B4IDUuM3B4IHJnYigwIDAgMCAvIDUlKSxcclxuICAgICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7ICovXHJcbiAgfVxyXG5gO1xyXG5jb25zdCBCdXlzID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwcHg7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBjb2xvcjogI2ZmZjtcclxuICBwYWRkaW5nOiA1cHg7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gIGJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9