exports.ids = [0];
exports.modules = {

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ant-design/icons */ "@ant-design/icons");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx";







const primarys = [{
  colorName: "#7f0000"
}, {
  colorName: "#b71c1c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#560027"
}, {
  colorName: "#311b92"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#0d47a1"
}, {
  colorName: "#002f6c"
}, {
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#00363a"
}, {
  colorName: "#006064"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#38006b"
}, {
  colorName: "#212121"
}, {
  colorName: "#003300"
}, {
  colorName: "#003d00"
}, {
  colorName: "#524c00"
}, {
  colorName: "#1c313a"
}, {
  colorName: "#29434e"
}];
function Setting({}) {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_2__["Context"]);

  const setTheme = color => {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_5__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_6__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  const setLanguage = lang => {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_5__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_6__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map((row, index) => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Col"], {
          span: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName,
              borderColor: row.colorName
            },
            onClick: () => setTheme(row.colorName),
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 15
          }, this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 13
        }, this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: () => setLanguage("EN"),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, this), "ENGLISH"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: () => setLanguage("TH"),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_7__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 13
          }, this), "THAI"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
const TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], ({
  theme
}) => theme.primary);

/***/ }),

/***/ "./src/utils/local-storage.ts":
/*!************************************!*\
  !*** ./src/utils/local-storage.ts ***!
  \************************************/
/*! exports provided: _setStorage, _getStorage, _deleteStorage, _deleteAllStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_setStorage", function() { return _setStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_getStorage", function() { return _getStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteStorage", function() { return _deleteStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteAllStorage", function() { return _deleteAllStorage; });
const _setStorage = (key, body) => {
  localStorage.setItem(key, body);
};
const _getStorage = key => {
  const boby = localStorage.getItem(key);

  try {
    return JSON.parse(boby);
  } catch (error) {
    return boby;
  }
};
const _deleteStorage = key => {
  localStorage.removeItem(key);
};
const _deleteAllStorage = () => {
  localStorage.clear();
};

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wYWdlcy9zZXR0aW5nLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvbG9jYWwtc3RvcmFnZS50cyJdLCJuYW1lcyI6WyJwcmltYXJ5cyIsImNvbG9yTmFtZSIsIlNldHRpbmciLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzZXRUaGVtZSIsImNvbG9yIiwiX3NldFN0b3JhZ2UiLCJLRVlfU1RPUkFHRSIsIlRIRU1FIiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnNvbGUiLCJsb2ciLCJ0eXBlIiwicGF5bG9hZCIsInByaW1hcnkiLCJzZXRMYW5ndWFnZSIsImxhbmciLCJMQU5HIiwibGFuZ3VhZ2UiLCJ0aGVtZSIsInBhZGRpbmciLCJtYXAiLCJyb3ciLCJpbmRleCIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyQ29sb3IiLCJmb250U2l6ZSIsIlRleHRIZWFkZXIiLCJzdHlsZWQiLCJkaXYiLCJrZXkiLCJib2R5IiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsIl9nZXRTdG9yYWdlIiwiYm9ieSIsImdldEl0ZW0iLCJwYXJzZSIsImVycm9yIiwiX2RlbGV0ZVN0b3JhZ2UiLCJyZW1vdmVJdGVtIiwiX2RlbGV0ZUFsbFN0b3JhZ2UiLCJjbGVhciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLE1BQU1BLFFBQVEsR0FBRyxDQUNmO0FBQUVDLFdBQVMsRUFBRTtBQUFiLENBRGUsRUFFZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUZlLEVBR2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FIZSxFQUlmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBSmUsRUFLZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUxlLEVBTWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FOZSxFQU9mO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBUGUsRUFRZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVJlLEVBU2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FUZSxFQVVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBVmUsRUFXZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVhlLEVBWWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FaZSxFQWFmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBYmUsRUFjZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWRlLEVBZWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FmZSxFQWdCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWhCZSxFQWlCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWpCZSxFQWtCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWxCZSxFQW1CZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQW5CZSxFQW9CZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQXBCZSxDQUFqQjtBQXVCZSxTQUFTQyxPQUFULENBQWlCLEVBQWpCLEVBQTBDO0FBQ3ZELFFBQU07QUFBRUMsU0FBRjtBQUFTQztBQUFULE1BQXNCQyx3REFBVSxDQUFDQyxnREFBRCxDQUF0Qzs7QUFDQSxRQUFNQyxRQUFRLEdBQUlDLEtBQUQsSUFBVztBQUMxQkMsNEVBQVcsQ0FBQ0Msc0RBQVcsQ0FBQ0MsS0FBYixFQUFvQkMsSUFBSSxDQUFDQyxTQUFMLENBQWVMLEtBQWYsQ0FBcEIsQ0FBWDs7QUFDQU0sV0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QlAsS0FBekI7QUFFQUosWUFBUSxDQUFDO0FBQ1BZLFVBQUksRUFBRSxhQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQQyxlQUFPLEVBQUVWO0FBREY7QUFGRixLQUFELENBQVI7QUFNRCxHQVZEOztBQVdBLFFBQU1XLFdBQVcsR0FBSUMsSUFBRCxJQUFVO0FBQzVCWCw0RUFBVyxDQUFDQyxzREFBVyxDQUFDVyxJQUFiLEVBQW1CVCxJQUFJLENBQUNDLFNBQUwsQ0FBZU8sSUFBZixDQUFuQixDQUFYOztBQUVBaEIsWUFBUSxDQUFDO0FBQ1BZLFVBQUksRUFBRSxjQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQSyxnQkFBUSxFQUFFRjtBQURIO0FBRkYsS0FBRCxDQUFSO0FBTUQsR0FURDs7QUFVQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLFVBQUQ7QUFBWSxXQUFLLEVBQUVqQixLQUFLLENBQUNvQixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLGdCQUNHeEIsUUFBUSxDQUFDeUIsR0FBVCxDQUFhLENBQUNDLEdBQUQsRUFBTUMsS0FBTixLQUFnQjtBQUM1Qiw0QkFDRSxxRUFBQyx3Q0FBRDtBQUFpQixjQUFJLEVBQUUsQ0FBdkI7QUFBQSxpQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUU7QUFDTEMsbUJBQUssRUFBRSxNQURGO0FBRUxDLDZCQUFlLEVBQUVILEdBQUcsQ0FBQ3pCLFNBRmhCO0FBR0w2Qix5QkFBVyxFQUFFSixHQUFHLENBQUN6QjtBQUhaLGFBRlQ7QUFPRSxtQkFBTyxFQUFFLE1BQU1NLFFBQVEsQ0FBQ21CLEdBQUcsQ0FBQ3pCLFNBQUwsQ0FQekI7QUFBQSxzQkFTR3lCLEdBQUcsQ0FBQ3pCO0FBVFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFdBQVUwQixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREY7QUFlRCxPQWhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRixlQXFCRSxxRUFBQyxVQUFEO0FBQVksV0FBSyxFQUFFeEIsS0FBSyxDQUFDb0IsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyQkYsZUFzQkUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLDhCQUNFLHFFQUFDLHdDQUFEO0FBQUssWUFBSSxFQUFFLENBQVg7QUFBQSwrQkFDRSxxRUFBQywyQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsZUFBSyxFQUFFO0FBQUVJLGlCQUFLLEVBQUU7QUFBVCxXQUZUO0FBR0UsaUJBQU8sRUFBRSxNQUFNVCxXQUFXLENBQUMsSUFBRCxDQUg1QjtBQUFBLGtDQUtFLHFFQUFDLGdFQUFEO0FBQ0UsaUJBQUssRUFBRTtBQUFFWSxzQkFBUSxFQUFFO0FBQVo7QUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQWFFLHFFQUFDLHdDQUFEO0FBQUssWUFBSSxFQUFFLENBQVg7QUFBQSwrQkFDRSxxRUFBQywyQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsZUFBSyxFQUFFO0FBQUVILGlCQUFLLEVBQUU7QUFBVCxXQUZUO0FBR0UsaUJBQU8sRUFBRSxNQUFNVCxXQUFXLENBQUMsSUFBRCxDQUg1QjtBQUFBLGtDQUtFLHFFQUFDLGdFQUFEO0FBQ0UsaUJBQUssRUFBRTtBQUFFWSxzQkFBUSxFQUFFO0FBQVo7QUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF0QkY7QUFBQSxrQkFERjtBQW1ERDtBQUVELE1BQU1DLFVBQVUsR0FBR0Msd0RBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxvWUFJTCxDQUFDO0FBQUVYO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNMLE9BSmhCLENBQWhCLEM7Ozs7Ozs7Ozs7OztBQzdHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU8sTUFBTVQsV0FBVyxHQUFHLENBQUMwQixHQUFELEVBQWNDLElBQWQsS0FBK0I7QUFDdERDLGNBQVksQ0FBQ0MsT0FBYixDQUFxQkgsR0FBckIsRUFBMEJDLElBQTFCO0FBQ0QsQ0FGSTtBQUlFLE1BQU1HLFdBQVcsR0FBSUosR0FBRCxJQUFpQjtBQUMxQyxRQUFNSyxJQUFJLEdBQUdILFlBQVksQ0FBQ0ksT0FBYixDQUFxQk4sR0FBckIsQ0FBYjs7QUFDQSxNQUFJO0FBQ0YsV0FBT3ZCLElBQUksQ0FBQzhCLEtBQUwsQ0FBV0YsSUFBWCxDQUFQO0FBQ0QsR0FGRCxDQUVFLE9BQU9HLEtBQVAsRUFBYztBQUNkLFdBQU9ILElBQVA7QUFDRDtBQUNGLENBUE07QUFTQSxNQUFNSSxjQUFjLEdBQUlULEdBQUQsSUFBaUI7QUFDN0NFLGNBQVksQ0FBQ1EsVUFBYixDQUF3QlYsR0FBeEI7QUFDRCxDQUZNO0FBSUEsTUFBTVcsaUJBQWlCLEdBQUcsTUFBTTtBQUNyQ1QsY0FBWSxDQUFDVSxLQUFiO0FBQ0QsQ0FGTSxDIiwiZmlsZSI6IjAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50LCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBCdXR0b24sIENvbCwgUm93IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgX3NldFN0b3JhZ2UgfSBmcm9tIFwiLi4vLi4vdXRpbHMvbG9jYWwtc3RvcmFnZVwiO1xyXG5pbXBvcnQgeyBLRVlfU1RPUkFHRSB9IGZyb20gXCIuLi8uLi9jb25zdGFudHNcIjtcclxuaW1wb3J0IHsgR2xvYmFsT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5cclxuY29uc3QgcHJpbWFyeXMgPSBbXHJcbiAgeyBjb2xvck5hbWU6IFwiIzdmMDAwMFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiI2I3MWMxY1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzg4MGU0ZlwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzU2MDAyN1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzMxMWI5MlwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzFhMjM3ZVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzBkNDdhMVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwMmY2Y1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzI2MzIzOFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwNGQ0MFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwMzYzYVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwNjA2NFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzRhMTQ4Y1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzM4MDA2YlwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzIxMjEyMVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwMzMwMFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwM2QwMFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzUyNGMwMFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzFjMzEzYVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzI5NDM0ZVwiIH0sXHJcbl07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXR0aW5nKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3Qgc2V0VGhlbWUgPSAoY29sb3IpID0+IHtcclxuICAgIF9zZXRTdG9yYWdlKEtFWV9TVE9SQUdFLlRIRU1FLCBKU09OLnN0cmluZ2lmeShjb2xvcikpO1xyXG4gICAgY29uc29sZS5sb2coXCJUaGVtZSA9PiBcIiwgY29sb3IpO1xyXG5cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogXCJTRVRfUFJJTUFSWVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcHJpbWFyeTogY29sb3IsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIGNvbnN0IHNldExhbmd1YWdlID0gKGxhbmcpID0+IHtcclxuICAgIF9zZXRTdG9yYWdlKEtFWV9TVE9SQUdFLkxBTkcsIEpTT04uc3RyaW5naWZ5KGxhbmcpKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX0xBTkdVQUdFXCIsXHJcbiAgICAgIHBheWxvYWQ6IHtcclxuICAgICAgICBsYW5ndWFnZTogbGFuZyxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxUZXh0SGVhZGVyIHRoZW1lPXtzdGF0ZS50aGVtZX0+U0VUVElORyBQUklNQVJZPC9UZXh0SGVhZGVyPlxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IHN0eWxlPXt7IHBhZGRpbmc6IDEwIH19PlxyXG4gICAgICAgIHtwcmltYXJ5cy5tYXAoKHJvdywgaW5kZXgpID0+IHtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxDb2wga2V5PXtpbmRleH0gc3Bhbj17M30+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHJvdy5jb2xvck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiByb3cuY29sb3JOYW1lLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRoZW1lKHJvdy5jb2xvck5hbWUpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtyb3cuY29sb3JOYW1lfVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvUm93PlxyXG4gICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlNFVFRJTkcgTEFOR1VBR0U8L1RleHRIZWFkZXI+XHJcbiAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgcGFkZGluZzogMTAgfX0+XHJcbiAgICAgICAgPENvbCBzcGFuPXszfT5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZ3VhZ2UoXCJFTlwiKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEdsb2JhbE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IDIwfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgRU5HTElTSFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPENvbCBzcGFuPXszfT5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZ3VhZ2UoXCJUSFwiKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEdsb2JhbE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IDIwfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgVEhBSVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgIDwvUm93PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgVGV4dEhlYWRlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG4iLCJleHBvcnQgY29uc3QgX3NldFN0b3JhZ2UgPSAoa2V5OiBzdHJpbmcsIGJvZHk6IHN0cmluZykgPT4ge1xyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBib2R5KTtcclxuICB9O1xyXG4gIFxyXG4gIGV4cG9ydCBjb25zdCBfZ2V0U3RvcmFnZSA9IChrZXk6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgYm9ieSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShib2J5KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBib2J5O1xyXG4gICAgfVxyXG4gIH07XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IF9kZWxldGVTdG9yYWdlID0gKGtleTogc3RyaW5nKSA9PiB7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpO1xyXG4gIH07XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IF9kZWxldGVBbGxTdG9yYWdlID0gKCkgPT4ge1xyXG4gICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XHJcbiAgfTtcclxuICAiXSwic291cmNlUm9vdCI6IiJ9