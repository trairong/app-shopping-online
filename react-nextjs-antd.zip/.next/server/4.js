exports.ids = [4];
exports.modules = {

/***/ "./src/components/pages/list-product.tsx":
/*!***********************************************!*\
  !*** ./src/components/pages/list-product.tsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ListProduct; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\list-product.tsx";




const columns = [{
  title: "No.",
  dataIndex: "no" // width: 150,

}, {
  title: "ชื่อสินค้า",
  dataIndex: "productName" // width: 150,

}, {
  title: "ราคา",
  dataIndex: "ProductPrice"
}, {
  title: "จำนวน",
  dataIndex: "ProductQTY"
}, {
  title: "ราคารวม",
  dataIndex: "ProductTotal"
}, {
  title: "Action",
  dataIndex: "action",
  align: "center",
  width: 150,
  render: text => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Row"], {
      gutter: 16,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        span: 12,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Button"], {
          type: "primary",
          children: "EDIT"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 11
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Col"], {
        span: 12,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Button"], {
          type: "primary",
          children: "DEL"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 11
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 9
    }, undefined)
  }, void 0, false)
}];
function ListProduct({}) {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_4__["Context"]);
  const data = [];

  for (let i = 0; i < 100; i++) {
    data.push({
      key: i + 1,
      no: i + 1,
      productName: "product",
      ProductPrice: "1500.00",
      ProductQTY: 3,
      ProductTotal: "4500.00" // Active: ['delete','edit'],

    });
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Tables, {
      theme: state.theme,
      dataSource: data,
      columns: columns // scroll={{ y: "calc(100vh - 240px)" }}

    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this)
  }, void 0, false);
}
const Tables = styled_components__WEBPACK_IMPORTED_MODULE_2___default()(antd__WEBPACK_IMPORTED_MODULE_3__["Table"]).withConfig({
  displayName: "list-product__Tables",
  componentId: "sc-112xzpm-0"
})(["padding:16px;.ant-table-thead th{border-radius:0px !important;color:#fff;background:", "!important;border-bottom:solid 0px #cdd8ed !important;position:sticky;top:0px;z-index:2;}.ant-pagination-item-active a{color:#fff !important;}.ant-table-tbody > tr > td{border-bottom:solid 1px ", " !important;border-radius:0px !important;}.ant-table-tbody > tr:hover > td{background:", " !important;color:#fff;border-top:solid 1px ", " !important;border-bottom:solid 1px ", " !important;}.ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-table-content{height:calc(100vh - 160px);overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", "!important;}}-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.toolbar, ({
  theme
}) => theme.toolbar, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary);
const Scrolls = styled_components__WEBPACK_IMPORTED_MODULE_2___default.a.div.withConfig({
  displayName: "list-product__Scrolls",
  componentId: "sc-112xzpm-1"
})(["height:calc(100vh - 143px);padding:10px;margin-top:-10px;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:5px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:5px;background-color:", ";}"], ({
  theme
}) => theme.primary);

/***/ })

};;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9wYWdlcy9saXN0LXByb2R1Y3QudHN4Il0sIm5hbWVzIjpbImNvbHVtbnMiLCJ0aXRsZSIsImRhdGFJbmRleCIsImFsaWduIiwid2lkdGgiLCJyZW5kZXIiLCJ0ZXh0IiwiTGlzdFByb2R1Y3QiLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJkYXRhIiwiaSIsInB1c2giLCJrZXkiLCJubyIsInByb2R1Y3ROYW1lIiwiUHJvZHVjdFByaWNlIiwiUHJvZHVjdFFUWSIsIlByb2R1Y3RUb3RhbCIsInRoZW1lIiwiVGFibGVzIiwic3R5bGVkIiwiVGFibGUiLCJwcmltYXJ5IiwidG9vbGJhciIsIlNjcm9sbHMiLCJkaXYiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUdBLE1BQU1BLE9BQU8sR0FBRyxDQUNkO0FBQ0VDLE9BQUssRUFBRSxLQURUO0FBRUVDLFdBQVMsRUFBRSxJQUZiLENBR0U7O0FBSEYsQ0FEYyxFQU1kO0FBQ0VELE9BQUssRUFBRSxZQURUO0FBRUVDLFdBQVMsRUFBRSxhQUZiLENBR0U7O0FBSEYsQ0FOYyxFQVdkO0FBQ0VELE9BQUssRUFBRSxNQURUO0FBRUVDLFdBQVMsRUFBRTtBQUZiLENBWGMsRUFlZDtBQUNFRCxPQUFLLEVBQUUsT0FEVDtBQUVFQyxXQUFTLEVBQUU7QUFGYixDQWZjLEVBbUJkO0FBQ0VELE9BQUssRUFBRSxTQURUO0FBRUVDLFdBQVMsRUFBRTtBQUZiLENBbkJjLEVBdUJkO0FBQ0VELE9BQUssRUFBRSxRQURUO0FBRUVDLFdBQVMsRUFBRSxRQUZiO0FBR0VDLE9BQUssRUFBRSxRQUhUO0FBSUVDLE9BQUssRUFBRSxHQUpUO0FBS0VDLFFBQU0sRUFBR0MsSUFBRCxpQkFDTjtBQUFBLDJCQUNFLHFFQUFDLHdDQUFEO0FBQUssWUFBTSxFQUFFLEVBQWI7QUFBQSw4QkFDRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxFQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFBUSxjQUFJLEVBQUMsU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFJRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxFQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFBUSxjQUFJLEVBQUMsU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFOSixDQXZCYyxDQUFoQjtBQTJDZSxTQUFTQyxXQUFULENBQXFCLEVBQXJCLEVBQThDO0FBQzNELFFBQU07QUFBRUMsU0FBRjtBQUFTQztBQUFULE1BQXNCQyx3REFBVSxDQUFDQyxnREFBRCxDQUF0QztBQUVBLFFBQU1DLElBQUksR0FBRyxFQUFiOztBQUNBLE9BQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxHQUFwQixFQUF5QkEsQ0FBQyxFQUExQixFQUE4QjtBQUM1QkQsUUFBSSxDQUFDRSxJQUFMLENBQVU7QUFDUkMsU0FBRyxFQUFFRixDQUFDLEdBQUcsQ0FERDtBQUVSRyxRQUFFLEVBQUVILENBQUMsR0FBRyxDQUZBO0FBR1JJLGlCQUFXLEVBQUUsU0FITDtBQUlSQyxrQkFBWSxFQUFFLFNBSk47QUFLUkMsZ0JBQVUsRUFBRSxDQUxKO0FBTVJDLGtCQUFZLEVBQUUsU0FOTixDQVFSOztBQVJRLEtBQVY7QUFVRDs7QUFFRCxzQkFDRTtBQUFBLDJCQUVFLHFFQUFDLE1BQUQ7QUFDRSxXQUFLLEVBQUVaLEtBQUssQ0FBQ2EsS0FEZjtBQUVFLGdCQUFVLEVBQUVULElBRmQ7QUFHRSxhQUFPLEVBQUVaLE9BSFgsQ0FJRTs7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkYsbUJBREY7QUFZRDtBQUNELE1BQU1zQixNQUFNLEdBQUdDLHdEQUFNLENBQUNDLDBDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsd2dEQU1NLENBQUM7QUFBRUg7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0ksT0FOM0IsRUFrQm1CLENBQUM7QUFBRUo7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0ksT0FsQnhDLEVBdUJNLENBQUM7QUFBRUo7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0ksT0F2QjNCLEVBeUJnQixDQUFDO0FBQUVKO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNLLE9BekJyQyxFQTBCbUIsQ0FBQztBQUFFTDtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDSyxPQTFCeEMsRUE2QlksQ0FBQztBQUFFTDtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDSSxPQTdCakMsRUFrRWMsQ0FBQztBQUFFSjtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDSSxPQWxFbkMsQ0FBWjtBQTZFQSxNQUFNRSxPQUFPLEdBQUdKLHdEQUFNLENBQUNLLEdBQVY7QUFBQTtBQUFBO0FBQUEseVdBbUJXLENBQUM7QUFBRVA7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0ksT0FuQmhDLENBQWIsQyIsImZpbGUiOiI0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBUYWJsZSwgSW5wdXQsIEJ1dHRvbiwgUG9wY29uZmlybSwgRm9ybSwgUm93LCBDb2wgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBGb3JtSW5zdGFuY2UgfSBmcm9tIFwiYW50ZC9saWIvZm9ybVwiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5jb25zdCBjb2x1bW5zID0gW1xyXG4gIHtcclxuICAgIHRpdGxlOiBcIk5vLlwiLFxyXG4gICAgZGF0YUluZGV4OiBcIm5vXCIsXHJcbiAgICAvLyB3aWR0aDogMTUwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwi4LiK4Li34LmI4Lit4Liq4Li04LiZ4LiE4LmJ4LiyXCIsXHJcbiAgICBkYXRhSW5kZXg6IFwicHJvZHVjdE5hbWVcIixcclxuICAgIC8vIHdpZHRoOiAxNTAsXHJcbiAgfSxcclxuICB7XHJcbiAgICB0aXRsZTogXCLguKPguLLguITguLJcIixcclxuICAgIGRhdGFJbmRleDogXCJQcm9kdWN0UHJpY2VcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiBcIuC4iOC4s+C4meC4p+C4mVwiLFxyXG4gICAgZGF0YUluZGV4OiBcIlByb2R1Y3RRVFlcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiBcIuC4o+C4suC4hOC4suC4o+C4p+C4oVwiLFxyXG4gICAgZGF0YUluZGV4OiBcIlByb2R1Y3RUb3RhbFwiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwiQWN0aW9uXCIsXHJcbiAgICBkYXRhSW5kZXg6IFwiYWN0aW9uXCIsXHJcbiAgICBhbGlnbjogXCJjZW50ZXJcIixcclxuICAgIHdpZHRoOiAxNTAsXHJcbiAgICByZW5kZXI6ICh0ZXh0OiBzdHJpbmcpID0+IChcclxuICAgICAgPD5cclxuICAgICAgICA8Um93IGd1dHRlcj17MTZ9PlxyXG4gICAgICAgICAgPENvbCBzcGFuPXsxMn0+XHJcbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIj5FRElUPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgc3Bhbj17MTJ9PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCI+REVMPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICA8L1Jvdz5cclxuICAgICAgPC8+XHJcbiAgICApLFxyXG4gIH0sXHJcbl07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaXN0UHJvZHVjdCh7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG5cclxuICBjb25zdCBkYXRhID0gW107XHJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDA7IGkrKykge1xyXG4gICAgZGF0YS5wdXNoKHtcclxuICAgICAga2V5OiBpICsgMSxcclxuICAgICAgbm86IGkgKyAxLFxyXG4gICAgICBwcm9kdWN0TmFtZTogXCJwcm9kdWN0XCIsXHJcbiAgICAgIFByb2R1Y3RQcmljZTogXCIxNTAwLjAwXCIsXHJcbiAgICAgIFByb2R1Y3RRVFk6IDMsXHJcbiAgICAgIFByb2R1Y3RUb3RhbDogXCI0NTAwLjAwXCIsXHJcblxyXG4gICAgICAvLyBBY3RpdmU6IFsnZGVsZXRlJywnZWRpdCddLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgey8qIDxTY3JvbGxzIHRoZW1lPXtzdGF0ZS50aGVtZX0+ICovfVxyXG4gICAgICA8VGFibGVzXHJcbiAgICAgICAgdGhlbWU9e3N0YXRlLnRoZW1lfVxyXG4gICAgICAgIGRhdGFTb3VyY2U9e2RhdGF9XHJcbiAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAvLyBzY3JvbGw9e3sgeTogXCJjYWxjKDEwMHZoIC0gMjQwcHgpXCIgfX1cclxuICAgICAgPjwvVGFibGVzPlxyXG4gICAgICB7LyogPC9TY3JvbGxzPiAqL31cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuY29uc3QgVGFibGVzID0gc3R5bGVkKFRhYmxlKWBcclxuICBwYWRkaW5nOiAxNnB4O1xyXG4gIC8qIGhlaWdodDogMTAwJTsgKi9cclxuICAuYW50LXRhYmxlLXRoZWFkIHRoIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9IWltcG9ydGFudDtcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDBweCAjY2RkOGVkICFpbXBvcnRhbnQ7XHJcbiAgICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gICAgdG9wOiAwcHg7XHJcbiAgICB6LWluZGV4OiAyO1xyXG4gIH1cclxuXHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tYWN0aXZlIGEge1xyXG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtdGFibGUtdGJvZHkgPiB0ciA+IHRkIHtcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtdGFibGUtdGJvZHkgPiB0cjpob3ZlciA+IHRkIHtcclxuICAgIGJhY2tncm91bmQ6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYm9yZGVyLXRvcDogc29saWQgMXB4ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUudG9vbGJhcn0gIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnRvb2xiYXJ9ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9IWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxuICAuYW50LXBhZ2luYXRpb24taXRlbSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1wcmV2OmFmdGVyLFxyXG4gIC5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQ6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzA1ODVlNyAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2U3ZWJlZSAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazpmaXJzdC1jaGlsZCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogIzAwMDtcclxuICB9XHJcbiAgLmFudC10YWJsZS1jb250ZW50IHtcclxuICAgIGhlaWdodDogY2FsYygxMDB2aCAtIDE2MHB4KTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgd2lkdGg6IDE1cHg7XHJcbiAgICAgIGhlaWdodDogMTVweDtcclxuICAgIH1cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgICAtd2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjUpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlY2VjZWM7XHJcbiAgICB9XHJcblxyXG4gICAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcblxyXG4gIGJveC1zaGFkb3c6IDAgMi44cHggMi4ycHggcmdiKDAgMCAwIC8gMyUpLCAwIDYuN3B4IDUuM3B4IHJnYigwIDAgMCAvIDUlKSxcclxuICAgIDAgMTIuNXB4IDEwcHggcmdiKDAgMCAwIC8gNiUpLCAwIDM5LjNweCAxNy45cHggcmdiKDAgMCAwIC8gMCUpLFxyXG4gICAgMCA0MS44cHggMzMuNHB4IHJnYigwIDAgMCAvIDAlKSwgMCAxMDBweCA4MHB4IHJnYigwIDAgMCAvIDAlKTtcclxuYDtcclxuXHJcbmNvbnN0IFNjcm9sbHMgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDE0M3B4KTtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIG1hcmdpbi10b3A6IC0xMHB4O1xyXG4gIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgfVxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNlY2VjO1xyXG4gIH1cclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuYDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==