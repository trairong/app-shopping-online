module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// object to store loaded chunks
/******/ 	// "0" means "already loaded"
/******/ 	var installedChunks = {
/******/ 		"pages/index": 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// require() chunk loading for javascript
/******/
/******/ 		// "0" is the signal for "already loaded"
/******/ 		if(installedChunks[chunkId] !== 0) {
/******/ 			var chunk = require("../" + ({}[chunkId]||chunkId) + ".js");
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids;
/******/ 			for(var moduleId in moreModules) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// uncaught error handler for webpack runtime
/******/ 	__webpack_require__.oe = function(err) {
/******/ 		process.nextTick(function() {
/******/ 			throw err; // catch this error by using import().catch()
/******/ 		});
/******/ 	};
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_c_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/components/c-layout */ "./src/components/c-layout.tsx");
/* harmony import */ var _src_components_c_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/c-header */ "./src/components/c-header.tsx");
/* harmony import */ var _src_components_c_sider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../src/components/c-sider */ "./src/components/c-sider.tsx");
/* harmony import */ var _src_utils_switch_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../src/utils/switch-components */ "./src/utils/switch-components.tsx");
/* harmony import */ var _src_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/context */ "./src/context/index.tsx");
/* harmony import */ var _src_components_c_content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/components/c-content */ "./src/components/c-content.tsx");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\pages\\index.tsx";








function Home() {
  const {
    state
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_src_context__WEBPACK_IMPORTED_MODULE_7__["Context"]); // useEffect(() => {
  // }, [])

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_c_layout__WEBPACK_IMPORTED_MODULE_3__["default"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_c_header__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_c_layout__WEBPACK_IMPORTED_MODULE_3__["default"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_c_sider__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_components_c_content__WEBPACK_IMPORTED_MODULE_8__["default"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_utils_switch_components__WEBPACK_IMPORTED_MODULE_6__["default"], {
            route: state.routMenu
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default.a, {
      id: "3718163584",
      children: "html,body{padding:0;margin:0;font-family:\"Kanit\",sans-serif;}*{box-sizing:border-box;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkQ6XFx0ZW1wbGF0ZVxccmVhY3RcXHJlYWN0LW5leHRqcy1hbnRkXFxwYWdlc1xcaW5kZXgudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXlCeUIsQUFJcUIsQUFNWSxVQUxiLFNBQ3VCLEdBS2xDLDRCQUpBIiwiZmlsZSI6IkQ6XFx0ZW1wbGF0ZVxccmVhY3RcXHJlYWN0LW5leHRqcy1hbnRkXFxwYWdlc1xcaW5kZXgudHN4Iiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUNvbnRleHQsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IENMYXlvdXQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL2MtbGF5b3V0XCI7XG5pbXBvcnQgQ0hlYWRlciBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvYy1oZWFkZXJcIjtcbmltcG9ydCBDU2lkZXIgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL2Mtc2lkZXJcIjtcbmltcG9ydCBTd2l0Y2hDb21wb25lbnRzIGZyb20gXCIuLi9zcmMvdXRpbHMvc3dpdGNoLWNvbXBvbmVudHNcIjtcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vc3JjL2NvbnRleHRcIjtcbmltcG9ydCBDQ29udGVudCBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvYy1jb250ZW50XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IHsgc3RhdGUgfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XG5cbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcbiAgXG4gIC8vIH0sIFtdKVxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8Q0xheW91dD5cbiAgICAgICAgPENIZWFkZXIgLz5cbiAgICAgICAgPENMYXlvdXQ+XG4gICAgICAgICAgPENTaWRlciAvPlxuICAgICAgICAgIDxDQ29udGVudD5cbiAgICAgICAgICAgIDxTd2l0Y2hDb21wb25lbnRzIHJvdXRlPXtzdGF0ZS5yb3V0TWVudX0gLz5cbiAgICAgICAgICA8L0NDb250ZW50PlxuICAgICAgICA8L0NMYXlvdXQ+XG4gICAgICA8L0NMYXlvdXQ+XG4gICAgICA8c3R5bGUganN4IGdsb2JhbD57YFxuICAgICAgICBodG1sLFxuICAgICAgICBib2R5IHtcbiAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICBmb250LWZhbWlseTogXCJLYW5pdFwiLCBzYW5zLXNlcmlmO1xuICAgICAgICB9XG5cbiAgICAgICAgKiB7XG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICAgICAgfVxuICAgICAgYH08L3N0eWxlPlxuICAgIDwvPlxuICApO1xufVxuIl19 */\n/*@ sourceURL=D:\\\\template\\\\react\\\\react-nextjs-antd\\\\pages\\\\index.tsx */"
    }, void 0, false, void 0, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./src/components lazy recursive ^\\.\\/.*$":
/*!*******************************************************!*\
  !*** ./src/components lazy ^\.\/.*$ namespace object ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./c-content": [
		"./src/components/c-content.tsx"
	],
	"./c-content.tsx": [
		"./src/components/c-content.tsx"
	],
	"./c-footer": [
		"./src/components/c-footer.tsx",
		1
	],
	"./c-footer.tsx": [
		"./src/components/c-footer.tsx",
		1
	],
	"./c-header": [
		"./src/components/c-header.tsx"
	],
	"./c-header.tsx": [
		"./src/components/c-header.tsx"
	],
	"./c-layout": [
		"./src/components/c-layout.tsx"
	],
	"./c-layout.tsx": [
		"./src/components/c-layout.tsx"
	],
	"./c-sider": [
		"./src/components/c-sider.tsx"
	],
	"./c-sider.tsx": [
		"./src/components/c-sider.tsx"
	],
	"./pages/history": [
		"./src/components/pages/history.tsx",
		2
	],
	"./pages/history.tsx": [
		"./src/components/pages/history.tsx",
		2
	],
	"./pages/home": [
		"./src/components/pages/home.tsx",
		3
	],
	"./pages/home.tsx": [
		"./src/components/pages/home.tsx",
		3
	],
	"./pages/list-product": [
		"./src/components/pages/list-product.tsx",
		4
	],
	"./pages/list-product.tsx": [
		"./src/components/pages/list-product.tsx",
		4
	],
	"./pages/product": [
		"./src/components/pages/product.tsx",
		5
	],
	"./pages/product.tsx": [
		"./src/components/pages/product.tsx",
		5
	],
	"./pages/setting": [
		"./src/components/pages/setting.tsx",
		0
	],
	"./pages/setting.tsx": [
		"./src/components/pages/setting.tsx",
		0
	],
	"./pages/transport": [
		"./src/components/pages/transport.tsx",
		6
	],
	"./pages/transport.tsx": [
		"./src/components/pages/transport.tsx",
		6
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/components lazy recursive ^\\.\\/.*$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/components weak recursive ^\\.\\/.*$":
/*!**************************************!*\
  !*** ./src/components weak ^\.\/.*$ ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./c-content": "./src/components/c-content.tsx",
	"./c-content.tsx": "./src/components/c-content.tsx",
	"./c-footer": "./src/components/c-footer.tsx",
	"./c-footer.tsx": "./src/components/c-footer.tsx",
	"./c-header": "./src/components/c-header.tsx",
	"./c-header.tsx": "./src/components/c-header.tsx",
	"./c-layout": "./src/components/c-layout.tsx",
	"./c-layout.tsx": "./src/components/c-layout.tsx",
	"./c-sider": "./src/components/c-sider.tsx",
	"./c-sider.tsx": "./src/components/c-sider.tsx",
	"./pages/history": "./src/components/pages/history.tsx",
	"./pages/history.tsx": "./src/components/pages/history.tsx",
	"./pages/home": "./src/components/pages/home.tsx",
	"./pages/home.tsx": "./src/components/pages/home.tsx",
	"./pages/list-product": "./src/components/pages/list-product.tsx",
	"./pages/list-product.tsx": "./src/components/pages/list-product.tsx",
	"./pages/product": "./src/components/pages/product.tsx",
	"./pages/product.tsx": "./src/components/pages/product.tsx",
	"./pages/setting": "./src/components/pages/setting.tsx",
	"./pages/setting.tsx": "./src/components/pages/setting.tsx",
	"./pages/transport": "./src/components/pages/transport.tsx",
	"./pages/transport.tsx": "./src/components/pages/transport.tsx"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	if(!__webpack_require__.m[id]) {
		var e = new Error("Module '" + req + "' ('" + id + "') is not available (weak dependency)");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
webpackContext.id = "./src/components weak recursive ^\\.\\/.*$";
module.exports = webpackContext;

/***/ }),

/***/ "./src/components/c-content.tsx":
/*!**************************************!*\
  !*** ./src/components/c-content.tsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CContent; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-content.tsx";



function CContent({
  children
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Contents, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: 1,
          width: "100%",
          overflow: 'hidden'
        },
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 9
    }, this)
  }, void 0, false);
}
const Contents = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Layout"].Content).withConfig({
  displayName: "c-content__Contents",
  componentId: "sc-9afq94-0"
})(["display:flex;flex-direction:column;"]);

/***/ }),

/***/ "./src/components/c-header.tsx":
/*!*************************************!*\
  !*** ./src/components/c-header.tsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CHeader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ant-design/icons */ "@ant-design/icons");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Account */ "@2fd/ant-design-icons/lib/Account");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/AccountCircle */ "@2fd/ant-design-icons/lib/AccountCircle");
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Cart */ "@2fd/ant-design-icons/lib/Cart");
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/ViewGrid */ "@2fd/ant-design-icons/lib/ViewGrid");
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/BellOutline */ "@2fd/ant-design-icons/lib/BellOutline");
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-header.tsx";











const {
  Header,
  Footer,
  Sider,
  Content
} = antd__WEBPACK_IMPORTED_MODULE_1__["Layout"];
function CHeader({}) {
  const {
    state
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]);
  const {
    0: lang,
    1: setlang
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
  const {
    0: isLoad,
    1: setisLoad
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_11__["Language"])(state.language));
    setisLoad(true);
  }, [state.language]);
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {}, [lang]);

  const menu = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"], {
    style: {
      width: 200
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["UserOutlined"], {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 32
      }, this),
      children: "Profile"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_6___default.a, {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 32
      }, this),
      children: "Logout"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, this);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: isLoad && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Headers, {
      theme: state.theme,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Row"], {
        style: {
          height: "100%",
          display: "flex",
          alignItems: "center"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
          md: 6,
          style: {
            display: "flex",
            height: "100%"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Images, {
            src: "/images/shopping_1.png",
            preview: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
          md: 12,
          style: {
            display: "flex",
            alignItems: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Input"], {
            placeholder: "INPUT SEARCH",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            type: "primary",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            },
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__["SearchOutlined"], {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 58,
              columnNumber: 23
            }, this),
            children: lang.Search
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Col"], {
          md: 6,
          style: {
            textAlign: "end"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_10___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_8___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_9___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Dropdown"], {
            overlay: menu,
            placement: "bottomLeft",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              type: "primary",
              shape: "circle",
              icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_7___default.a, {
                style: {
                  fontSize: 30
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 25
              }, this),
              style: {
                width: 50,
                height: 50
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 83,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 9
    }, this)
  }, void 0, false);
}
const Headers = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(Header).withConfig({
  displayName: "c-header__Headers",
  componentId: "sc-18zra2i-0"
})(["background-color:", ";box-shadow:0px 0px 5px #000000;padding:0px;height:80px;position:sticky;top:0px;z-index:3;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], ({
  theme
}) => theme.primary);
const Images = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Image"]).withConfig({
  displayName: "c-header__Images",
  componentId: "sc-18zra2i-1"
})(["height:100%;width:100px;padding-left:0px;"]);

/***/ }),

/***/ "./src/components/c-layout.tsx":
/*!*************************************!*\
  !*** ./src/components/c-layout.tsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CLayout; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-layout.tsx";



function CLayout({
  children
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Layouts, {
      style: {
        height: "100vh"
      },
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this)
  }, void 0, false);
}
const Layouts = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_1__["Layout"]).withConfig({
  displayName: "c-layout__Layouts",
  componentId: "sc-167kuxx-0"
})(["#components-layout-demo-side .logo{height:32px;margin:16px;background:rgba(255,255,255,0.3);}.site-layout .site-layout-background{background:#fff;}"]);

/***/ }),

/***/ "./src/components/c-sider.tsx":
/*!************************************!*\
  !*** ./src/components/c-sider.tsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CSider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _constants_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../constants/index */ "./src/constants/index.ts");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Home */ "@2fd/ant-design-icons/lib/Home");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/History */ "@2fd/ant-design-icons/lib/History");
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/FormatListBulletedSquare */ "@2fd/ant-design-icons/lib/FormatListBulletedSquare");
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/CogOutline */ "@2fd/ant-design-icons/lib/CogOutline");
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/TruckDeliveryOutline */ "@2fd/ant-design-icons/lib/TruckDeliveryOutline");
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Shopping */ "@2fd/ant-design-icons/lib/Shopping");
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-sider.tsx";












function CSider({}) {
  const {
    state,
    dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_4__["Context"]);
  const {
    0: menuKey,
    1: setMenuKey
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: isLoading,
    1: setIsLoading
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const {
    0: lang,
    1: setlang
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null);
  const {
    0: collapsed,
    1: setCollapsed
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    collapsed: false
  });
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let langs = Object(_languages__WEBPACK_IMPORTED_MODULE_12__["Language"])(state.language);
    setlang(langs);
  }, [state.language]);
  const MIST_MENU = [{
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].HOME,
    title: lang === null || lang === void 0 ? void 0 : lang.Home,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_6___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].PRODUCT,
    title: lang === null || lang === void 0 ? void 0 : lang.ProductType,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_11___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].LIST_PRODUCT,
    title: lang === null || lang === void 0 ? void 0 : lang.ProductList,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_8___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].HISTORY,
    title: lang === null || lang === void 0 ? void 0 : lang.ProductHistory,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_7___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].TRANSPORT,
    title: lang === null || lang === void 0 ? void 0 : lang.ProductShipping,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_10___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_5__["ROUTE_MENU"].SETTING,
    title: lang === null || lang === void 0 ? void 0 : lang.Setting,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_9___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 13
    }, this)
  }];
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (MIST_MENU) {
      setMenuKey(MIST_MENU[0].key);
    }

    setIsLoading(true);
  }, [state.language]);

  const onCollapse = collapsed => {
    console.log(collapsed);
    setCollapsed({
      collapsed
    });
  };

  const RouteMenu = item => {
    console.log(item);
    dispatch({
      type: "SET_ROUT_MUNU",
      payload: {
        routMenu: item.key
      }
    });
    setMenuKey(item.key);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {}, [lang, MIST_MENU]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Siders, {
      collapsible: true,
      collapsed: collapsed.collapsed,
      onCollapse: onCollapse,
      theme: state.theme,
      width: 250,
      children: isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"], {
        mode: "inline",
        defaultSelectedKeys: [menuKey],
        className: "Menu",
        children: MIST_MENU.map((item, index) => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
            className: "siderMenu",
            icon: item.icon,
            onClick: () => RouteMenu(item),
            children: item.title
          }, item.key, false, {
            fileName: _jsxFileName,
            lineNumber: 111,
            columnNumber: 17
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 100,
      columnNumber: 7
    }, this)
  }, void 0, false);
}
const Siders = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Sider).withConfig({
  displayName: "c-sider__Siders",
  componentId: "o7xxc1-0"
})(["box-shadow:0px 0px 5px #000000;background-color:", ";overflow:hidden;.ant-menu-inline .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-menu-vertical .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-layout-sider-trigger{background-color:", ";}.ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected{background-color:", " !important;color:#fff;height:60px;padding-left:24px;display:flex;align-items:center;margin:0px;}.ant-menu-submenu > .ant-menu-submenu-title{height:60px;display:flex;align-items:center;color:", ";margin:0px;}.ant-menu-submenu-arrow{color:", ";}.siderMenu{height:60px;padding-left:24px;display:flex;align-items:center;color:", ";margin:0px;}.Menu{height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:10px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.3);border-radius:0px;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}}"], ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary, ({
  theme
}) => theme.primary);

/***/ }),

/***/ "./src/constants/index.ts":
/*!********************************!*\
  !*** ./src/constants/index.ts ***!
  \********************************/
/*! exports provided: HOST, ROUTE_MENU, KEY_STORAGE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOST", function() { return HOST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ROUTE_MENU", function() { return ROUTE_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KEY_STORAGE", function() { return KEY_STORAGE; });
const NODE_ENV = "development";
const HOST = {
  URL: NODE_ENV.trim() === "development" ? "http://localhost:3000" : "",
  API: {
    AUTH: {
      GETPRODUCT: "/api/product"
    }
  }
};
const ROUTE_MENU = {
  HOME: "pages/home",
  PRODUCT: "pages/product",
  LIST_PRODUCT: "pages/list-product",
  HISTORY: "pages/history",
  TRANSPORT: "pages/transport",
  SETTING: "pages/setting"
};
const KEY_STORAGE = {
  THEME: "SET_THEME",
  LANG: "SET_LANGUAGE"
};

/***/ }),

/***/ "./src/context/index.tsx":
/*!*******************************!*\
  !*** ./src/context/index.tsx ***!
  \*******************************/
/*! exports provided: initialState, Context */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Context", function() { return Context; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  user: null,
  language: "TH",
  routMenu: "pages/home",
  userToken: null,
  theme: {
    // primary: "#263238",
    primary: "#004d40",
    // primary: "#1a237e",
    // primary: "#4a148c",
    // primary: "#880e4f",
    // primary: "#212121",
    link: "#007AFF",
    success: "#4CD964",
    warning: "#FF9500",
    error: "#FF3B30",
    toolbar: "#000000",
    outline: "#ffffff",
    white: "#ffffff"
  }
};
const Context = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["createContext"])(null);

/***/ }),

/***/ "./src/languages/index.ts":
/*!********************************!*\
  !*** ./src/languages/index.ts ***!
  \********************************/
/*! exports provided: Language */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Language", function() { return Language; });
const langTH = {
  TITLE: ["ค้นหา", "Search"],
  RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
};
const Language = lang => {
  let SetLanguage = {};
  let indexTH = 0;
  let indexEN = 1;
  const Language = {
    Home: ["หน้าแรก", "HOME"],
    ProductType: ["หมวดสินค้า", "PRODUCT TYPE"],
    ProductList: ["สินค้าที่เลือก", "PRODUCT LIST"],
    ProductHistory: ["สินค้าที่สั่งซื้อแล้ว", "PRODUCT HISTORY"],
    ProductShipping: ["สินค้ากำลังจัดส่ง", "PRODUCT SHIPPING"],
    Setting: ["ตั้งค้า", "SETTING"],
    Search: ["ค้นหา", "Search"],
    RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
  };

  const getTH = () => {
    SetLanguage.Home = Language.Home[indexTH];
    SetLanguage.ProductType = Language.ProductType[indexTH];
    SetLanguage.ProductList = Language.ProductList[indexTH];
    SetLanguage.ProductHistory = Language.ProductHistory[indexTH];
    SetLanguage.ProductShipping = Language.ProductShipping[indexTH];
    SetLanguage.Setting = Language.Setting[indexTH];
    SetLanguage.Search = Language.Search[indexTH];
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexTH];
    return SetLanguage;
  };

  const getEN = () => {
    SetLanguage.Home = Language.Home[indexEN];
    SetLanguage.ProductType = Language.ProductType[indexEN];
    SetLanguage.ProductList = Language.ProductList[indexEN];
    SetLanguage.ProductHistory = Language.ProductHistory[indexEN];
    SetLanguage.ProductShipping = Language.ProductShipping[indexEN];
    SetLanguage.Setting = Language.Setting[indexEN];
    SetLanguage.Search = Language.Search[indexEN];
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexEN];
    return SetLanguage;
  };

  if (lang.toUpperCase() == "TH") {
    return getTH();
  }

  return getEN();
};

/***/ }),

/***/ "./src/utils/switch-components.tsx":
/*!*****************************************!*\
  !*** ./src/utils/switch-components.tsx ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dynamic */ "next/dynamic");
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "antd");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\utils\\switch-components.tsx";



const SwitchComponents = ({
  route
}) => {
  try {
    const Article = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(() => __webpack_require__("./src/components lazy recursive ^\\.\\/.*$")(`./${route}`).catch(err => {
      return () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(StatusWrong, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 24
      }, undefined);
    }), {
      loading: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          width: "100%",
          height: "90vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Spin"], {
          tip: "Loading..."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 11
      }, undefined),
      loadableGenerated: {
        webpack: () => [/*require.resolve*/(__webpack_require__("./src/components weak recursive ^\\.\\/.*$").resolve(`./${route}`))],
        modules: [`../components/${route}`]
      }
    });
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Article, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 12
    }, undefined);
  } catch (error) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(StatusWrong, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 12
    }, undefined);
  }
};

const StatusWrong = () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Result"], {
  status: "500",
  title: "500",
  subTitle: "Sorry, something went wrong."
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 37,
  columnNumber: 3
}, undefined);

/* harmony default export */ __webpack_exports__["default"] = (SwitchComponents);

/***/ }),

/***/ "@2fd/ant-design-icons/lib/Account":
/*!****************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/Account" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/Account");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/AccountCircle":
/*!**********************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/AccountCircle" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/AccountCircle");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/BellOutline":
/*!********************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/BellOutline" ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/BellOutline");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/Cart":
/*!*************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/Cart" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/Cart");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/CogOutline":
/*!*******************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/CogOutline" ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/CogOutline");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/FormatListBulletedSquare":
/*!*********************************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/FormatListBulletedSquare" ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/FormatListBulletedSquare");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/History":
/*!****************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/History" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/History");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/Home":
/*!*************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/Home" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/Home");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/Shopping":
/*!*****************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/Shopping" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/Shopping");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/TruckDeliveryOutline":
/*!*****************************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/TruckDeliveryOutline" ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/TruckDeliveryOutline");

/***/ }),

/***/ "@2fd/ant-design-icons/lib/ViewGrid":
/*!*****************************************************!*\
  !*** external "@2fd/ant-design-icons/lib/ViewGrid" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@2fd/ant-design-icons/lib/ViewGrid");

/***/ }),

/***/ "@ant-design/icons":
/*!************************************!*\
  !*** external "@ant-design/icons" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ "antd":
/*!***********************!*\
  !*** external "antd" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),

/***/ "next/dynamic":
/*!*******************************!*\
  !*** external "next/dynamic" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dynamic");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzIGxhenkgXlxcLlxcLy4qJCBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzIHdlYWsgXlxcLlxcLy4qJCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jLWNvbnRlbnQudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2MtaGVhZGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jLWxheW91dC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvYy1zaWRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnN0YW50cy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGV4dC9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2xhbmd1YWdlcy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvc3dpdGNoLWNvbXBvbmVudHMudHN4Iiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudENpcmNsZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQmVsbE91dGxpbmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NhcnRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NvZ091dGxpbmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0Zvcm1hdExpc3RCdWxsZXRlZFNxdWFyZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSGlzdG9yeVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSG9tZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvU2hvcHBpbmdcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1RydWNrRGVsaXZlcnlPdXRsaW5lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9WaWV3R3JpZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBhbnQtZGVzaWduL2ljb25zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiYW50ZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvZHluYW1pY1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3R5bGVkLWNvbXBvbmVudHNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJzdHlsZWQtanN4L3N0eWxlXCIiXSwibmFtZXMiOlsiSG9tZSIsInN0YXRlIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJyb3V0TWVudSIsIkNDb250ZW50IiwiY2hpbGRyZW4iLCJmbGV4Iiwid2lkdGgiLCJvdmVyZmxvdyIsIkNvbnRlbnRzIiwic3R5bGVkIiwiTGF5b3V0IiwiQ29udGVudCIsIkhlYWRlciIsIkZvb3RlciIsIlNpZGVyIiwiQ0hlYWRlciIsImxhbmciLCJzZXRsYW5nIiwidXNlU3RhdGUiLCJpc0xvYWQiLCJzZXRpc0xvYWQiLCJ1c2VFZmZlY3QiLCJMYW5ndWFnZSIsImxhbmd1YWdlIiwibWVudSIsImZvbnRTaXplIiwidGhlbWUiLCJoZWlnaHQiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsIlNlYXJjaCIsInRleHRBbGlnbiIsIkhlYWRlcnMiLCJwcmltYXJ5IiwiSW1hZ2VzIiwiSW1hZ2UiLCJDTGF5b3V0IiwiTGF5b3V0cyIsIkNTaWRlciIsImRpc3BhdGNoIiwibWVudUtleSIsInNldE1lbnVLZXkiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJjb2xsYXBzZWQiLCJzZXRDb2xsYXBzZWQiLCJsYW5ncyIsIk1JU1RfTUVOVSIsImtleSIsIk1FTlUiLCJIT01FIiwidGl0bGUiLCJpY29uIiwiUFJPRFVDVCIsIlByb2R1Y3RUeXBlIiwiTElTVF9QUk9EVUNUIiwiUHJvZHVjdExpc3QiLCJISVNUT1JZIiwiUHJvZHVjdEhpc3RvcnkiLCJUUkFOU1BPUlQiLCJQcm9kdWN0U2hpcHBpbmciLCJTRVRUSU5HIiwiU2V0dGluZyIsIm9uQ29sbGFwc2UiLCJjb25zb2xlIiwibG9nIiwiUm91dGVNZW51IiwiaXRlbSIsInR5cGUiLCJwYXlsb2FkIiwibWFwIiwiaW5kZXgiLCJTaWRlcnMiLCJOT0RFX0VOViIsIkhPU1QiLCJVUkwiLCJ0cmltIiwiQVBJIiwiQVVUSCIsIkdFVFBST0RVQ1QiLCJST1VURV9NRU5VIiwiS0VZX1NUT1JBR0UiLCJUSEVNRSIsIkxBTkciLCJpbml0aWFsU3RhdGUiLCJ1c2VyIiwidXNlclRva2VuIiwibGluayIsInN1Y2Nlc3MiLCJ3YXJuaW5nIiwiZXJyb3IiLCJ0b29sYmFyIiwib3V0bGluZSIsIndoaXRlIiwiY3JlYXRlQ29udGV4dCIsImxhbmdUSCIsIlRJVExFIiwiUmVjb21tZW5kZWRQcm9kdWN0cyIsIlNldExhbmd1YWdlIiwiaW5kZXhUSCIsImluZGV4RU4iLCJnZXRUSCIsImdldEVOIiwidG9VcHBlckNhc2UiLCJTd2l0Y2hDb21wb25lbnRzIiwicm91dGUiLCJBcnRpY2xlIiwiZHluYW1pYyIsImNhdGNoIiwiZXJyIiwibG9hZGluZyIsImp1c3RpZnlDb250ZW50IiwiU3RhdHVzV3JvbmciXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBOzs7UUFHQTs7UUFFQTtRQUNBO1FBQ0EsbUNBQW1DO1FBQ25DO1FBQ0E7UUFDQTtRQUNBO1FBQ0Esa0JBQWtCLHFCQUFxQjtRQUN2QztRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSxjQUFjO1FBQ2QsSUFBSTtRQUNKOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRWUsU0FBU0EsSUFBVCxHQUFnQjtBQUM3QixRQUFNO0FBQUVDO0FBQUYsTUFBWUMsd0RBQVUsQ0FBQ0Msb0RBQUQsQ0FBNUIsQ0FENkIsQ0FHN0I7QUFFQTs7QUFDQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLGdFQUFEO0FBQUEsOEJBQ0UscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUUscUVBQUMsZ0VBQUQ7QUFBQSxnQ0FDRSxxRUFBQywrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUscUVBQUMsaUVBQUQ7QUFBQSxpQ0FDRSxxRUFBQyxvRUFBRDtBQUFrQixpQkFBSyxFQUFFRixLQUFLLENBQUNHO0FBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREY7QUF5QkQsQzs7Ozs7Ozs7Ozs7QUN2Q0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQzs7Ozs7Ozs7Ozs7QUNwR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaERBO0FBQ0E7QUFDQTtBQU1lLFNBQVNDLFFBQVQsQ0FBa0I7QUFBQ0M7QUFBRCxDQUFsQixFQUFtRDtBQUM5RCxzQkFDSTtBQUFBLDJCQUNBLHFFQUFDLFFBQUQ7QUFBQSw2QkFDRTtBQUFLLGFBQUssRUFBRTtBQUFFQyxjQUFJLEVBQUUsQ0FBUjtBQUFXQyxlQUFLLEVBQUUsTUFBbEI7QUFBeUJDLGtCQUFRLEVBQUU7QUFBbkMsU0FBWjtBQUFBLGtCQUEyREg7QUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQSxtQkFESjtBQVFEO0FBQ0QsTUFBTUksUUFBUSxHQUFHQyx3REFBTSxDQUFDQywyQ0FBTSxDQUFDQyxPQUFSLENBQVQ7QUFBQTtBQUFBO0FBQUEsMkNBQWQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNO0FBQUVDLFFBQUY7QUFBVUMsUUFBVjtBQUFrQkMsT0FBbEI7QUFBeUJIO0FBQXpCLElBQXFDRCwyQ0FBM0M7QUFJZSxTQUFTSyxPQUFULENBQWlCLEVBQWpCLEVBQTBDO0FBQ3ZELFFBQU07QUFBRWhCO0FBQUYsTUFBWUMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FBNUI7QUFDQSxRQUFNO0FBQUEsT0FBQ2UsSUFBRDtBQUFBLE9BQU9DO0FBQVAsTUFBa0JDLHNEQUFRLENBQU0sSUFBTixDQUFoQztBQUNBLFFBQU07QUFBQSxPQUFDQyxNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQkYsc0RBQVEsQ0FBQyxLQUFELENBQXBDO0FBRUFHLHlEQUFTLENBQUMsTUFBTTtBQUNkSixXQUFPLENBQUNLLDREQUFRLENBQUN2QixLQUFLLENBQUN3QixRQUFQLENBQVQsQ0FBUDtBQUNBSCxhQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0QsR0FIUSxFQUdOLENBQUNyQixLQUFLLENBQUN3QixRQUFQLENBSE0sQ0FBVDtBQUtBRix5REFBUyxDQUFDLE1BQU0sQ0FBRSxDQUFULEVBQVcsQ0FBQ0wsSUFBRCxDQUFYLENBQVQ7O0FBRUEsUUFBTVEsSUFBSSxnQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFNBQUssRUFBRTtBQUFFbEIsV0FBSyxFQUFFO0FBQVQsS0FBYjtBQUFBLDRCQUNFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUFtQixVQUFJLGVBQUUscUVBQUMsOERBQUQ7QUFBYyxhQUFLLEVBQUU7QUFBRW1CLGtCQUFRLEVBQUU7QUFBWjtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQXpCO0FBQUE7QUFBQSxPQUFlLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBSUUscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQW1CLFVBQUksZUFBRSxxRUFBQyx3RUFBRDtBQUFhLGFBQUssRUFBRTtBQUFFQSxrQkFBUSxFQUFFO0FBQVo7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUF6QjtBQUFBO0FBQUEsT0FBZSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjs7QUFXQSxzQkFDRTtBQUFBLGNBQ0dOLE1BQU0saUJBQ0wscUVBQUMsT0FBRDtBQUFTLFdBQUssRUFBRXBCLEtBQUssQ0FBQzJCLEtBQXRCO0FBQUEsNkJBQ0UscUVBQUMsd0NBQUQ7QUFDRSxhQUFLLEVBQUU7QUFBRUMsZ0JBQU0sRUFBRSxNQUFWO0FBQWtCQyxpQkFBTyxFQUFFLE1BQTNCO0FBQW1DQyxvQkFBVSxFQUFFO0FBQS9DLFNBRFQ7QUFBQSxnQ0FHRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQVksZUFBSyxFQUFFO0FBQUVELG1CQUFPLEVBQUUsTUFBWDtBQUFtQkQsa0JBQU0sRUFBRTtBQUEzQixXQUFuQjtBQUFBLGlDQUNFLHFFQUFDLE1BQUQ7QUFBUSxlQUFHLEVBQUMsd0JBQVo7QUFBcUMsbUJBQU8sRUFBRTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFIRixlQU1FLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLEVBQVQ7QUFBYSxlQUFLLEVBQUU7QUFBRUMsbUJBQU8sRUFBRSxNQUFYO0FBQW1CQyxzQkFBVSxFQUFFO0FBQS9CLFdBQXBCO0FBQUEsa0NBQ0UscUVBQUMsMENBQUQ7QUFDRSx1QkFBVyxFQUFDLGNBRGQ7QUFFRSxpQkFBSyxFQUFFO0FBQUVDLDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUI7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBS0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFO0FBQUVELDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUIsYUFGVDtBQUdFLGdCQUFJLGVBQUUscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUFBLHNCQUtHZixJQUFJLENBQUNnQjtBQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5GLGVBbUJFLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBWSxlQUFLLEVBQUU7QUFBRUMscUJBQVMsRUFBRTtBQUFiLFdBQW5CO0FBQUEsa0NBQ0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFDLFFBRlI7QUFHRSxnQkFBSSxlQUFFLHFFQUFDLDZFQUFEO0FBQWEsbUJBQUssRUFBRTtBQUFFUix3QkFBUSxFQUFFO0FBQVo7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUlFLGlCQUFLLEVBQUU7QUFBRW5CLG1CQUFLLEVBQUUsRUFBVDtBQUFhcUIsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFPRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMscUVBQUQ7QUFBTSxtQkFBSyxFQUFFO0FBQUVGLHdCQUFRLEVBQUU7QUFBWjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSFI7QUFJRSxpQkFBSyxFQUFFO0FBQUVuQixtQkFBSyxFQUFFLEVBQVQ7QUFBYXFCLG9CQUFNLEVBQUU7QUFBckI7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVBGLGVBYUUscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFDLFFBRlI7QUFHRSxnQkFBSSxlQUFFLHFFQUFDLHlFQUFEO0FBQVUsbUJBQUssRUFBRTtBQUFFRix3QkFBUSxFQUFFO0FBQVo7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUlFLGlCQUFLLEVBQUU7QUFBRW5CLG1CQUFLLEVBQUUsRUFBVDtBQUFhcUIsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYkYsZUFtQkUscUVBQUMsNkNBQUQ7QUFBVSxtQkFBTyxFQUFFSCxJQUFuQjtBQUF5QixxQkFBUyxFQUFDLFlBQW5DO0FBQUEsbUNBQ0UscUVBQUMsMkNBQUQ7QUFDRSxrQkFBSSxFQUFDLFNBRFA7QUFFRSxtQkFBSyxFQUFDLFFBRlI7QUFHRSxrQkFBSSxlQUFFLHFFQUFDLDhFQUFEO0FBQWUscUJBQUssRUFBRTtBQUFFQywwQkFBUSxFQUFFO0FBQVo7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFIUjtBQUlFLG1CQUFLLEVBQUU7QUFBRW5CLHFCQUFLLEVBQUUsRUFBVDtBQUFhcUIsc0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSixtQkFERjtBQXdERDtBQUVELE1BQU1PLE9BQU8sR0FBR3pCLHdEQUFNLENBQUNHLE1BQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSwwVEFDUyxDQUFDO0FBQUVjO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNTLE9BRDlCLENBQWI7QUFjQSxNQUFNQyxNQUFNLEdBQUczQix3REFBTSxDQUFDNEIsMENBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxpREFBWixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0dBO0FBQ0E7QUFDQTtBQU1lLFNBQVNDLE9BQVQsQ0FBaUI7QUFBRWxDO0FBQUYsQ0FBakIsRUFBb0Q7QUFDakUsc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxPQUFEO0FBQVMsV0FBSyxFQUFFO0FBQUV1QixjQUFNLEVBQUU7QUFBVixPQUFoQjtBQUFBLGdCQUFzQ3ZCO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQUtEO0FBRUQsTUFBTW1DLE9BQU8sR0FBRzlCLHdEQUFNLENBQUNDLDJDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsMkpBQWIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCQTtBQUNBO0FBU0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJZSxTQUFTOEIsTUFBVCxDQUFnQixFQUFoQixFQUF5QztBQUN0RCxRQUFNO0FBQUV6QyxTQUFGO0FBQVMwQztBQUFULE1BQXNCekMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3lDLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCekIsc0RBQVEsRUFBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQzBCLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCM0Isc0RBQVEsQ0FBQyxLQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNGLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCQyxzREFBUSxDQUFNLElBQU4sQ0FBaEM7QUFFQSxRQUFNO0FBQUEsT0FBQzRCLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCN0Isc0RBQVEsQ0FBQztBQUN6QzRCLGFBQVMsRUFBRTtBQUQ4QixHQUFELENBQTFDO0FBR0F6Qix5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJMkIsS0FBSyxHQUFHMUIsNERBQVEsQ0FBQ3ZCLEtBQUssQ0FBQ3dCLFFBQVAsQ0FBcEI7QUFDQU4sV0FBTyxDQUFDK0IsS0FBRCxDQUFQO0FBQ0QsR0FIUSxFQUdOLENBQUNqRCxLQUFLLENBQUN3QixRQUFQLENBSE0sQ0FBVDtBQUtBLFFBQU0wQixTQUFTLEdBQUcsQ0FDaEI7QUFDRUMsT0FBRyxFQUFFQywyREFBSSxDQUFDQyxJQURaO0FBRUVDLFNBQUssRUFBRXJDLElBQUYsYUFBRUEsSUFBRix1QkFBRUEsSUFBSSxDQUFFbEIsSUFGZjtBQUdFd0QsUUFBSSxlQUFFLHFFQUFDLHFFQUFEO0FBQU0sV0FBSyxFQUFFO0FBQUU3QixnQkFBUSxFQUFFO0FBQVo7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FEZ0IsRUFNaEI7QUFDRXlCLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ0ksT0FEWjtBQUVFRixTQUFLLEVBQUVyQyxJQUFGLGFBQUVBLElBQUYsdUJBQUVBLElBQUksQ0FBRXdDLFdBRmY7QUFHRUYsUUFBSSxlQUFFLHFFQUFDLDBFQUFEO0FBQWMsV0FBSyxFQUFFO0FBQUU3QixnQkFBUSxFQUFFO0FBQVo7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBTmdCLEVBV2hCO0FBQ0V5QixPQUFHLEVBQUVDLDJEQUFJLENBQUNNLFlBRFo7QUFFRUosU0FBSyxFQUFFckMsSUFBRixhQUFFQSxJQUFGLHVCQUFFQSxJQUFJLENBQUUwQyxXQUZmO0FBR0VKLFFBQUksZUFBRSxxRUFBQyx5RkFBRDtBQUE4QixXQUFLLEVBQUU7QUFBRTdCLGdCQUFRLEVBQUU7QUFBWjtBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FYZ0IsRUFnQmhCO0FBQ0V5QixPQUFHLEVBQUVDLDJEQUFJLENBQUNRLE9BRFo7QUFFRU4sU0FBSyxFQUFFckMsSUFBRixhQUFFQSxJQUFGLHVCQUFFQSxJQUFJLENBQUU0QyxjQUZmO0FBR0VOLFFBQUksZUFBRSxxRUFBQyx3RUFBRDtBQUFhLFdBQUssRUFBRTtBQUFFN0IsZ0JBQVEsRUFBRTtBQUFaO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQWhCZ0IsRUFxQmhCO0FBQ0V5QixPQUFHLEVBQUVDLDJEQUFJLENBQUNVLFNBRFo7QUFFRVIsU0FBSyxFQUFFckMsSUFBRixhQUFFQSxJQUFGLHVCQUFFQSxJQUFJLENBQUU4QyxlQUZmO0FBR0VSLFFBQUksZUFBRSxxRUFBQyxzRkFBRDtBQUEwQixXQUFLLEVBQUU7QUFBRTdCLGdCQUFRLEVBQUU7QUFBWjtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FyQmdCLEVBMEJoQjtBQUNFeUIsT0FBRyxFQUFFQywyREFBSSxDQUFDWSxPQURaO0FBRUVWLFNBQUssRUFBRXJDLElBQUYsYUFBRUEsSUFBRix1QkFBRUEsSUFBSSxDQUFFZ0QsT0FGZjtBQUdFVixRQUFJLGVBQUUscUVBQUMsMkVBQUQ7QUFBZ0IsV0FBSyxFQUFFO0FBQUU3QixnQkFBUSxFQUFFO0FBQVo7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBMUJnQixDQUFsQjtBQWlDQUoseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSTRCLFNBQUosRUFBZTtBQUNiTixnQkFBVSxDQUFDTSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFDLEdBQWQsQ0FBVjtBQUNEOztBQUNETCxnQkFBWSxDQUFDLElBQUQsQ0FBWjtBQUNELEdBTFEsRUFLTixDQUFDOUMsS0FBSyxDQUFDd0IsUUFBUCxDQUxNLENBQVQ7O0FBT0EsUUFBTTBDLFVBQVUsR0FBSW5CLFNBQUQsSUFBZTtBQUNoQ29CLFdBQU8sQ0FBQ0MsR0FBUixDQUFZckIsU0FBWjtBQUNBQyxnQkFBWSxDQUFDO0FBQUVEO0FBQUYsS0FBRCxDQUFaO0FBQ0QsR0FIRDs7QUFLQSxRQUFNc0IsU0FBUyxHQUFJQyxJQUFELElBQVU7QUFDMUJILFdBQU8sQ0FBQ0MsR0FBUixDQUFZRSxJQUFaO0FBQ0E1QixZQUFRLENBQUM7QUFDUDZCLFVBQUksRUFBRSxlQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQckUsZ0JBQVEsRUFBRW1FLElBQUksQ0FBQ25CO0FBRFI7QUFGRixLQUFELENBQVI7QUFNQVAsY0FBVSxDQUFDMEIsSUFBSSxDQUFDbkIsR0FBTixDQUFWO0FBQ0QsR0FURDs7QUFXQTdCLHlEQUFTLENBQUMsTUFBTSxDQUFFLENBQVQsRUFBVyxDQUFDTCxJQUFELEVBQU9pQyxTQUFQLENBQVgsQ0FBVDtBQUVBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsTUFBRDtBQUNFLGlCQUFXLE1BRGI7QUFFRSxlQUFTLEVBQUVILFNBQVMsQ0FBQ0EsU0FGdkI7QUFHRSxnQkFBVSxFQUFFbUIsVUFIZDtBQUlFLFdBQUssRUFBRWxFLEtBQUssQ0FBQzJCLEtBSmY7QUFLRSxXQUFLLEVBQUUsR0FMVDtBQUFBLGdCQU9Ha0IsU0FBUyxpQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFlBQUksRUFBQyxRQUFYO0FBQW9CLDJCQUFtQixFQUFFLENBQUNGLE9BQUQsQ0FBekM7QUFBb0QsaUJBQVMsRUFBQyxNQUE5RDtBQUFBLGtCQUNHTyxTQUFTLENBQUN1QixHQUFWLENBQWMsQ0FBQ0gsSUFBRCxFQUFPSSxLQUFQLEtBQWlCO0FBQzlCLDhCQUNFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUVFLHFCQUFTLEVBQUMsV0FGWjtBQUdFLGdCQUFJLEVBQUVKLElBQUksQ0FBQ2YsSUFIYjtBQUlFLG1CQUFPLEVBQUUsTUFBTWMsU0FBUyxDQUFDQyxJQUFELENBSjFCO0FBQUEsc0JBTUdBLElBQUksQ0FBQ2hCO0FBTlIsYUFDT2dCLElBQUksQ0FBQ25CLEdBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQVVELFNBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBNEJEO0FBRUQsTUFBTXdCLE1BQU0sR0FBR2pFLHdEQUFNLENBQUNDLDJDQUFNLENBQUNJLEtBQVIsQ0FBVDtBQUFBO0FBQUE7QUFBQSxvNkJBRVUsQ0FBQztBQUFFWTtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDUyxPQUYvQixFQVdZLENBQUM7QUFBRVQ7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1MsT0FYakMsRUFjWSxDQUFDO0FBQUVUO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNTLE9BZGpDLEVBMEJDLENBQUM7QUFBRVQ7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1MsT0ExQnRCLEVBOEJDLENBQUM7QUFBRVQ7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1MsT0E5QnRCLEVBcUNDLENBQUM7QUFBRVQ7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1MsT0FyQ3RCLEVBdURjLENBQUM7QUFBRVQ7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ1MsT0F2RG5DLENBQVosQzs7Ozs7Ozs7Ozs7O0FDL0hBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTXdDLFFBQVEsZ0JBQWQ7QUFFTyxNQUFNQyxJQUFJLEdBQUc7QUFDbEJDLEtBQUcsRUFBRUYsUUFBUSxDQUFDRyxJQUFULE9BQW9CLGFBQXBCLEdBQW9DLHVCQUFwQyxHQUE4RCxFQURqRDtBQUVsQkMsS0FBRyxFQUFFO0FBQ0hDLFFBQUksRUFBRTtBQUNKQyxnQkFBVSxFQUFFO0FBRFI7QUFESDtBQUZhLENBQWI7QUFTQSxNQUFNQyxVQUFVLEdBQUc7QUFDeEI5QixNQUFJLEVBQUUsWUFEa0I7QUFFeEJHLFNBQU8sRUFBRSxlQUZlO0FBR3hCRSxjQUFZLEVBQUUsb0JBSFU7QUFJeEJFLFNBQU8sRUFBRSxlQUplO0FBS3hCRSxXQUFTLEVBQUUsaUJBTGE7QUFNeEJFLFNBQU8sRUFBRTtBQU5lLENBQW5CO0FBU0EsTUFBTW9CLFdBQVcsR0FBRztBQUN6QkMsT0FBSyxFQUFFLFdBRGtCO0FBRXpCQyxNQUFJLEVBQUU7QUFGbUIsQ0FBcEIsQzs7Ozs7Ozs7Ozs7O0FDcEJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVFTyxNQUFNQyxZQUEwQixHQUFHO0FBQ3hDQyxNQUFJLEVBQUUsSUFEa0M7QUFFeENoRSxVQUFRLEVBQUUsSUFGOEI7QUFHeENyQixVQUFRLEVBQUUsWUFIOEI7QUFJeENzRixXQUFTLEVBQUUsSUFKNkI7QUFLeEM5RCxPQUFLLEVBQUU7QUFDTDtBQUNBUyxXQUFPLEVBQUUsU0FGSjtBQUdMO0FBQ0E7QUFDQTtBQUNBO0FBQ0FzRCxRQUFJLEVBQUUsU0FQRDtBQVFMQyxXQUFPLEVBQUUsU0FSSjtBQVNMQyxXQUFPLEVBQUUsU0FUSjtBQVVMQyxTQUFLLEVBQUUsU0FWRjtBQVdMQyxXQUFPLEVBQUUsU0FYSjtBQVlMQyxXQUFPLEVBQUUsU0FaSjtBQWFMQyxTQUFLLEVBQUU7QUFiRjtBQUxpQyxDQUFuQztBQXNCQSxNQUFNOUYsT0FBTyxnQkFBRytGLDJEQUFhLENBQVcsSUFBWCxDQUE3QixDOzs7Ozs7Ozs7Ozs7QUM3RlA7QUFBQTtBQUFBLE1BQU1DLE1BQU0sR0FBRztBQUNiQyxPQUFLLEVBQUUsQ0FBQyxPQUFELEVBQVUsUUFBVixDQURNO0FBRWJDLHFCQUFtQixFQUFFLENBQUMsYUFBRCxFQUFnQixzQkFBaEI7QUFGUixDQUFmO0FBS08sTUFBTTdFLFFBQVEsR0FBSU4sSUFBRCxJQUFrQjtBQUN4QyxNQUFJb0YsV0FBZ0IsR0FBRyxFQUF2QjtBQUNBLE1BQUlDLE9BQU8sR0FBRyxDQUFkO0FBQ0EsTUFBSUMsT0FBTyxHQUFHLENBQWQ7QUFFQSxRQUFNaEYsUUFBUSxHQUFHO0FBQ2Z4QixRQUFJLEVBQUUsQ0FBQyxTQUFELEVBQVksTUFBWixDQURTO0FBRWYwRCxlQUFXLEVBQUUsQ0FBQyxZQUFELEVBQWUsY0FBZixDQUZFO0FBR2ZFLGVBQVcsRUFBRSxDQUFDLGdCQUFELEVBQW1CLGNBQW5CLENBSEU7QUFJZkUsa0JBQWMsRUFBRSxDQUFDLHVCQUFELEVBQTBCLGlCQUExQixDQUpEO0FBS2ZFLG1CQUFlLEVBQUUsQ0FBQyxtQkFBRCxFQUFzQixrQkFBdEIsQ0FMRjtBQU1mRSxXQUFPLEVBQUUsQ0FBQyxTQUFELEVBQVksU0FBWixDQU5NO0FBT2ZoQyxVQUFNLEVBQUUsQ0FBQyxPQUFELEVBQVUsUUFBVixDQVBPO0FBUWZtRSx1QkFBbUIsRUFBRSxDQUFDLGFBQUQsRUFBZ0Isc0JBQWhCO0FBUk4sR0FBakI7O0FBVUEsUUFBTUksS0FBSyxHQUFHLE1BQU07QUFDaEJILGVBQVcsQ0FBQ3RHLElBQVosR0FBbUJ3QixRQUFRLENBQUN4QixJQUFULENBQWN1RyxPQUFkLENBQW5CO0FBQ0FELGVBQVcsQ0FBQzVDLFdBQVosR0FBMEJsQyxRQUFRLENBQUNrQyxXQUFULENBQXFCNkMsT0FBckIsQ0FBMUI7QUFDQUQsZUFBVyxDQUFDMUMsV0FBWixHQUEwQnBDLFFBQVEsQ0FBQ29DLFdBQVQsQ0FBcUIyQyxPQUFyQixDQUExQjtBQUNBRCxlQUFXLENBQUN4QyxjQUFaLEdBQTZCdEMsUUFBUSxDQUFDc0MsY0FBVCxDQUF3QnlDLE9BQXhCLENBQTdCO0FBQ0FELGVBQVcsQ0FBQ3RDLGVBQVosR0FBOEJ4QyxRQUFRLENBQUN3QyxlQUFULENBQXlCdUMsT0FBekIsQ0FBOUI7QUFDQUQsZUFBVyxDQUFDcEMsT0FBWixHQUFzQjFDLFFBQVEsQ0FBQzBDLE9BQVQsQ0FBaUJxQyxPQUFqQixDQUF0QjtBQUNBRCxlQUFXLENBQUNwRSxNQUFaLEdBQXFCVixRQUFRLENBQUNVLE1BQVQsQ0FBZ0JxRSxPQUFoQixDQUFyQjtBQUNBRCxlQUFXLENBQUNELG1CQUFaLEdBQWtDN0UsUUFBUSxDQUFDNkUsbUJBQVQsQ0FBNkJFLE9BQTdCLENBQWxDO0FBQ0YsV0FBT0QsV0FBUDtBQUNELEdBVkQ7O0FBV0EsUUFBTUksS0FBSyxHQUFHLE1BQU07QUFDaEJKLGVBQVcsQ0FBQ3RHLElBQVosR0FBbUJ3QixRQUFRLENBQUN4QixJQUFULENBQWN3RyxPQUFkLENBQW5CO0FBQ0FGLGVBQVcsQ0FBQzVDLFdBQVosR0FBMEJsQyxRQUFRLENBQUNrQyxXQUFULENBQXFCOEMsT0FBckIsQ0FBMUI7QUFDQUYsZUFBVyxDQUFDMUMsV0FBWixHQUEwQnBDLFFBQVEsQ0FBQ29DLFdBQVQsQ0FBcUI0QyxPQUFyQixDQUExQjtBQUNBRixlQUFXLENBQUN4QyxjQUFaLEdBQTZCdEMsUUFBUSxDQUFDc0MsY0FBVCxDQUF3QjBDLE9BQXhCLENBQTdCO0FBQ0FGLGVBQVcsQ0FBQ3RDLGVBQVosR0FBOEJ4QyxRQUFRLENBQUN3QyxlQUFULENBQXlCd0MsT0FBekIsQ0FBOUI7QUFDQUYsZUFBVyxDQUFDcEMsT0FBWixHQUFzQjFDLFFBQVEsQ0FBQzBDLE9BQVQsQ0FBaUJzQyxPQUFqQixDQUF0QjtBQUNBRixlQUFXLENBQUNwRSxNQUFaLEdBQXFCVixRQUFRLENBQUNVLE1BQVQsQ0FBZ0JzRSxPQUFoQixDQUFyQjtBQUNBRixlQUFXLENBQUNELG1CQUFaLEdBQWtDN0UsUUFBUSxDQUFDNkUsbUJBQVQsQ0FBNkJHLE9BQTdCLENBQWxDO0FBQ0YsV0FBT0YsV0FBUDtBQUNELEdBVkQ7O0FBWUEsTUFBSXBGLElBQUksQ0FBQ3lGLFdBQUwsTUFBc0IsSUFBMUIsRUFBZ0M7QUFDOUIsV0FBT0YsS0FBSyxFQUFaO0FBQ0Q7O0FBQ0QsU0FBT0MsS0FBSyxFQUFaO0FBQ0QsQ0ExQ00sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTFA7QUFDQTs7QUFLQSxNQUFNRSxnQkFBZ0IsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFzQjtBQUM3QyxNQUFJO0FBQ0YsVUFBTUMsT0FBTyxHQUFHQyxtREFBTyxDQUNyQixNQUNFLGtFQUFRLEtBQWdCRixLQUFNLEVBQTlCLEVBQWlDRyxLQUFqQyxDQUF3Q0MsR0FBRCxJQUFTO0FBQzlDLGFBQU8sbUJBQU0scUVBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFiO0FBQ0QsS0FGRCxDQUZtQixFQUtyQjtBQUNFQyxhQUFPLEVBQUUsbUJBQ1A7QUFDRSxhQUFLLEVBQUU7QUFDTDFHLGVBQUssRUFBRSxNQURGO0FBRUxxQixnQkFBTSxFQUFFLE1BRkg7QUFHTEMsaUJBQU8sRUFBRSxNQUhKO0FBSUxxRix3QkFBYyxFQUFFLFFBSlg7QUFLTHBGLG9CQUFVLEVBQUU7QUFMUCxTQURUO0FBQUEsK0JBU0UscUVBQUMseUNBQUQ7QUFBTSxhQUFHLEVBQUM7QUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSjtBQUFBO0FBQUEsNENBSFUsK0VBQWdCOEUsS0FBTSxFQUdoQztBQUFBLGtCQUhVLGlCQUFnQkEsS0FBTSxFQUdoQztBQUFBO0FBQUEsS0FMcUIsQ0FBdkI7QUFxQkEsd0JBQU8scUVBQUMsT0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFQO0FBQ0QsR0F2QkQsQ0F1QkUsT0FBT2YsS0FBUCxFQUFjO0FBQ2Qsd0JBQU8scUVBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFQO0FBQ0Q7QUFDRixDQTNCRDs7QUE2QkEsTUFBTXNCLFdBQVcsR0FBRyxtQkFDbEIscUVBQUMsMkNBQUQ7QUFBUSxRQUFNLEVBQUMsS0FBZjtBQUFxQixPQUFLLEVBQUMsS0FBM0I7QUFBaUMsVUFBUSxFQUFDO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjs7QUFHZVIsK0VBQWYsRTs7Ozs7Ozs7Ozs7QUN0Q0EsOEQ7Ozs7Ozs7Ozs7O0FDQUEsb0U7Ozs7Ozs7Ozs7O0FDQUEsa0U7Ozs7Ozs7Ozs7O0FDQUEsMkQ7Ozs7Ozs7Ozs7O0FDQUEsaUU7Ozs7Ozs7Ozs7O0FDQUEsK0U7Ozs7Ozs7Ozs7O0FDQUEsOEQ7Ozs7Ozs7Ozs7O0FDQUEsMkQ7Ozs7Ozs7Ozs7O0FDQUEsK0Q7Ozs7Ozs7Ozs7O0FDQUEsMkU7Ozs7Ozs7Ozs7O0FDQUEsK0Q7Ozs7Ozs7Ozs7O0FDQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsaUM7Ozs7Ozs7Ozs7O0FDQUEseUM7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsa0Q7Ozs7Ozs7Ozs7O0FDQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsNkMiLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBjaHVua3NcbiBcdC8vIFwiMFwiIG1lYW5zIFwiYWxyZWFkeSBsb2FkZWRcIlxuIFx0dmFyIGluc3RhbGxlZENodW5rcyA9IHtcbiBcdFx0XCJwYWdlcy9pbmRleFwiOiAwXG4gXHR9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuIFx0Ly8gVGhpcyBmaWxlIGNvbnRhaW5zIG9ubHkgdGhlIGVudHJ5IGNodW5rLlxuIFx0Ly8gVGhlIGNodW5rIGxvYWRpbmcgZnVuY3Rpb24gZm9yIGFkZGl0aW9uYWwgY2h1bmtzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmUgPSBmdW5jdGlvbiByZXF1aXJlRW5zdXJlKGNodW5rSWQpIHtcbiBcdFx0dmFyIHByb21pc2VzID0gW107XG5cblxuIFx0XHQvLyByZXF1aXJlKCkgY2h1bmsgbG9hZGluZyBmb3IgamF2YXNjcmlwdFxuXG4gXHRcdC8vIFwiMFwiIGlzIHRoZSBzaWduYWwgZm9yIFwiYWxyZWFkeSBsb2FkZWRcIlxuIFx0XHRpZihpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gIT09IDApIHtcbiBcdFx0XHR2YXIgY2h1bmsgPSByZXF1aXJlKFwiLi4vXCIgKyAoe31bY2h1bmtJZF18fGNodW5rSWQpICsgXCIuanNcIik7XG4gXHRcdFx0dmFyIG1vcmVNb2R1bGVzID0gY2h1bmsubW9kdWxlcywgY2h1bmtJZHMgPSBjaHVuay5pZHM7XG4gXHRcdFx0Zm9yKHZhciBtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuIFx0XHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdFx0fVxuIFx0XHRcdGZvcih2YXIgaSA9IDA7IGkgPCBjaHVua0lkcy5sZW5ndGg7IGkrKylcbiBcdFx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkc1tpXV0gPSAwO1xuIFx0XHR9XG4gXHRcdHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcyk7XG4gXHR9O1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIHVuY2F1Z2h0IGVycm9yIGhhbmRsZXIgZm9yIHdlYnBhY2sgcnVudGltZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vZSA9IGZ1bmN0aW9uKGVycikge1xuIFx0XHRwcm9jZXNzLm5leHRUaWNrKGZ1bmN0aW9uKCkge1xuIFx0XHRcdHRocm93IGVycjsgLy8gY2F0Y2ggdGhpcyBlcnJvciBieSB1c2luZyBpbXBvcnQoKS5jYXRjaCgpXG4gXHRcdH0pO1xuIFx0fTtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9wYWdlcy9pbmRleC50c3hcIik7XG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlQ29udGV4dCwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgQ0xheW91dCBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvYy1sYXlvdXRcIjtcbmltcG9ydCBDSGVhZGVyIGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9jLWhlYWRlclwiO1xuaW1wb3J0IENTaWRlciBmcm9tIFwiLi4vc3JjL2NvbXBvbmVudHMvYy1zaWRlclwiO1xuaW1wb3J0IFN3aXRjaENvbXBvbmVudHMgZnJvbSBcIi4uL3NyYy91dGlscy9zd2l0Y2gtY29tcG9uZW50c1wiO1xuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi9zcmMvY29udGV4dFwiO1xuaW1wb3J0IENDb250ZW50IGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9jLWNvbnRlbnRcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgeyBzdGF0ZSB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcblxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xuICBcbiAgLy8gfSwgW10pXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxDTGF5b3V0PlxuICAgICAgICA8Q0hlYWRlciAvPlxuICAgICAgICA8Q0xheW91dD5cbiAgICAgICAgICA8Q1NpZGVyIC8+XG4gICAgICAgICAgPENDb250ZW50PlxuICAgICAgICAgICAgPFN3aXRjaENvbXBvbmVudHMgcm91dGU9e3N0YXRlLnJvdXRNZW51fSAvPlxuICAgICAgICAgIDwvQ0NvbnRlbnQ+XG4gICAgICAgIDwvQ0xheW91dD5cbiAgICAgIDwvQ0xheW91dD5cbiAgICAgIDxzdHlsZSBqc3ggZ2xvYmFsPntgXG4gICAgICAgIGh0bWwsXG4gICAgICAgIGJvZHkge1xuICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgIGZvbnQtZmFtaWx5OiBcIkthbml0XCIsIHNhbnMtc2VyaWY7XG4gICAgICAgIH1cblxuICAgICAgICAqIHtcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgICB9XG4gICAgICBgfTwvc3R5bGU+XG4gICAgPC8+XG4gICk7XG59XG4iLCJ2YXIgbWFwID0ge1xuXHRcIi4vYy1jb250ZW50XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvYy1jb250ZW50LnRzeFwiXG5cdF0sXG5cdFwiLi9jLWNvbnRlbnQudHN4XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvYy1jb250ZW50LnRzeFwiXG5cdF0sXG5cdFwiLi9jLWZvb3RlclwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL2MtZm9vdGVyLnRzeFwiLFxuXHRcdDFcblx0XSxcblx0XCIuL2MtZm9vdGVyLnRzeFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL2MtZm9vdGVyLnRzeFwiLFxuXHRcdDFcblx0XSxcblx0XCIuL2MtaGVhZGVyXCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvYy1oZWFkZXIudHN4XCJcblx0XSxcblx0XCIuL2MtaGVhZGVyLnRzeFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL2MtaGVhZGVyLnRzeFwiXG5cdF0sXG5cdFwiLi9jLWxheW91dFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL2MtbGF5b3V0LnRzeFwiXG5cdF0sXG5cdFwiLi9jLWxheW91dC50c3hcIjogW1xuXHRcdFwiLi9zcmMvY29tcG9uZW50cy9jLWxheW91dC50c3hcIlxuXHRdLFxuXHRcIi4vYy1zaWRlclwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL2Mtc2lkZXIudHN4XCJcblx0XSxcblx0XCIuL2Mtc2lkZXIudHN4XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvYy1zaWRlci50c3hcIlxuXHRdLFxuXHRcIi4vcGFnZXMvaGlzdG9yeVwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2hpc3RvcnkudHN4XCIsXG5cdFx0MlxuXHRdLFxuXHRcIi4vcGFnZXMvaGlzdG9yeS50c3hcIjogW1xuXHRcdFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9oaXN0b3J5LnRzeFwiLFxuXHRcdDJcblx0XSxcblx0XCIuL3BhZ2VzL2hvbWVcIjogW1xuXHRcdFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9ob21lLnRzeFwiLFxuXHRcdDNcblx0XSxcblx0XCIuL3BhZ2VzL2hvbWUudHN4XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvaG9tZS50c3hcIixcblx0XHQzXG5cdF0sXG5cdFwiLi9wYWdlcy9saXN0LXByb2R1Y3RcIjogW1xuXHRcdFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9saXN0LXByb2R1Y3QudHN4XCIsXG5cdFx0NFxuXHRdLFxuXHRcIi4vcGFnZXMvbGlzdC1wcm9kdWN0LnRzeFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2xpc3QtcHJvZHVjdC50c3hcIixcblx0XHQ0XG5cdF0sXG5cdFwiLi9wYWdlcy9wcm9kdWN0XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvcHJvZHVjdC50c3hcIixcblx0XHQ1XG5cdF0sXG5cdFwiLi9wYWdlcy9wcm9kdWN0LnRzeFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL3Byb2R1Y3QudHN4XCIsXG5cdFx0NVxuXHRdLFxuXHRcIi4vcGFnZXMvc2V0dGluZ1wiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL3NldHRpbmcudHN4XCIsXG5cdFx0MFxuXHRdLFxuXHRcIi4vcGFnZXMvc2V0dGluZy50c3hcIjogW1xuXHRcdFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9zZXR0aW5nLnRzeFwiLFxuXHRcdDBcblx0XSxcblx0XCIuL3BhZ2VzL3RyYW5zcG9ydFwiOiBbXG5cdFx0XCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL3RyYW5zcG9ydC50c3hcIixcblx0XHQ2XG5cdF0sXG5cdFwiLi9wYWdlcy90cmFuc3BvcnQudHN4XCI6IFtcblx0XHRcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvdHJhbnNwb3J0LnRzeFwiLFxuXHRcdDZcblx0XVxufTtcbmZ1bmN0aW9uIHdlYnBhY2tBc3luY0NvbnRleHQocmVxKSB7XG5cdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8obWFwLCByZXEpKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0XHRlLmNvZGUgPSAnTU9EVUxFX05PVF9GT1VORCc7XG5cdFx0XHR0aHJvdyBlO1xuXHRcdH0pO1xuXHR9XG5cblx0dmFyIGlkcyA9IG1hcFtyZXFdLCBpZCA9IGlkc1swXTtcblx0cmV0dXJuIFByb21pc2UuYWxsKGlkcy5zbGljZSgxKS5tYXAoX193ZWJwYWNrX3JlcXVpcmVfXy5lKSkudGhlbihmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhpZCk7XG5cdH0pO1xufVxud2VicGFja0FzeW5jQ29udGV4dC5rZXlzID0gZnVuY3Rpb24gd2VicGFja0FzeW5jQ29udGV4dEtleXMoKSB7XG5cdHJldHVybiBPYmplY3Qua2V5cyhtYXApO1xufTtcbndlYnBhY2tBc3luY0NvbnRleHQuaWQgPSBcIi4vc3JjL2NvbXBvbmVudHMgbGF6eSByZWN1cnNpdmUgXlxcXFwuXFxcXC8uKiRcIjtcbm1vZHVsZS5leHBvcnRzID0gd2VicGFja0FzeW5jQ29udGV4dDsiLCJ2YXIgbWFwID0ge1xuXHRcIi4vYy1jb250ZW50XCI6IFwiLi9zcmMvY29tcG9uZW50cy9jLWNvbnRlbnQudHN4XCIsXG5cdFwiLi9jLWNvbnRlbnQudHN4XCI6IFwiLi9zcmMvY29tcG9uZW50cy9jLWNvbnRlbnQudHN4XCIsXG5cdFwiLi9jLWZvb3RlclwiOiBcIi4vc3JjL2NvbXBvbmVudHMvYy1mb290ZXIudHN4XCIsXG5cdFwiLi9jLWZvb3Rlci50c3hcIjogXCIuL3NyYy9jb21wb25lbnRzL2MtZm9vdGVyLnRzeFwiLFxuXHRcIi4vYy1oZWFkZXJcIjogXCIuL3NyYy9jb21wb25lbnRzL2MtaGVhZGVyLnRzeFwiLFxuXHRcIi4vYy1oZWFkZXIudHN4XCI6IFwiLi9zcmMvY29tcG9uZW50cy9jLWhlYWRlci50c3hcIixcblx0XCIuL2MtbGF5b3V0XCI6IFwiLi9zcmMvY29tcG9uZW50cy9jLWxheW91dC50c3hcIixcblx0XCIuL2MtbGF5b3V0LnRzeFwiOiBcIi4vc3JjL2NvbXBvbmVudHMvYy1sYXlvdXQudHN4XCIsXG5cdFwiLi9jLXNpZGVyXCI6IFwiLi9zcmMvY29tcG9uZW50cy9jLXNpZGVyLnRzeFwiLFxuXHRcIi4vYy1zaWRlci50c3hcIjogXCIuL3NyYy9jb21wb25lbnRzL2Mtc2lkZXIudHN4XCIsXG5cdFwiLi9wYWdlcy9oaXN0b3J5XCI6IFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9oaXN0b3J5LnRzeFwiLFxuXHRcIi4vcGFnZXMvaGlzdG9yeS50c3hcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2hpc3RvcnkudHN4XCIsXG5cdFwiLi9wYWdlcy9ob21lXCI6IFwiLi9zcmMvY29tcG9uZW50cy9wYWdlcy9ob21lLnRzeFwiLFxuXHRcIi4vcGFnZXMvaG9tZS50c3hcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2hvbWUudHN4XCIsXG5cdFwiLi9wYWdlcy9saXN0LXByb2R1Y3RcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2xpc3QtcHJvZHVjdC50c3hcIixcblx0XCIuL3BhZ2VzL2xpc3QtcHJvZHVjdC50c3hcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL2xpc3QtcHJvZHVjdC50c3hcIixcblx0XCIuL3BhZ2VzL3Byb2R1Y3RcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL3Byb2R1Y3QudHN4XCIsXG5cdFwiLi9wYWdlcy9wcm9kdWN0LnRzeFwiOiBcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvcHJvZHVjdC50c3hcIixcblx0XCIuL3BhZ2VzL3NldHRpbmdcIjogXCIuL3NyYy9jb21wb25lbnRzL3BhZ2VzL3NldHRpbmcudHN4XCIsXG5cdFwiLi9wYWdlcy9zZXR0aW5nLnRzeFwiOiBcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3hcIixcblx0XCIuL3BhZ2VzL3RyYW5zcG9ydFwiOiBcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvdHJhbnNwb3J0LnRzeFwiLFxuXHRcIi4vcGFnZXMvdHJhbnNwb3J0LnRzeFwiOiBcIi4vc3JjL2NvbXBvbmVudHMvcGFnZXMvdHJhbnNwb3J0LnRzeFwiXG59O1xuXG5cbmZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0KHJlcSkge1xuXHR2YXIgaWQgPSB3ZWJwYWNrQ29udGV4dFJlc29sdmUocmVxKTtcblx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubVtpZF0pIHtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIk1vZHVsZSAnXCIgKyByZXEgKyBcIicgKCdcIiArIGlkICsgXCInKSBpcyBub3QgYXZhaWxhYmxlICh3ZWFrIGRlcGVuZGVuY3kpXCIpO1xuXHRcdGUuY29kZSA9ICdNT0RVTEVfTk9UX0ZPVU5EJztcblx0XHR0aHJvdyBlO1xuXHR9XG5cdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKGlkKTtcbn1cbmZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0UmVzb2x2ZShyZXEpIHtcblx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhtYXAsIHJlcSkpIHtcblx0XHR2YXIgZSA9IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIgKyByZXEgKyBcIidcIik7XG5cdFx0ZS5jb2RlID0gJ01PRFVMRV9OT1RfRk9VTkQnO1xuXHRcdHRocm93IGU7XG5cdH1cblx0cmV0dXJuIG1hcFtyZXFdO1xufVxud2VicGFja0NvbnRleHQua2V5cyA9IGZ1bmN0aW9uIHdlYnBhY2tDb250ZXh0S2V5cygpIHtcblx0cmV0dXJuIE9iamVjdC5rZXlzKG1hcCk7XG59O1xud2VicGFja0NvbnRleHQucmVzb2x2ZSA9IHdlYnBhY2tDb250ZXh0UmVzb2x2ZTtcbndlYnBhY2tDb250ZXh0LmlkID0gXCIuL3NyYy9jb21wb25lbnRzIHdlYWsgcmVjdXJzaXZlIF5cXFxcLlxcXFwvLiokXCI7XG5tb2R1bGUuZXhwb3J0cyA9IHdlYnBhY2tDb250ZXh0OyIsImltcG9ydCB7IExheW91dCB9IGZyb20gJ2FudGQnO1xyXG5pbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHtcclxuICAgIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENDb250ZW50KHtjaGlsZHJlbn06IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICA8Q29udGVudHM+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIHdpZHRoOiBcIjEwMCVcIixvdmVyZmxvdzogJ2hpZGRlbid9fT57Y2hpbGRyZW59PC9kaXY+XHJcbiAgICAgICAgICB7LyogPEJIRm9vdGVyIC8+ICovfVxyXG4gICAgICAgIDwvQ29udGVudHM+XHJcbiAgICAgIDwvPlxyXG4gICAgKTtcclxuICB9XHJcbiAgY29uc3QgQ29udGVudHMgPSBzdHlsZWQoTGF5b3V0LkNvbnRlbnQpYFxyXG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogIzk5OTsgKi9cclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGA7XHJcbiAgXHJcbiIsImltcG9ydCB7IENvbCwgUm93LCBMYXlvdXQsIElucHV0LCBCdXR0b24sIEltYWdlLCBEcm9wZG93biwgTWVudSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQXVkaW9PdXRsaW5lZCwgU2VhcmNoT3V0bGluZWQsIFVzZXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRcIjtcclxuaW1wb3J0IEFjY291bnRJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0FjY291bnRcIjtcclxuaW1wb3J0IEFjY291bnRDaXJjbGUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudENpcmNsZVwiO1xyXG5pbXBvcnQgQ2FydCBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9DYXJ0XCI7XHJcbmltcG9ydCBWaWV3R3JpZCBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9WaWV3R3JpZFwiO1xyXG5pbXBvcnQgQmVsbE91dGxpbmUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQmVsbE91dGxpbmVcIjtcclxuaW1wb3J0IHsgTGFuZ3VhZ2UgfSBmcm9tIFwiLi4vbGFuZ3VhZ2VzXCI7XHJcblxyXG5jb25zdCB7IEhlYWRlciwgRm9vdGVyLCBTaWRlciwgQ29udGVudCB9ID0gTGF5b3V0O1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDSGVhZGVyKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KG51bGwpO1xyXG4gIGNvbnN0IFtpc0xvYWQsIHNldGlzTG9hZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRsYW5nKExhbmd1YWdlKHN0YXRlLmxhbmd1YWdlKSk7XHJcbiAgICBzZXRpc0xvYWQodHJ1ZSk7XHJcbiAgfSwgW3N0YXRlLmxhbmd1YWdlXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7fSwgW2xhbmddKTtcclxuXHJcbiAgY29uc3QgbWVudSA9IChcclxuICAgIDxNZW51IHN0eWxlPXt7IHdpZHRoOiAyMDAgfX0+XHJcbiAgICAgIDxNZW51Lkl0ZW0ga2V5PVwiMVwiIGljb249ezxVc2VyT3V0bGluZWQgc3R5bGU9e3sgZm9udFNpemU6IDIwIH19IC8+fT5cclxuICAgICAgICBQcm9maWxlXHJcbiAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICA8TWVudS5JdGVtIGtleT1cIjFcIiBpY29uPXs8QWNjb3VudEljb24gc3R5bGU9e3sgZm9udFNpemU6IDIwIH19IC8+fT5cclxuICAgICAgICBMb2dvdXRcclxuICAgICAgPC9NZW51Lkl0ZW0+XHJcbiAgICA8L01lbnU+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtpc0xvYWQgJiYgKFxyXG4gICAgICAgIDxIZWFkZXJzIHRoZW1lPXtzdGF0ZS50aGVtZX0+XHJcbiAgICAgICAgICA8Um93XHJcbiAgICAgICAgICAgIHN0eWxlPXt7IGhlaWdodDogXCIxMDAlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxDb2wgbWQ9ezZ9IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBoZWlnaHQ6IFwiMTAwJVwiIH19PlxyXG4gICAgICAgICAgICAgIDxJbWFnZXMgc3JjPVwiL2ltYWdlcy9zaG9wcGluZ18xLnBuZ1wiIHByZXZpZXc9e2ZhbHNlfSAvPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgPENvbCBtZD17MTJ9IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJTlBVVCBTRUFSQ0hcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwLCBib3hTaGFkb3c6IFwiMHB4IDBweCAycHggIzAwMDAwMFwiIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDAsIGJveFNoYWRvdzogXCIwcHggMHB4IDJweCAjMDAwMDAwXCIgfX1cclxuICAgICAgICAgICAgICAgIGljb249ezxTZWFyY2hPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7bGFuZy5TZWFyY2h9XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICA8Q29sIG1kPXs2fSBzdHlsZT17eyB0ZXh0QWxpZ246IFwiZW5kXCIgfX0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgc2hhcGU9XCJjaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PEJlbGxPdXRsaW5lIHN0eWxlPXt7IGZvbnRTaXplOiAzMCB9fSAvPn1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgc2hhcGU9XCJjaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PENhcnQgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaGFwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8Vmlld0dyaWQgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8RHJvcGRvd24gb3ZlcmxheT17bWVudX0gcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PEFjY291bnRDaXJjbGUgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTAsIGhlaWdodDogNTAgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICA8L0hlYWRlcnM+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBIZWFkZXJzID0gc3R5bGVkKEhlYWRlcilgXHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBib3gtc2hhZG93OiAwcHggMHB4IDVweCAjMDAwMDAwO1xyXG4gIHBhZGRpbmc6IDBweDtcclxuICBoZWlnaHQ6IDgwcHg7XHJcbiAgLyogZGlzcGxheTogZmxleDsgKi9cclxuICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gIHRvcDogMHB4O1xyXG4gIHotaW5kZXg6IDM7XHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG5cclxuY29uc3QgSW1hZ2VzID0gc3R5bGVkKEltYWdlKWBcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgd2lkdGg6IDEwMHB4O1xyXG4gIHBhZGRpbmctbGVmdDogMHB4O1xyXG5gO1xyXG4iLCJpbXBvcnQgeyBMYXlvdXQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENMYXlvdXQoeyBjaGlsZHJlbiB9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxMYXlvdXRzIHN0eWxlPXt7IGhlaWdodDogXCIxMDB2aFwiIH19PntjaGlsZHJlbn08L0xheW91dHM+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBMYXlvdXRzID0gc3R5bGVkKExheW91dClgXHJcbiAgI2NvbXBvbmVudHMtbGF5b3V0LWRlbW8tc2lkZSAubG9nbyB7XHJcbiAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICBtYXJnaW46IDE2cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMyk7XHJcbiAgfVxyXG5cclxuICAuc2l0ZS1sYXlvdXQgLnNpdGUtbGF5b3V0LWJhY2tncm91bmQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICB9XHJcbmA7XHJcbiIsImltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnJlYWRjcnVtYiwgTGF5b3V0LCBNZW51IH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgRGVza3RvcE91dGxpbmVkLFxyXG4gIFBpZUNoYXJ0T3V0bGluZWQsXHJcbiAgRmlsZU91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBVc2VyT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gXCJhbnRkL2xpYi9sYXlvdXQvbGF5b3V0XCI7XHJcbmltcG9ydCBTdWJNZW51IGZyb20gXCJhbnRkL2xpYi9tZW51L1N1Yk1lbnVcIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi9jb250ZXh0XCI7XHJcbmltcG9ydCB7IFJPVVRFX01FTlUgYXMgTUVOVSB9IGZyb20gXCIuLi9jb25zdGFudHMvaW5kZXhcIjtcclxuaW1wb3J0IEhvbWUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSG9tZVwiO1xyXG5pbXBvcnQgSGlzdG9yeUljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSGlzdG9yeVwiO1xyXG5pbXBvcnQgRm9ybWF0TGlzdEJ1bGxldGVkU3F1YXJlSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9Gb3JtYXRMaXN0QnVsbGV0ZWRTcXVhcmVcIjtcclxuaW1wb3J0IENvZ091dGxpbmVJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NvZ091dGxpbmVcIjtcclxuaW1wb3J0IFRydWNrRGVsaXZlcnlPdXRsaW5lSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9UcnVja0RlbGl2ZXJ5T3V0bGluZVwiO1xyXG5pbXBvcnQgU2hvcHBpbmdJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1Nob3BwaW5nXCI7XHJcbmltcG9ydCB7IExhbmd1YWdlIH0gZnJvbSBcIi4uL2xhbmd1YWdlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDU2lkZXIoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlLCBkaXNwYXRjaCB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICBjb25zdCBbbWVudUtleSwgc2V0TWVudUtleV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KG51bGwpO1xyXG5cclxuICBjb25zdCBbY29sbGFwc2VkLCBzZXRDb2xsYXBzZWRdID0gdXNlU3RhdGUoe1xyXG4gICAgY29sbGFwc2VkOiBmYWxzZSxcclxuICB9KTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IGxhbmdzID0gTGFuZ3VhZ2Uoc3RhdGUubGFuZ3VhZ2UpO1xyXG4gICAgc2V0bGFuZyhsYW5ncyk7XHJcbiAgfSwgW3N0YXRlLmxhbmd1YWdlXSk7XHJcblxyXG4gIGNvbnN0IE1JU1RfTUVOVSA9IFtcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhPTUUsXHJcbiAgICAgIHRpdGxlOiBsYW5nPy5Ib21lLFxyXG4gICAgICBpY29uOiA8SG9tZSBzdHlsZT17eyBmb250U2l6ZTogMjUgfX0gLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IE1FTlUuUFJPRFVDVCxcclxuICAgICAgdGl0bGU6IGxhbmc/LlByb2R1Y3RUeXBlLFxyXG4gICAgICBpY29uOiA8U2hvcHBpbmdJY29uIHN0eWxlPXt7IGZvbnRTaXplOiAyNSB9fSAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogTUVOVS5MSVNUX1BST0RVQ1QsXHJcbiAgICAgIHRpdGxlOiBsYW5nPy5Qcm9kdWN0TGlzdCxcclxuICAgICAgaWNvbjogPEZvcm1hdExpc3RCdWxsZXRlZFNxdWFyZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhJU1RPUlksXHJcbiAgICAgIHRpdGxlOiBsYW5nPy5Qcm9kdWN0SGlzdG9yeSxcclxuICAgICAgaWNvbjogPEhpc3RvcnlJY29uIHN0eWxlPXt7IGZvbnRTaXplOiAyNSB9fSAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogTUVOVS5UUkFOU1BPUlQsXHJcbiAgICAgIHRpdGxlOiBsYW5nPy5Qcm9kdWN0U2hpcHBpbmcsXHJcbiAgICAgIGljb246IDxUcnVja0RlbGl2ZXJ5T3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlNFVFRJTkcsXHJcbiAgICAgIHRpdGxlOiBsYW5nPy5TZXR0aW5nLFxyXG4gICAgICBpY29uOiA8Q29nT3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKE1JU1RfTUVOVSkge1xyXG4gICAgICBzZXRNZW51S2V5KE1JU1RfTUVOVVswXS5rZXkpO1xyXG4gICAgfVxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gIH0sIFtzdGF0ZS5sYW5ndWFnZV0pO1xyXG5cclxuICBjb25zdCBvbkNvbGxhcHNlID0gKGNvbGxhcHNlZCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coY29sbGFwc2VkKTtcclxuICAgIHNldENvbGxhcHNlZCh7IGNvbGxhcHNlZCB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBSb3V0ZU1lbnUgPSAoaXRlbSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coaXRlbSk7XHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1JPVVRfTVVOVVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcm91dE1lbnU6IGl0ZW0ua2V5LFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBzZXRNZW51S2V5KGl0ZW0ua2V5KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge30sIFtsYW5nLCBNSVNUX01FTlVdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxTaWRlcnNcclxuICAgICAgICBjb2xsYXBzaWJsZVxyXG4gICAgICAgIGNvbGxhcHNlZD17Y29sbGFwc2VkLmNvbGxhcHNlZH1cclxuICAgICAgICBvbkNvbGxhcHNlPXtvbkNvbGxhcHNlfVxyXG4gICAgICAgIHRoZW1lPXtzdGF0ZS50aGVtZX1cclxuICAgICAgICB3aWR0aD17MjUwfVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8TWVudSBtb2RlPVwiaW5saW5lXCIgZGVmYXVsdFNlbGVjdGVkS2V5cz17W21lbnVLZXldfSBjbGFzc05hbWU9XCJNZW51XCI+XHJcbiAgICAgICAgICAgIHtNSVNUX01FTlUubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8TWVudS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5rZXl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGVyTWVudVwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gUm91dGVNZW51KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvU2lkZXJzPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgU2lkZXJzID0gc3R5bGVkKExheW91dC5TaWRlcilgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggIzAwMDAwMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgLmFudC1tZW51LWlubGluZSAuYW50LW1lbnUtaXRlbTpub3QoOmxhc3QtY2hpbGQpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXZlcnRpY2FsIC5hbnQtbWVudS1pdGVtOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuICAuYW50LWxheW91dC1zaWRlci10cmlnZ2VyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgfVxyXG4gIC5hbnQtbWVudTpub3QoLmFudC1tZW51LWhvcml6b250YWwpIC5hbnQtbWVudS1pdGVtLXNlbGVjdGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXN1Ym1lbnUgPiAuYW50LW1lbnUtc3VibWVudS10aXRsZSB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIC5hbnQtbWVudS1zdWJtZW51LWFycm93IHtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuICAuc2lkZXJNZW51IHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMjRweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcblxyXG4gIC5NZW51IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgd2lkdGg6IDEwcHg7XHJcbiAgICB9XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG4iLCJjb25zdCBOT0RFX0VOViA9IHByb2Nlc3MuZW52Lk5PREVfRU5WO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhPU1QgPSB7XHJcbiAgVVJMOiBOT0RFX0VOVi50cmltKCkgPT09IFwiZGV2ZWxvcG1lbnRcIiA/IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwXCIgOiBcIlwiLFxyXG4gIEFQSToge1xyXG4gICAgQVVUSDoge1xyXG4gICAgICBHRVRQUk9EVUNUOiBcIi9hcGkvcHJvZHVjdFwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFJPVVRFX01FTlUgPSB7XHJcbiAgSE9NRTogXCJwYWdlcy9ob21lXCIsXHJcbiAgUFJPRFVDVDogXCJwYWdlcy9wcm9kdWN0XCIsXHJcbiAgTElTVF9QUk9EVUNUOiBcInBhZ2VzL2xpc3QtcHJvZHVjdFwiLFxyXG4gIEhJU1RPUlk6IFwicGFnZXMvaGlzdG9yeVwiLFxyXG4gIFRSQU5TUE9SVDogXCJwYWdlcy90cmFuc3BvcnRcIixcclxuICBTRVRUSU5HOiBcInBhZ2VzL3NldHRpbmdcIixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBLRVlfU1RPUkFHRSA9IHtcclxuICBUSEVNRTogXCJTRVRfVEhFTUVcIixcclxuICBMQU5HOiBcIlNFVF9MQU5HVUFHRVwiLFxyXG59O1xyXG4iLCJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCBEaXNwYXRjaCB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuZXhwb3J0IHR5cGUgQWN0aW9uVHlwZSA9XHJcbiAgfCBcIlNFVF9UT0tFTlwiXHJcbiAgfCBcIlNFVF9MQU5HVUFHRVwiXHJcbiAgfCBcIlNFVF9QUklNQVJZXCJcclxuICB8IFwiU0VUX1RPT0xCQVJcIlxyXG4gIHwgXCJTRVRfVVNFUlwiXHJcbiAgfCBcIkxPR0lOXCJcclxuICB8IFwiTE9HT1VUXCJcclxuICB8IFwiUkVHSVNURVJcIlxyXG4gIHwgXCJTRVRfQ09NUEFOWVwiXHJcbiAgfCBcIlNFVF9ST1VUX01VTlVcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUNvbnRleHQge1xyXG4gIHN0YXRlOiBJbml0aWFsU3RhdGUgfCBudWxsO1xyXG4gIGRpc3BhdGNoOiBEaXNwYXRjaDxBY3Rpb24+O1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEFjdGlvbiB7XHJcbiAgdHlwZTogQWN0aW9uVHlwZTtcclxuICBwYXlsb2FkPzogQWN0aW9uUGF5bG9hZDtcclxufVxyXG5cclxuaW50ZXJmYWNlIEFjdGlvblBheWxvYWQge1xyXG4gIHVzZXJUb2tlbj86IHN0cmluZztcclxuICByb3V0TWVudT86IHN0cmluZztcclxuICBsYW5ndWFnZT86IHN0cmluZztcclxuICB1c2VyPzogYW55O1xyXG4gIHRoZW1lPzogVGhlbWU7XHJcbiAgcHJpbWFyeT86IHN0cmluZztcclxuICB0b29sYmFyPzogc3RyaW5nO1xyXG4gIFtrZXk6IHN0cmluZ106IGFueTtcclxufVxyXG5cclxuaW50ZXJmYWNlIFRoZW1lIHtcclxuICBwcmltYXJ5OiBzdHJpbmc7XHJcbiAgbGluazogc3RyaW5nO1xyXG4gIHN1Y2Nlc3M6IHN0cmluZztcclxuICB3YXJuaW5nOiBzdHJpbmc7XHJcbiAgZXJyb3I6IHN0cmluZztcclxuICB0b29sYmFyOiBzdHJpbmc7XHJcbiAgb3V0bGluZTogc3RyaW5nO1xyXG4gIHdoaXRlOiBzdHJpbmc7XHJcbn1cclxuaW50ZXJmYWNlIElMYW5ndWFnZSB7XHJcbiAgVEg6IHN0cmluZztcclxuICBFTjogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEluaXRpYWxTdGF0ZSB7XHJcbiAgdXNlcjogVXNlcjtcclxuICBsYW5ndWFnZTogc3RyaW5nO1xyXG4gIHJvdXRNZW51OiBzdHJpbmc7XHJcbiAgdXNlclRva2VuOiBzdHJpbmcgfCBudWxsO1xyXG4gIHRoZW1lOiBUaGVtZSB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVXNlciB7XHJcbiAgY29tcGFueUtleT86IHN0cmluZztcclxuICBlbWFpbD86IHN0cmluZztcclxuICBmaXJzdE5hbWU/OiBzdHJpbmc7XHJcbiAga2V5Pzogc3RyaW5nO1xyXG4gIGxhc3ROYW1lPzogc3RyaW5nO1xyXG4gIHBhY2thZ2U/OiBzdHJpbmc7XHJcbiAgcGhvbmVOdW1iZXI/OiBzdHJpbmc7XHJcbiAgcm9sZT86IHN0cmluZztcclxuICB1cGRhdGVEYXRlPzogc3RyaW5nO1xyXG4gIFtrZXk6IHN0cmluZ106IGFueTtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZTogSW5pdGlhbFN0YXRlID0ge1xyXG4gIHVzZXI6IG51bGwsXHJcbiAgbGFuZ3VhZ2U6IFwiVEhcIixcclxuICByb3V0TWVudTogXCJwYWdlcy9ob21lXCIsXHJcbiAgdXNlclRva2VuOiBudWxsLFxyXG4gIHRoZW1lOiB7XHJcbiAgICAvLyBwcmltYXJ5OiBcIiMyNjMyMzhcIixcclxuICAgIHByaW1hcnk6IFwiIzAwNGQ0MFwiLFxyXG4gICAgLy8gcHJpbWFyeTogXCIjMWEyMzdlXCIsXHJcbiAgICAvLyBwcmltYXJ5OiBcIiM0YTE0OGNcIixcclxuICAgIC8vIHByaW1hcnk6IFwiIzg4MGU0ZlwiLFxyXG4gICAgLy8gcHJpbWFyeTogXCIjMjEyMTIxXCIsXHJcbiAgICBsaW5rOiBcIiMwMDdBRkZcIixcclxuICAgIHN1Y2Nlc3M6IFwiIzRDRDk2NFwiLFxyXG4gICAgd2FybmluZzogXCIjRkY5NTAwXCIsXHJcbiAgICBlcnJvcjogXCIjRkYzQjMwXCIsXHJcbiAgICB0b29sYmFyOiBcIiMwMDAwMDBcIixcclxuICAgIG91dGxpbmU6IFwiI2ZmZmZmZlwiLFxyXG4gICAgd2hpdGU6IFwiI2ZmZmZmZlwiLFxyXG4gIH0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8SUNvbnRleHQ+KG51bGwpO1xyXG4iLCJjb25zdCBsYW5nVEggPSB7XHJcbiAgVElUTEU6IFtcIuC4hOC5ieC4meC4q+C4slwiLCBcIlNlYXJjaFwiXSxcclxuICBSZWNvbW1lbmRlZFByb2R1Y3RzOiBbXCLguKrguLTguJnguITguYnguLLguYHguJnguLDguJnguLNcIiwgXCJSZWNvbW1lbmRlZCBQcm9kdWN0c1wiXSxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBMYW5ndWFnZSA9IChsYW5nOiBzdHJpbmcpID0+IHtcclxuICBsZXQgU2V0TGFuZ3VhZ2U6IGFueSA9IHt9O1xyXG4gIGxldCBpbmRleFRIID0gMDtcclxuICBsZXQgaW5kZXhFTiA9IDE7XHJcblxyXG4gIGNvbnN0IExhbmd1YWdlID0ge1xyXG4gICAgSG9tZTogW1wi4Lir4LiZ4LmJ4Liy4LmB4Lij4LiBXCIsIFwiSE9NRVwiXSxcclxuICAgIFByb2R1Y3RUeXBlOiBbXCLguKvguKHguKfguJTguKrguLTguJnguITguYnguLJcIiwgXCJQUk9EVUNUIFRZUEVcIl0sXHJcbiAgICBQcm9kdWN0TGlzdDogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LiX4Li14LmI4LmA4Lil4Li34Lit4LiBXCIsIFwiUFJPRFVDVCBMSVNUXCJdLFxyXG4gICAgUHJvZHVjdEhpc3Rvcnk6IFtcIuC4quC4tOC4meC4hOC5ieC4suC4l+C4teC5iOC4quC4seC5iOC4h+C4i+C4t+C5ieC4reC5geC4peC5ieC4p1wiLCBcIlBST0RVQ1QgSElTVE9SWVwiXSxcclxuICAgIFByb2R1Y3RTaGlwcGluZzogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LiB4Liz4Lil4Lix4LiH4LiI4Lix4LiU4Liq4LmI4LiHXCIsIFwiUFJPRFVDVCBTSElQUElOR1wiXSxcclxuICAgIFNldHRpbmc6IFtcIuC4leC4seC5ieC4h+C4hOC5ieC4slwiLCBcIlNFVFRJTkdcIl0sXHJcbiAgICBTZWFyY2g6IFtcIuC4hOC5ieC4meC4q+C4slwiLCBcIlNlYXJjaFwiXSxcclxuICAgIFJlY29tbWVuZGVkUHJvZHVjdHM6IFtcIuC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1wiLCBcIlJlY29tbWVuZGVkIFByb2R1Y3RzXCJdLFxyXG4gIH07XHJcbiAgY29uc3QgZ2V0VEggPSAoKSA9PiB7XHJcbiAgICAgIFNldExhbmd1YWdlLkhvbWUgPSBMYW5ndWFnZS5Ib21lW2luZGV4VEhdO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0VHlwZSA9IExhbmd1YWdlLlByb2R1Y3RUeXBlW2luZGV4VEhdO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0TGlzdCA9IExhbmd1YWdlLlByb2R1Y3RMaXN0W2luZGV4VEhdO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0SGlzdG9yeSA9IExhbmd1YWdlLlByb2R1Y3RIaXN0b3J5W2luZGV4VEhdO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0U2hpcHBpbmcgPSBMYW5ndWFnZS5Qcm9kdWN0U2hpcHBpbmdbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlNldHRpbmcgPSBMYW5ndWFnZS5TZXR0aW5nW2luZGV4VEhdO1xyXG4gICAgICBTZXRMYW5ndWFnZS5TZWFyY2ggPSBMYW5ndWFnZS5TZWFyY2hbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHMgPSBMYW5ndWFnZS5SZWNvbW1lbmRlZFByb2R1Y3RzW2luZGV4VEhdO1xyXG4gICAgcmV0dXJuIFNldExhbmd1YWdlO1xyXG4gIH07XHJcbiAgY29uc3QgZ2V0RU4gPSAoKSA9PiB7XHJcbiAgICAgIFNldExhbmd1YWdlLkhvbWUgPSBMYW5ndWFnZS5Ib21lW2luZGV4RU5dO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0VHlwZSA9IExhbmd1YWdlLlByb2R1Y3RUeXBlW2luZGV4RU5dO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0TGlzdCA9IExhbmd1YWdlLlByb2R1Y3RMaXN0W2luZGV4RU5dO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0SGlzdG9yeSA9IExhbmd1YWdlLlByb2R1Y3RIaXN0b3J5W2luZGV4RU5dO1xyXG4gICAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0U2hpcHBpbmcgPSBMYW5ndWFnZS5Qcm9kdWN0U2hpcHBpbmdbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlNldHRpbmcgPSBMYW5ndWFnZS5TZXR0aW5nW2luZGV4RU5dO1xyXG4gICAgICBTZXRMYW5ndWFnZS5TZWFyY2ggPSBMYW5ndWFnZS5TZWFyY2hbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHMgPSBMYW5ndWFnZS5SZWNvbW1lbmRlZFByb2R1Y3RzW2luZGV4RU5dO1xyXG4gICAgcmV0dXJuIFNldExhbmd1YWdlO1xyXG4gIH07XHJcblxyXG4gIGlmIChsYW5nLnRvVXBwZXJDYXNlKCkgPT0gXCJUSFwiKSB7XHJcbiAgICByZXR1cm4gZ2V0VEgoKTtcclxuICB9XHJcbiAgcmV0dXJuIGdldEVOKCk7XHJcbn07XHJcbiIsImltcG9ydCBkeW5hbWljIGZyb20gXCJuZXh0L2R5bmFtaWNcIjtcclxuaW1wb3J0IHsgU3BpbiwgUmVzdWx0IH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgcm91dGU6IHN0cmluZztcclxufVxyXG5jb25zdCBTd2l0Y2hDb21wb25lbnRzID0gKHsgcm91dGUgfTogUHJvcHMpID0+IHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgQXJ0aWNsZSA9IGR5bmFtaWMoXHJcbiAgICAgICgpID0+XHJcbiAgICAgICAgaW1wb3J0KGAuLi9jb21wb25lbnRzLyR7cm91dGV9YCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuICgpID0+IDxTdGF0dXNXcm9uZyAvPjtcclxuICAgICAgICB9KSxcclxuICAgICAge1xyXG4gICAgICAgIGxvYWRpbmc6ICgpID0+IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgaGVpZ2h0OiBcIjkwdmhcIixcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8U3BpbiB0aXA9XCJMb2FkaW5nLi4uXCI+PC9TcGluPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICAgIHJldHVybiA8QXJ0aWNsZSAvPjtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgcmV0dXJuIDxTdGF0dXNXcm9uZyAvPjtcclxuICB9XHJcbn07XHJcblxyXG5jb25zdCBTdGF0dXNXcm9uZyA9ICgpID0+IChcclxuICA8UmVzdWx0IHN0YXR1cz1cIjUwMFwiIHRpdGxlPVwiNTAwXCIgc3ViVGl0bGU9XCJTb3JyeSwgc29tZXRoaW5nIHdlbnQgd3JvbmcuXCIgLz5cclxuKTtcclxuZXhwb3J0IGRlZmF1bHQgU3dpdGNoQ29tcG9uZW50cztcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9BY2NvdW50XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudENpcmNsZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0JlbGxPdXRsaW5lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQ2FydFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NvZ091dGxpbmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9Gb3JtYXRMaXN0QnVsbGV0ZWRTcXVhcmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9IaXN0b3J5XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSG9tZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1Nob3BwaW5nXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvVHJ1Y2tEZWxpdmVyeU91dGxpbmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9WaWV3R3JpZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYW50LWRlc2lnbi9pY29uc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJhbnRkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZHluYW1pY1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWNvbXBvbmVudHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWpzeC9zdHlsZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9