module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/context */ "./src/context/index.tsx");
/* harmony import */ var _src_context_reducers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/context/reducers */ "./src/context/reducers.tsx");
/* harmony import */ var dynamic_antd_theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! dynamic-antd-theme */ "dynamic-antd-theme");
/* harmony import */ var dynamic_antd_theme__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(dynamic_antd_theme__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_antd_less__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../styles/antd.less */ "./styles/antd.less");
/* harmony import */ var _styles_antd_less__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_antd_less__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _src_utils_local_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../src/utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _src_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../src/constants */ "./src/constants/index.ts");


var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\pages\\_app.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // import { SET_LANGUAGE } from "../src/languages";




function MyApp({
  Component,
  pageProps
}) {
  const {
    0: state,
    1: dispatch
  } = Object(react__WEBPACK_IMPORTED_MODULE_2__["useReducer"])(_src_context_reducers__WEBPACK_IMPORTED_MODULE_4__["reducer"], _src_context__WEBPACK_IMPORTED_MODULE_3__["initialState"]);
  const value = {
    state,
    dispatch
  }; // let TH = "TH"
  // let EN = "EN"

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    // console.log("SET_LANGUAGE......", SET_LANGUAGE);
    const lang = Object(_src_utils_local_storage__WEBPACK_IMPORTED_MODULE_7__["_getStorage"])(_src_constants__WEBPACK_IMPORTED_MODULE_8__["KEY_STORAGE"].LANG);

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang === "" || lang === undefined ? "TH" : lang
      }
    });
    Object(dynamic_antd_theme__WEBPACK_IMPORTED_MODULE_5__["changeAntdTheme"])(Object(dynamic_antd_theme__WEBPACK_IMPORTED_MODULE_5__["generateThemeColor"])(state.theme.primary));
  }, [state.theme.primary]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_context__WEBPACK_IMPORTED_MODULE_3__["Context"].Provider, {
      value: value,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "Create Next App"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
          rel: "icon",
          href: "/favicon.ico"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
          href: "https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap",
          rel: "stylesheet"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, this), " "]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

/* harmony default export */ __webpack_exports__["default"] = (MyApp);

/***/ }),

/***/ "./src/constants/index.ts":
/*!********************************!*\
  !*** ./src/constants/index.ts ***!
  \********************************/
/*! exports provided: HOST, ROUTE_MENU, KEY_STORAGE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOST", function() { return HOST; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ROUTE_MENU", function() { return ROUTE_MENU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KEY_STORAGE", function() { return KEY_STORAGE; });
const NODE_ENV = "development";
const HOST = {
  URL: NODE_ENV.trim() === "development" ? "http://localhost:3000" : "",
  API: {
    AUTH: {
      GETPRODUCT: "/api/product"
    }
  }
};
const ROUTE_MENU = {
  HOME: "pages/home",
  PRODUCT: "pages/product",
  LIST_PRODUCT: "pages/list-product",
  HISTORY: "pages/history",
  TRANSPORT: "pages/transport",
  SETTING: "pages/setting"
};
const KEY_STORAGE = {
  THEME: "SET_THEME",
  LANG: "SET_LANGUAGE"
};

/***/ }),

/***/ "./src/context/index.tsx":
/*!*******************************!*\
  !*** ./src/context/index.tsx ***!
  \*******************************/
/*! exports provided: initialState, Context */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Context", function() { return Context; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  user: null,
  language: "TH",
  routMenu: "pages/home",
  userToken: null,
  theme: {
    // primary: "#263238",
    primary: "#004d40",
    // primary: "#1a237e",
    // primary: "#4a148c",
    // primary: "#880e4f",
    // primary: "#212121",
    link: "#007AFF",
    success: "#4CD964",
    warning: "#FF9500",
    error: "#FF3B30",
    toolbar: "#000000",
    outline: "#ffffff",
    white: "#ffffff"
  }
};
const Context = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["createContext"])(null);

/***/ }),

/***/ "./src/context/reducers.tsx":
/*!**********************************!*\
  !*** ./src/context/reducers.tsx ***!
  \**********************************/
/*! exports provided: reducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducer", function() { return reducer; });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const reducer = (state, {
  type,
  payload
}) => {
  switch (type) {
    case "SET_PRIMARY":
      return _objectSpread(_objectSpread({}, state), {}, {
        theme: _objectSpread(_objectSpread({}, state.theme), {}, {
          primary: payload.primary
        })
      });

    case "SET_ROUT_MUNU":
      return _objectSpread(_objectSpread({}, state), {}, {
        routMenu: payload.routMenu
      });

    case "SET_LANGUAGE":
      return _objectSpread(_objectSpread({}, state), {}, {
        language: payload.language
      });

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/utils/local-storage.ts":
/*!************************************!*\
  !*** ./src/utils/local-storage.ts ***!
  \************************************/
/*! exports provided: _setStorage, _getStorage, _deleteStorage, _deleteAllStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_setStorage", function() { return _setStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_getStorage", function() { return _getStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteStorage", function() { return _deleteStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteAllStorage", function() { return _deleteAllStorage; });
const _setStorage = (key, body) => {
  localStorage.setItem(key, body);
};
const _getStorage = key => {
  const boby = localStorage.getItem(key);

  try {
    return JSON.parse(boby);
  } catch (error) {
    return boby;
  }
};
const _deleteStorage = key => {
  localStorage.removeItem(key);
};
const _deleteAllStorage = () => {
  localStorage.clear();
};

/***/ }),

/***/ "./styles/antd.less":
/*!**************************!*\
  !*** ./styles/antd.less ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ 0:
/*!*****************************************!*\
  !*** multi private-next-pages/_app.tsx ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.tsx */"./pages/_app.tsx");


/***/ }),

/***/ "dynamic-antd-theme":
/*!*************************************!*\
  !*** external "dynamic-antd-theme" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("dynamic-antd-theme");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvX2FwcC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnN0YW50cy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29udGV4dC9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRleHQvcmVkdWNlcnMudHN4Iiwid2VicGFjazovLy8uL3NyYy91dGlscy9sb2NhbC1zdG9yYWdlLnRzIiwid2VicGFjazovLy9leHRlcm5hbCBcImR5bmFtaWMtYW50ZC10aGVtZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiXSwibmFtZXMiOlsiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlUmVkdWNlciIsInJlZHVjZXIiLCJpbml0aWFsU3RhdGUiLCJ2YWx1ZSIsInVzZUVmZmVjdCIsImxhbmciLCJfZ2V0U3RvcmFnZSIsIktFWV9TVE9SQUdFIiwiTEFORyIsInR5cGUiLCJwYXlsb2FkIiwibGFuZ3VhZ2UiLCJ1bmRlZmluZWQiLCJjaGFuZ2VBbnRkVGhlbWUiLCJnZW5lcmF0ZVRoZW1lQ29sb3IiLCJ0aGVtZSIsInByaW1hcnkiLCJOT0RFX0VOViIsIkhPU1QiLCJVUkwiLCJ0cmltIiwiQVBJIiwiQVVUSCIsIkdFVFBST0RVQ1QiLCJST1VURV9NRU5VIiwiSE9NRSIsIlBST0RVQ1QiLCJMSVNUX1BST0RVQ1QiLCJISVNUT1JZIiwiVFJBTlNQT1JUIiwiU0VUVElORyIsIlRIRU1FIiwidXNlciIsInJvdXRNZW51IiwidXNlclRva2VuIiwibGluayIsInN1Y2Nlc3MiLCJ3YXJuaW5nIiwiZXJyb3IiLCJ0b29sYmFyIiwib3V0bGluZSIsIndoaXRlIiwiQ29udGV4dCIsImNyZWF0ZUNvbnRleHQiLCJfc2V0U3RvcmFnZSIsImtleSIsImJvZHkiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiYm9ieSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJfZGVsZXRlU3RvcmFnZSIsInJlbW92ZUl0ZW0iLCJfZGVsZXRlQWxsU3RvcmFnZSIsImNsZWFyIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0NBRUE7O0FBQ0E7QUFDQTs7QUFFQSxTQUFTQSxLQUFULENBQWU7QUFBRUMsV0FBRjtBQUFhQztBQUFiLENBQWYsRUFBeUM7QUFDdkMsUUFBTTtBQUFBLE9BQUNDLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CQyx3REFBVSxDQUFDQyw2REFBRCxFQUFVQyx5REFBVixDQUFwQztBQUNBLFFBQU1DLEtBQUssR0FBRztBQUFFTCxTQUFGO0FBQVNDO0FBQVQsR0FBZCxDQUZ1QyxDQUd2QztBQUNBOztBQUNBSyx5REFBUyxDQUFDLE1BQU07QUFDZDtBQUNBLFVBQU1DLElBQUksR0FBR0MsNEVBQVcsQ0FBQ0MsMERBQVcsQ0FBQ0MsSUFBYixDQUF4Qjs7QUFDQVQsWUFBUSxDQUFDO0FBQ1BVLFVBQUksRUFBRSxjQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQQyxnQkFBUSxFQUFFTixJQUFJLEtBQUssRUFBVCxJQUFlQSxJQUFJLEtBQUtPLFNBQXhCLEdBQW9DLElBQXBDLEdBQTJDUDtBQUQ5QztBQUZGLEtBQUQsQ0FBUjtBQU1BUSw4RUFBZSxDQUFDQyw2RUFBa0IsQ0FBQ2hCLEtBQUssQ0FBQ2lCLEtBQU4sQ0FBWUMsT0FBYixDQUFuQixDQUFmO0FBQ0QsR0FWUSxFQVVOLENBQUNsQixLQUFLLENBQUNpQixLQUFOLENBQVlDLE9BQWIsQ0FWTSxDQUFUO0FBV0Esc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxvREFBRCxDQUFTLFFBQVQ7QUFBa0IsV0FBSyxFQUFFYixLQUF6QjtBQUFBLDhCQUNFLHFFQUFDLGdEQUFEO0FBQUEsZ0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRTtBQUFNLGFBQUcsRUFBQyxNQUFWO0FBQWlCLGNBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBR0U7QUFDRSxjQUFJLEVBQUMsbUxBRFA7QUFFRSxhQUFHLEVBQUM7QUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGLEVBTUssR0FOTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQVNFLHFFQUFDLFNBQUQsb0JBQWVOLFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBZUQ7O0FBRWNGLG9FQUFmLEU7Ozs7Ozs7Ozs7OztBQzNDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQU1zQixRQUFRLGdCQUFkO0FBRU8sTUFBTUMsSUFBSSxHQUFHO0FBQ2xCQyxLQUFHLEVBQUVGLFFBQVEsQ0FBQ0csSUFBVCxPQUFvQixhQUFwQixHQUFvQyx1QkFBcEMsR0FBOEQsRUFEakQ7QUFFbEJDLEtBQUcsRUFBRTtBQUNIQyxRQUFJLEVBQUU7QUFDSkMsZ0JBQVUsRUFBRTtBQURSO0FBREg7QUFGYSxDQUFiO0FBU0EsTUFBTUMsVUFBVSxHQUFHO0FBQ3hCQyxNQUFJLEVBQUUsWUFEa0I7QUFFeEJDLFNBQU8sRUFBRSxlQUZlO0FBR3hCQyxjQUFZLEVBQUUsb0JBSFU7QUFJeEJDLFNBQU8sRUFBRSxlQUplO0FBS3hCQyxXQUFTLEVBQUUsaUJBTGE7QUFNeEJDLFNBQU8sRUFBRTtBQU5lLENBQW5CO0FBU0EsTUFBTXZCLFdBQVcsR0FBRztBQUN6QndCLE9BQUssRUFBRSxXQURrQjtBQUV6QnZCLE1BQUksRUFBRTtBQUZtQixDQUFwQixDOzs7Ozs7Ozs7Ozs7QUNwQlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdUVPLE1BQU1OLFlBQTBCLEdBQUc7QUFDeEM4QixNQUFJLEVBQUUsSUFEa0M7QUFFeENyQixVQUFRLEVBQUUsSUFGOEI7QUFHeENzQixVQUFRLEVBQUUsWUFIOEI7QUFJeENDLFdBQVMsRUFBRSxJQUo2QjtBQUt4Q25CLE9BQUssRUFBRTtBQUNMO0FBQ0FDLFdBQU8sRUFBRSxTQUZKO0FBR0w7QUFDQTtBQUNBO0FBQ0E7QUFDQW1CLFFBQUksRUFBRSxTQVBEO0FBUUxDLFdBQU8sRUFBRSxTQVJKO0FBU0xDLFdBQU8sRUFBRSxTQVRKO0FBVUxDLFNBQUssRUFBRSxTQVZGO0FBV0xDLFdBQU8sRUFBRSxTQVhKO0FBWUxDLFdBQU8sRUFBRSxTQVpKO0FBYUxDLFNBQUssRUFBRTtBQWJGO0FBTGlDLENBQW5DO0FBc0JBLE1BQU1DLE9BQU8sZ0JBQUdDLDJEQUFhLENBQVcsSUFBWCxDQUE3QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNGQSxNQUFNMUMsT0FBTyxHQUFHLENBQ3JCSCxLQURxQixFQUVyQjtBQUFFVyxNQUFGO0FBQVFDO0FBQVIsQ0FGcUIsS0FHSjtBQUNqQixVQUFRRCxJQUFSO0FBQ0UsU0FBSyxhQUFMO0FBQ0UsNkNBQ0tYLEtBREw7QUFFRWlCLGFBQUssa0NBQ0FqQixLQUFLLENBQUNpQixLQUROO0FBRUhDLGlCQUFPLEVBQUVOLE9BQU8sQ0FBQ007QUFGZDtBQUZQOztBQU9GLFNBQUssZUFBTDtBQUNFLDZDQUNLbEIsS0FETDtBQUVFbUMsZ0JBQVEsRUFBRXZCLE9BQU8sQ0FBQ3VCO0FBRnBCOztBQUlGLFNBQUssY0FBTDtBQUNFLDZDQUNLbkMsS0FETDtBQUVFYSxnQkFBUSxFQUFFRCxPQUFPLENBQUNDO0FBRnBCOztBQUlGO0FBQ0UsYUFBT2IsS0FBUDtBQXBCSjtBQXNCRCxDQTFCTSxDOzs7Ozs7Ozs7Ozs7QUNGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU8sTUFBTThDLFdBQVcsR0FBRyxDQUFDQyxHQUFELEVBQWNDLElBQWQsS0FBK0I7QUFDdERDLGNBQVksQ0FBQ0MsT0FBYixDQUFxQkgsR0FBckIsRUFBMEJDLElBQTFCO0FBQ0QsQ0FGSTtBQUlFLE1BQU14QyxXQUFXLEdBQUl1QyxHQUFELElBQWlCO0FBQzFDLFFBQU1JLElBQUksR0FBR0YsWUFBWSxDQUFDRyxPQUFiLENBQXFCTCxHQUFyQixDQUFiOztBQUNBLE1BQUk7QUFDRixXQUFPTSxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsSUFBWCxDQUFQO0FBQ0QsR0FGRCxDQUVFLE9BQU9YLEtBQVAsRUFBYztBQUNkLFdBQU9XLElBQVA7QUFDRDtBQUNGLENBUE07QUFTQSxNQUFNSSxjQUFjLEdBQUlSLEdBQUQsSUFBaUI7QUFDN0NFLGNBQVksQ0FBQ08sVUFBYixDQUF3QlQsR0FBeEI7QUFDRCxDQUZNO0FBSUEsTUFBTVUsaUJBQWlCLEdBQUcsTUFBTTtBQUNyQ1IsY0FBWSxDQUFDUyxLQUFiO0FBQ0QsQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJULCtDOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL19hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMCk7XG4iLCJpbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWR1Y2VyIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250ZXh0LCBpbml0aWFsU3RhdGUgfSBmcm9tIFwiLi4vc3JjL2NvbnRleHRcIjtcbmltcG9ydCB7IHJlZHVjZXIgfSBmcm9tIFwiLi4vc3JjL2NvbnRleHQvcmVkdWNlcnNcIjtcbmltcG9ydCB7IGNoYW5nZUFudGRUaGVtZSwgZ2VuZXJhdGVUaGVtZUNvbG9yIH0gZnJvbSBcImR5bmFtaWMtYW50ZC10aGVtZVwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL2FudGQubGVzc1wiO1xuLy8gaW1wb3J0IHsgU0VUX0xBTkdVQUdFIH0gZnJvbSBcIi4uL3NyYy9sYW5ndWFnZXNcIjtcbmltcG9ydCB7IF9nZXRTdG9yYWdlIH0gZnJvbSBcIi4uL3NyYy91dGlscy9sb2NhbC1zdG9yYWdlXCI7XG5pbXBvcnQgeyBLRVlfU1RPUkFHRSB9IGZyb20gXCIuLi9zcmMvY29uc3RhbnRzXCI7XG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICBjb25zdCBbc3RhdGUsIGRpc3BhdGNoXSA9IHVzZVJlZHVjZXIocmVkdWNlciwgaW5pdGlhbFN0YXRlKTtcbiAgY29uc3QgdmFsdWUgPSB7IHN0YXRlLCBkaXNwYXRjaCB9O1xuICAvLyBsZXQgVEggPSBcIlRIXCJcbiAgLy8gbGV0IEVOID0gXCJFTlwiXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gY29uc29sZS5sb2coXCJTRVRfTEFOR1VBR0UuLi4uLi5cIiwgU0VUX0xBTkdVQUdFKTtcbiAgICBjb25zdCBsYW5nID0gX2dldFN0b3JhZ2UoS0VZX1NUT1JBR0UuTEFORyk7XG4gICAgZGlzcGF0Y2goe1xuICAgICAgdHlwZTogXCJTRVRfTEFOR1VBR0VcIixcbiAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgbGFuZ3VhZ2U6IGxhbmcgPT09IFwiXCIgfHwgbGFuZyA9PT0gdW5kZWZpbmVkID8gXCJUSFwiIDogbGFuZyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY2hhbmdlQW50ZFRoZW1lKGdlbmVyYXRlVGhlbWVDb2xvcihzdGF0ZS50aGVtZS5wcmltYXJ5KSk7XG4gIH0sIFtzdGF0ZS50aGVtZS5wcmltYXJ5XSk7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+XG4gICAgICAgIDxIZWFkPlxuICAgICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICAgIDxsaW5rIHJlbD1cImljb25cIiBocmVmPVwiL2Zhdmljb24uaWNvXCIgLz5cbiAgICAgICAgICA8bGlua1xuICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzMj9mYW1pbHk9S2FuaXQ6aXRhbCx3Z2h0QDAsMTAwOzAsMjAwOzAsMzAwOzAsNDAwOzAsNTAwOzAsNjAwOzAsNzAwOzAsODAwOzAsOTAwOzEsMTAwOzEsMjAwOzEsMzAwOzEsNDAwOzEsNTAwOzEsNjAwOzEsNzAwOzEsODAwOzEsOTAwJmRpc3BsYXk9c3dhcFwiXG4gICAgICAgICAgICByZWw9XCJzdHlsZXNoZWV0XCJcbiAgICAgICAgICAvPntcIiBcIn1cbiAgICAgICAgPC9IZWFkPlxuICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICA8L0NvbnRleHQuUHJvdmlkZXI+XG4gICAgPC8+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xuIiwiY29uc3QgTk9ERV9FTlYgPSBwcm9jZXNzLmVudi5OT0RFX0VOVjtcclxuXHJcbmV4cG9ydCBjb25zdCBIT1NUID0ge1xyXG4gIFVSTDogTk9ERV9FTlYudHJpbSgpID09PSBcImRldmVsb3BtZW50XCIgPyBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMFwiIDogXCJcIixcclxuICBBUEk6IHtcclxuICAgIEFVVEg6IHtcclxuICAgICAgR0VUUFJPRFVDVDogXCIvYXBpL3Byb2R1Y3RcIixcclxuICAgIH0sXHJcbiAgfSxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBST1VURV9NRU5VID0ge1xyXG4gIEhPTUU6IFwicGFnZXMvaG9tZVwiLFxyXG4gIFBST0RVQ1Q6IFwicGFnZXMvcHJvZHVjdFwiLFxyXG4gIExJU1RfUFJPRFVDVDogXCJwYWdlcy9saXN0LXByb2R1Y3RcIixcclxuICBISVNUT1JZOiBcInBhZ2VzL2hpc3RvcnlcIixcclxuICBUUkFOU1BPUlQ6IFwicGFnZXMvdHJhbnNwb3J0XCIsXHJcbiAgU0VUVElORzogXCJwYWdlcy9zZXR0aW5nXCIsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgS0VZX1NUT1JBR0UgPSB7XHJcbiAgVEhFTUU6IFwiU0VUX1RIRU1FXCIsXHJcbiAgTEFORzogXCJTRVRfTEFOR1VBR0VcIixcclxufTtcclxuIiwiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCB0eXBlIEFjdGlvblR5cGUgPVxyXG4gIHwgXCJTRVRfVE9LRU5cIlxyXG4gIHwgXCJTRVRfTEFOR1VBR0VcIlxyXG4gIHwgXCJTRVRfUFJJTUFSWVwiXHJcbiAgfCBcIlNFVF9UT09MQkFSXCJcclxuICB8IFwiU0VUX1VTRVJcIlxyXG4gIHwgXCJMT0dJTlwiXHJcbiAgfCBcIkxPR09VVFwiXHJcbiAgfCBcIlJFR0lTVEVSXCJcclxuICB8IFwiU0VUX0NPTVBBTllcIlxyXG4gIHwgXCJTRVRfUk9VVF9NVU5VXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElDb250ZXh0IHtcclxuICBzdGF0ZTogSW5pdGlhbFN0YXRlIHwgbnVsbDtcclxuICBkaXNwYXRjaDogRGlzcGF0Y2g8QWN0aW9uPjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBBY3Rpb24ge1xyXG4gIHR5cGU6IEFjdGlvblR5cGU7XHJcbiAgcGF5bG9hZD86IEFjdGlvblBheWxvYWQ7XHJcbn1cclxuXHJcbmludGVyZmFjZSBBY3Rpb25QYXlsb2FkIHtcclxuICB1c2VyVG9rZW4/OiBzdHJpbmc7XHJcbiAgcm91dE1lbnU/OiBzdHJpbmc7XHJcbiAgbGFuZ3VhZ2U/OiBzdHJpbmc7XHJcbiAgdXNlcj86IGFueTtcclxuICB0aGVtZT86IFRoZW1lO1xyXG4gIHByaW1hcnk/OiBzdHJpbmc7XHJcbiAgdG9vbGJhcj86IHN0cmluZztcclxuICBba2V5OiBzdHJpbmddOiBhbnk7XHJcbn1cclxuXHJcbmludGVyZmFjZSBUaGVtZSB7XHJcbiAgcHJpbWFyeTogc3RyaW5nO1xyXG4gIGxpbms6IHN0cmluZztcclxuICBzdWNjZXNzOiBzdHJpbmc7XHJcbiAgd2FybmluZzogc3RyaW5nO1xyXG4gIGVycm9yOiBzdHJpbmc7XHJcbiAgdG9vbGJhcjogc3RyaW5nO1xyXG4gIG91dGxpbmU6IHN0cmluZztcclxuICB3aGl0ZTogc3RyaW5nO1xyXG59XHJcbmludGVyZmFjZSBJTGFuZ3VhZ2Uge1xyXG4gIFRIOiBzdHJpbmc7XHJcbiAgRU46IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJbml0aWFsU3RhdGUge1xyXG4gIHVzZXI6IFVzZXI7XHJcbiAgbGFuZ3VhZ2U6IHN0cmluZztcclxuICByb3V0TWVudTogc3RyaW5nO1xyXG4gIHVzZXJUb2tlbjogc3RyaW5nIHwgbnVsbDtcclxuICB0aGVtZTogVGhlbWUgfCBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFVzZXIge1xyXG4gIGNvbXBhbnlLZXk/OiBzdHJpbmc7XHJcbiAgZW1haWw/OiBzdHJpbmc7XHJcbiAgZmlyc3ROYW1lPzogc3RyaW5nO1xyXG4gIGtleT86IHN0cmluZztcclxuICBsYXN0TmFtZT86IHN0cmluZztcclxuICBwYWNrYWdlPzogc3RyaW5nO1xyXG4gIHBob25lTnVtYmVyPzogc3RyaW5nO1xyXG4gIHJvbGU/OiBzdHJpbmc7XHJcbiAgdXBkYXRlRGF0ZT86IHN0cmluZztcclxuICBba2V5OiBzdHJpbmddOiBhbnk7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBpbml0aWFsU3RhdGU6IEluaXRpYWxTdGF0ZSA9IHtcclxuICB1c2VyOiBudWxsLFxyXG4gIGxhbmd1YWdlOiBcIlRIXCIsXHJcbiAgcm91dE1lbnU6IFwicGFnZXMvaG9tZVwiLFxyXG4gIHVzZXJUb2tlbjogbnVsbCxcclxuICB0aGVtZToge1xyXG4gICAgLy8gcHJpbWFyeTogXCIjMjYzMjM4XCIsXHJcbiAgICBwcmltYXJ5OiBcIiMwMDRkNDBcIixcclxuICAgIC8vIHByaW1hcnk6IFwiIzFhMjM3ZVwiLFxyXG4gICAgLy8gcHJpbWFyeTogXCIjNGExNDhjXCIsXHJcbiAgICAvLyBwcmltYXJ5OiBcIiM4ODBlNGZcIixcclxuICAgIC8vIHByaW1hcnk6IFwiIzIxMjEyMVwiLFxyXG4gICAgbGluazogXCIjMDA3QUZGXCIsXHJcbiAgICBzdWNjZXNzOiBcIiM0Q0Q5NjRcIixcclxuICAgIHdhcm5pbmc6IFwiI0ZGOTUwMFwiLFxyXG4gICAgZXJyb3I6IFwiI0ZGM0IzMFwiLFxyXG4gICAgdG9vbGJhcjogXCIjMDAwMDAwXCIsXHJcbiAgICBvdXRsaW5lOiBcIiNmZmZmZmZcIixcclxuICAgIHdoaXRlOiBcIiNmZmZmZmZcIixcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IENvbnRleHQgPSBjcmVhdGVDb250ZXh0PElDb250ZXh0PihudWxsKTtcclxuIiwiaW1wb3J0IHsgQWN0aW9uLCBpbml0aWFsU3RhdGUsIEluaXRpYWxTdGF0ZSB9IGZyb20gXCIuXCI7XHJcblxyXG5leHBvcnQgY29uc3QgcmVkdWNlciA9IChcclxuICBzdGF0ZTogSW5pdGlhbFN0YXRlLFxyXG4gIHsgdHlwZSwgcGF5bG9hZCB9OiBBY3Rpb25cclxuKTogSW5pdGlhbFN0YXRlID0+IHtcclxuICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgIGNhc2UgXCJTRVRfUFJJTUFSWVwiOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIHRoZW1lOiB7XHJcbiAgICAgICAgICAuLi5zdGF0ZS50aGVtZSxcclxuICAgICAgICAgIHByaW1hcnk6IHBheWxvYWQucHJpbWFyeSxcclxuICAgICAgICB9LFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBcIlNFVF9ST1VUX01VTlVcIjpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICByb3V0TWVudTogcGF5bG9hZC5yb3V0TWVudSxcclxuICAgICAgfTtcclxuICAgIGNhc2UgXCJTRVRfTEFOR1VBR0VcIjpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBsYW5ndWFnZTogcGF5bG9hZC5sYW5ndWFnZSxcclxuICAgICAgfTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZTtcclxuICB9XHJcbn07XHJcbiIsImV4cG9ydCBjb25zdCBfc2V0U3RvcmFnZSA9IChrZXk6IHN0cmluZywgYm9keTogc3RyaW5nKSA9PiB7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIGJvZHkpO1xyXG4gIH07XHJcbiAgXHJcbiAgZXhwb3J0IGNvbnN0IF9nZXRTdG9yYWdlID0gKGtleTogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBib2J5ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgIHRyeSB7XHJcbiAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvYnkpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgcmV0dXJuIGJvYnk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBcclxuICBleHBvcnQgY29uc3QgX2RlbGV0ZVN0b3JhZ2UgPSAoa2V5OiBzdHJpbmcpID0+IHtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGtleSk7XHJcbiAgfTtcclxuICBcclxuICBleHBvcnQgY29uc3QgX2RlbGV0ZUFsbFN0b3JhZ2UgPSAoKSA9PiB7XHJcbiAgICBsb2NhbFN0b3JhZ2UuY2xlYXIoKTtcclxuICB9O1xyXG4gICIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImR5bmFtaWMtYW50ZC10aGVtZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=