webpackHotUpdate_N_E(4,{

/***/ "./src/languages/index.ts":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay80LmNiMjY3MTI3NzhhNzI2MTY0OGUxLmhvdC11cGRhdGUuanMiLCJzb3VyY2VSb290IjoiIn0=