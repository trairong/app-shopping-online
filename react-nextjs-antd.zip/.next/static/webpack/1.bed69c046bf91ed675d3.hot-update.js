webpackHotUpdate_N_E(1,{

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx",
    _s = $RefreshSig$();








var primarys = [{
  colorName: "#b71c1c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#311b92"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#0d47a1"
}, {
  colorName: "#002f6c"
}, {
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#00363a"
}, {
  colorName: "#006064"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#212121"
}];
function Setting(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_3__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var setTheme = function setTheme(color) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  var setLanguage = function setLanguage(lang) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map(function (row, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
          span: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName,
              borderColor: row.colorName
            },
            onClick: function onClick() {
              return setTheme(row.colorName);
            },
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 15
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 55,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("EN");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, this), "ENGLISH"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("TH");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 91,
            columnNumber: 13
          }, this), "THAI"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Setting, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Setting;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = TextHeader;

var _c, _c2;

$RefreshReg$(_c, "Setting");
$RefreshReg$(_c2, "TextHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3giXSwibmFtZXMiOlsicHJpbWFyeXMiLCJjb2xvck5hbWUiLCJTZXR0aW5nIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwic2V0VGhlbWUiLCJjb2xvciIsIl9zZXRTdG9yYWdlIiwiS0VZX1NUT1JBR0UiLCJUSEVNRSIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsInBheWxvYWQiLCJwcmltYXJ5Iiwic2V0TGFuZ3VhZ2UiLCJsYW5nIiwiTEFORyIsImxhbmd1YWdlIiwidGhlbWUiLCJwYWRkaW5nIiwibWFwIiwicm93IiwiaW5kZXgiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiZm9udFNpemUiLCJUZXh0SGVhZGVyIiwic3R5bGVkIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLElBQU1BLFFBQVEsR0FBRyxDQUNmO0FBQUVDLFdBQVMsRUFBRTtBQUFiLENBRGUsRUFFZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUZlLEVBR2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FIZSxFQUlmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBSmUsRUFLZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUxlLEVBTWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FOZSxFQU9mO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBUGUsRUFRZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVJlLEVBU2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FUZSxFQVVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBVmUsRUFXZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVhlLEVBWWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FaZSxDQUFqQjtBQWVlLFNBQVNDLE9BQVQsT0FBMEM7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQSxvQkFDM0JDLHdEQUFVLENBQUNDLGdEQUFELENBRGlCO0FBQUEsTUFDL0NDLEtBRCtDLGVBQy9DQSxLQUQrQztBQUFBLE1BQ3hDQyxRQUR3QyxlQUN4Q0EsUUFEd0M7O0FBRXZELE1BQU1DLFFBQVEsR0FBRyxTQUFYQSxRQUFXLENBQUNDLEtBQUQsRUFBVztBQUMxQkMsNEVBQVcsQ0FBQ0Msc0RBQVcsQ0FBQ0MsS0FBYixFQUFvQkMsSUFBSSxDQUFDQyxTQUFMLENBQWVMLEtBQWYsQ0FBcEIsQ0FBWDs7QUFDQU0sV0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QlAsS0FBekI7QUFFQUYsWUFBUSxDQUFDO0FBQ1BVLFVBQUksRUFBRSxhQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQQyxlQUFPLEVBQUVWO0FBREY7QUFGRixLQUFELENBQVI7QUFNRCxHQVZEOztBQVdBLE1BQU1XLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNDLElBQUQsRUFBVTtBQUM1QlgsNEVBQVcsQ0FBQ0Msc0RBQVcsQ0FBQ1csSUFBYixFQUFtQlQsSUFBSSxDQUFDQyxTQUFMLENBQWVPLElBQWYsQ0FBbkIsQ0FBWDs7QUFFQWQsWUFBUSxDQUFDO0FBQ1BVLFVBQUksRUFBRSxjQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQSyxnQkFBUSxFQUFFRjtBQURIO0FBRkYsS0FBRCxDQUFSO0FBTUQsR0FURDs7QUFVQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLFVBQUQ7QUFBWSxXQUFLLEVBQUVmLEtBQUssQ0FBQ2tCLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFFRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQU0sRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLENBQWI7QUFBdUIsV0FBSyxFQUFFO0FBQUVDLGVBQU8sRUFBRTtBQUFYLE9BQTlCO0FBQUEsZ0JBQ0d4QixRQUFRLENBQUN5QixHQUFULENBQWEsVUFBQ0MsR0FBRCxFQUFNQyxLQUFOLEVBQWdCO0FBQzVCLDRCQUNFLHFFQUFDLHdDQUFEO0FBQWlCLGNBQUksRUFBRSxDQUF2QjtBQUFBLGlDQUNFLHFFQUFDLDJDQUFEO0FBQ0UsZ0JBQUksRUFBQyxTQURQO0FBRUUsaUJBQUssRUFBRTtBQUNMQyxtQkFBSyxFQUFFLE1BREY7QUFFTEMsNkJBQWUsRUFBRUgsR0FBRyxDQUFDekIsU0FGaEI7QUFHTDZCLHlCQUFXLEVBQUVKLEdBQUcsQ0FBQ3pCO0FBSFosYUFGVDtBQU9FLG1CQUFPLEVBQUU7QUFBQSxxQkFBTU0sUUFBUSxDQUFDbUIsR0FBRyxDQUFDekIsU0FBTCxDQUFkO0FBQUEsYUFQWDtBQUFBLHNCQVNHeUIsR0FBRyxDQUFDekI7QUFUUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsV0FBVTBCLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQWVELE9BaEJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBcUJFLHFFQUFDLFVBQUQ7QUFBWSxXQUFLLEVBQUV0QixLQUFLLENBQUNrQixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXJCRixlQXNCRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQU0sRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLENBQWI7QUFBdUIsV0FBSyxFQUFFO0FBQUVDLGVBQU8sRUFBRTtBQUFYLE9BQTlCO0FBQUEsOEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUUsQ0FBWDtBQUFBLCtCQUNFLHFFQUFDLDJDQUFEO0FBQ0UsY0FBSSxFQUFDLFNBRFA7QUFFRSxlQUFLLEVBQUU7QUFBRUksaUJBQUssRUFBRTtBQUFULFdBRlQ7QUFHRSxpQkFBTyxFQUFFO0FBQUEsbUJBQU1ULFdBQVcsQ0FBQyxJQUFELENBQWpCO0FBQUEsV0FIWDtBQUFBLGtDQUtFLHFFQUFDLGdFQUFEO0FBQ0UsaUJBQUssRUFBRTtBQUFFWSxzQkFBUSxFQUFFO0FBQVo7QUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQWFFLHFFQUFDLHdDQUFEO0FBQUssWUFBSSxFQUFFLENBQVg7QUFBQSwrQkFDRSxxRUFBQywyQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsZUFBSyxFQUFFO0FBQUVILGlCQUFLLEVBQUU7QUFBVCxXQUZUO0FBR0UsaUJBQU8sRUFBRTtBQUFBLG1CQUFNVCxXQUFXLENBQUMsSUFBRCxDQUFqQjtBQUFBLFdBSFg7QUFBQSxrQ0FLRSxxRUFBQyxnRUFBRDtBQUNFLGlCQUFLLEVBQUU7QUFBRVksc0JBQVEsRUFBRTtBQUFaO0FBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdEJGO0FBQUEsa0JBREY7QUFtREQ7O0dBMUV1QjdCLE87O0tBQUFBLE87QUE0RXhCLElBQU04QixVQUFVLEdBQUdDLHlEQUFNLENBQUNDLEdBQVY7QUFBQTtBQUFBO0FBQUEsb1lBSUw7QUFBQSxNQUFHWCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNMLE9BQXJCO0FBQUEsQ0FKSyxDQUFoQjtNQUFNYyxVIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrLzEuYmVkNjljMDQ2YmY5MWVkNjc1ZDMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0XCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiwgQ29sLCBSb3cgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBfc2V0U3RvcmFnZSB9IGZyb20gXCIuLi8uLi91dGlscy9sb2NhbC1zdG9yYWdlXCI7XHJcbmltcG9ydCB7IEtFWV9TVE9SQUdFIH0gZnJvbSBcIi4uLy4uL2NvbnN0YW50c1wiO1xyXG5pbXBvcnQgeyBHbG9iYWxPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5jb25zdCBwcmltYXJ5cyA9IFtcclxuICB7IGNvbG9yTmFtZTogXCIjYjcxYzFjXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjODgwZTRmXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMzExYjkyXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMWEyMzdlXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMGQ0N2ExXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMDAyZjZjXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMjYzMjM4XCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMDA0ZDQwXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMDAzNjNhXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMDA2MDY0XCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjNGExNDhjXCIgfSxcclxuICB7IGNvbG9yTmFtZTogXCIjMjEyMTIxXCIgfSxcclxuXTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNldHRpbmcoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlLCBkaXNwYXRjaCB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICBjb25zdCBzZXRUaGVtZSA9IChjb2xvcikgPT4ge1xyXG4gICAgX3NldFN0b3JhZ2UoS0VZX1NUT1JBR0UuVEhFTUUsIEpTT04uc3RyaW5naWZ5KGNvbG9yKSk7XHJcbiAgICBjb25zb2xlLmxvZyhcIlRoZW1lID0+IFwiLCBjb2xvcik7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9QUklNQVJZXCIsXHJcbiAgICAgIHBheWxvYWQ6IHtcclxuICAgICAgICBwcmltYXJ5OiBjb2xvcixcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgY29uc3Qgc2V0TGFuZ3VhZ2UgPSAobGFuZykgPT4ge1xyXG4gICAgX3NldFN0b3JhZ2UoS0VZX1NUT1JBR0UuTEFORywgSlNPTi5zdHJpbmdpZnkobGFuZykpO1xyXG5cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogXCJTRVRfTEFOR1VBR0VcIixcclxuICAgICAgcGF5bG9hZDoge1xyXG4gICAgICAgIGxhbmd1YWdlOiBsYW5nLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFRleHRIZWFkZXIgdGhlbWU9e3N0YXRlLnRoZW1lfT5TRVRUSU5HIFBSSU1BUlk8L1RleHRIZWFkZXI+XHJcbiAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgcGFkZGluZzogMTAgfX0+XHJcbiAgICAgICAge3ByaW1hcnlzLm1hcCgocm93LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPENvbCBrZXk9e2luZGV4fSBzcGFuPXszfT5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogcm93LmNvbG9yTmFtZSxcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IHJvdy5jb2xvck5hbWUsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGhlbWUocm93LmNvbG9yTmFtZSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3Jvdy5jb2xvck5hbWV9XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC9Sb3c+XHJcbiAgICAgIDxUZXh0SGVhZGVyIHRoZW1lPXtzdGF0ZS50aGVtZX0+U0VUVElORyBMQU5HVUFHRTwvVGV4dEhlYWRlcj5cclxuICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBzdHlsZT17eyBwYWRkaW5nOiAxMCB9fT5cclxuICAgICAgICA8Q29sIHNwYW49ezN9PlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMYW5ndWFnZShcIkVOXCIpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R2xvYmFsT3V0bGluZWRcclxuICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogMjB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICBFTkdMSVNIXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgICA8Q29sIHNwYW49ezN9PlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMYW5ndWFnZShcIlRIXCIpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R2xvYmFsT3V0bGluZWRcclxuICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogMjB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICBUSEFJXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgPC9Sb3c+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBUZXh0SGVhZGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmctbGVmdDogMTZweDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICBib3gtc2hhZG93OiAwIDIuOHB4IDIuMnB4IHJnYigwIDAgMCAvIDMlKSwgMCA2LjdweCA1LjNweCByZ2IoMCAwIDAgLyA1JSksXHJcbiAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=