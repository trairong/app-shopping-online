webpackHotUpdate_N_E(1,{

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx",
    _s = $RefreshSig$();







// primary: "#263238",
//  primary: "#004d40",
// primary: "#1a237e",
// primary: "#4a148c",
// primary: "#880e4f",
// primary: "#212121",
var primarys = [{
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#212121"
}];
function Setting(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_3__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var setTheme = function setTheme(color) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  var setLanguage = function setLanguage(lang) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map(function (row, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
          span: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName
            },
            onClick: function onClick() {
              return setTheme(row.colorName);
            },
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 54,
            columnNumber: 15
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 2,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("EN");
          },
          children: "ENGLISH"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 2,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("TH");
          },
          children: "THAI"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Setting, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Setting;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = TextHeader;

var _c, _c2;

$RefreshReg$(_c, "Setting");
$RefreshReg$(_c2, "TextHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3giXSwibmFtZXMiOlsicHJpbWFyeXMiLCJjb2xvck5hbWUiLCJTZXR0aW5nIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwic2V0VGhlbWUiLCJjb2xvciIsIl9zZXRTdG9yYWdlIiwiS0VZX1NUT1JBR0UiLCJUSEVNRSIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsInBheWxvYWQiLCJwcmltYXJ5Iiwic2V0TGFuZ3VhZ2UiLCJsYW5nIiwiTEFORyIsImxhbmd1YWdlIiwidGhlbWUiLCJwYWRkaW5nIiwibWFwIiwicm93IiwiaW5kZXgiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsIlRleHRIZWFkZXIiLCJzdHlsZWQiLCJkaXYiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUEsUUFBUSxHQUFHLENBQ2Y7QUFBRUMsV0FBUyxFQUFFO0FBQWIsQ0FEZSxFQUVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBRmUsRUFHZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUhlLEVBSWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FKZSxFQUtmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBTGUsRUFNZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQU5lLENBQWpCO0FBU2UsU0FBU0MsT0FBVCxPQUEwQztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9CQUMzQkMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FEaUI7QUFBQSxNQUMvQ0MsS0FEK0MsZUFDL0NBLEtBRCtDO0FBQUEsTUFDeENDLFFBRHdDLGVBQ3hDQSxRQUR3Qzs7QUFFdkQsTUFBTUMsUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQ0MsS0FBRCxFQUFXO0FBQzFCQyw0RUFBVyxDQUFDQyxzREFBVyxDQUFDQyxLQUFiLEVBQW9CQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUwsS0FBZixDQUFwQixDQUFYOztBQUNBTSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXlCUCxLQUF6QjtBQUVBRixZQUFRLENBQUM7QUFDUFUsVUFBSSxFQUFFLGFBREM7QUFFUEMsYUFBTyxFQUFFO0FBQ1BDLGVBQU8sRUFBRVY7QUFERjtBQUZGLEtBQUQsQ0FBUjtBQU1ELEdBVkQ7O0FBV0EsTUFBTVcsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsSUFBRCxFQUFVO0FBQzVCWCw0RUFBVyxDQUFDQyxzREFBVyxDQUFDVyxJQUFiLEVBQW1CVCxJQUFJLENBQUNDLFNBQUwsQ0FBZU8sSUFBZixDQUFuQixDQUFYOztBQUVBZCxZQUFRLENBQUM7QUFDUFUsVUFBSSxFQUFFLGNBREM7QUFFUEMsYUFBTyxFQUFFO0FBQ1BLLGdCQUFRLEVBQUVGO0FBREg7QUFGRixLQUFELENBQVI7QUFNRCxHQVREOztBQVVBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsVUFBRDtBQUFZLFdBQUssRUFBRWYsS0FBSyxDQUFDa0IsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUVFLHFFQUFDLHdDQUFEO0FBQUssWUFBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixXQUFLLEVBQUU7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBOUI7QUFBQSxnQkFDR3hCLFFBQVEsQ0FBQ3lCLEdBQVQsQ0FBYSxVQUFDQyxHQUFELEVBQU1DLEtBQU4sRUFBZ0I7QUFDNUIsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBaUIsY0FBSSxFQUFFLENBQXZCO0FBQUEsaUNBQ0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFO0FBQUVDLG1CQUFLLEVBQUUsTUFBVDtBQUFpQkMsNkJBQWUsRUFBRUgsR0FBRyxDQUFDekI7QUFBdEMsYUFGVDtBQUdFLG1CQUFPLEVBQUU7QUFBQSxxQkFBTU0sUUFBUSxDQUFDbUIsR0FBRyxDQUFDekIsU0FBTCxDQUFkO0FBQUEsYUFIWDtBQUFBLHNCQUtHeUIsR0FBRyxDQUFDekI7QUFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsV0FBVTBCLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERjtBQVdELE9BWkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFpQkUscUVBQUMsVUFBRDtBQUFZLFdBQUssRUFBRXRCLEtBQUssQ0FBQ2tCLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBakJGLGVBa0JFLHFFQUFDLHdDQUFEO0FBQUssWUFBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixXQUFLLEVBQUU7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBOUI7QUFBQSw4QkFDRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxDQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFBUSxjQUFJLEVBQUMsU0FBYjtBQUF1QixlQUFLLEVBQUU7QUFBRUksaUJBQUssRUFBRTtBQUFULFdBQTlCO0FBQWlELGlCQUFPLEVBQUU7QUFBQSxtQkFBSVQsV0FBVyxDQUFDLElBQUQsQ0FBZjtBQUFBLFdBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBTUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUUsQ0FBWDtBQUFBLCtCQUNFLHFFQUFDLDJDQUFEO0FBQVEsY0FBSSxFQUFDLFNBQWI7QUFBdUIsZUFBSyxFQUFFO0FBQUVTLGlCQUFLLEVBQUU7QUFBVCxXQUE5QjtBQUFpRCxpQkFBTyxFQUFFO0FBQUEsbUJBQUlULFdBQVcsQ0FBQyxJQUFELENBQWY7QUFBQSxXQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFsQkY7QUFBQSxrQkFERjtBQWlDRDs7R0F4RHVCakIsTzs7S0FBQUEsTztBQTBEeEIsSUFBTTRCLFVBQVUsR0FBR0MseURBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxvWUFJTDtBQUFBLE1BQUdULEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0wsT0FBckI7QUFBQSxDQUpLLENBQWhCO01BQU1ZLFUiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svMS41ZWYzNjg5NWUzYTY5NjA4OGJkOS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQnV0dG9uLCBDb2wsIFJvdyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IF9zZXRTdG9yYWdlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2xvY2FsLXN0b3JhZ2VcIjtcclxuaW1wb3J0IHsgS0VZX1NUT1JBR0UgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuLy8gcHJpbWFyeTogXCIjMjYzMjM4XCIsXHJcbi8vICBwcmltYXJ5OiBcIiMwMDRkNDBcIixcclxuLy8gcHJpbWFyeTogXCIjMWEyMzdlXCIsXHJcbi8vIHByaW1hcnk6IFwiIzRhMTQ4Y1wiLFxyXG4vLyBwcmltYXJ5OiBcIiM4ODBlNGZcIixcclxuLy8gcHJpbWFyeTogXCIjMjEyMTIxXCIsXHJcbmNvbnN0IHByaW1hcnlzID0gW1xyXG4gIHsgY29sb3JOYW1lOiBcIiMyNjMyMzhcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDRkNDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMxYTIzN2VcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM0YTE0OGNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM4ODBlNGZcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyMTIxMjFcIiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2V0dGluZyh7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIGNvbnN0IHNldFRoZW1lID0gKGNvbG9yKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5USEVNRSwgSlNPTi5zdHJpbmdpZnkoY29sb3IpKTtcclxuICAgIGNvbnNvbGUubG9nKFwiVGhlbWUgPT4gXCIsIGNvbG9yKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1BSSU1BUllcIixcclxuICAgICAgcGF5bG9hZDoge1xyXG4gICAgICAgIHByaW1hcnk6IGNvbG9yLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBzZXRMYW5ndWFnZSA9IChsYW5nKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5MQU5HLCBKU09OLnN0cmluZ2lmeShsYW5nKSk7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9MQU5HVUFHRVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgbGFuZ3VhZ2U6IGxhbmcsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlNFVFRJTkcgUFJJTUFSWTwvVGV4dEhlYWRlcj5cclxuICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBzdHlsZT17eyBwYWRkaW5nOiAxMCB9fT5cclxuICAgICAgICB7cHJpbWFyeXMubWFwKChyb3csIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8Q29sIGtleT17aW5kZXh9IHNwYW49ezJ9PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgYmFja2dyb3VuZENvbG9yOiByb3cuY29sb3JOYW1lIH19XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaGVtZShyb3cuY29sb3JOYW1lKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cm93LmNvbG9yTmFtZX1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L1Jvdz5cclxuICAgICAgPFRleHRIZWFkZXIgdGhlbWU9e3N0YXRlLnRoZW1lfT5TRVRUSU5HIExBTkdVQUdFPC9UZXh0SGVhZGVyPlxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IHN0eWxlPXt7IHBhZGRpbmc6IDEwIH19PlxyXG4gICAgICAgIDxDb2wgc3Bhbj17Mn0+XHJcbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IG9uQ2xpY2s9eygpPT5zZXRMYW5ndWFnZShcIkVOXCIpfT5cclxuICAgICAgICAgICAgRU5HTElTSFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPENvbCBzcGFuPXsyfT5cclxuICAgICAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIiBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX0gb25DbGljaz17KCk9PnNldExhbmd1YWdlKFwiVEhcIil9PlxyXG4gICAgICAgICAgICBUSEFJXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0NvbD5cclxuICAgICAgPC9Sb3c+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBUZXh0SGVhZGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmctbGVmdDogMTZweDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICBib3gtc2hhZG93OiAwIDIuOHB4IDIuMnB4IHJnYigwIDAgMCAvIDMlKSwgMCA2LjdweCA1LjNweCByZ2IoMCAwIDAgLyA1JSksXHJcbiAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=