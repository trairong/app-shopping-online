webpackHotUpdate_N_E(1,{

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx",
    _s = $RefreshSig$();








var primarys = [{
  colorName: "#7f0000"
}, {
  colorName: "#b71c1c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#311b92"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#0d47a1"
}, {
  colorName: "#002f6c"
}, {
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#00363a"
}, {
  colorName: "#006064"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#212121"
}];
function Setting(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_3__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var setTheme = function setTheme(color) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  var setLanguage = function setLanguage(lang) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map(function (row, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
          span: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName,
              borderColor: row.colorName
            },
            onClick: function onClick() {
              return setTheme(row.colorName);
            },
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 15
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("EN");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, this), "ENGLISH"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("TH");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 92,
            columnNumber: 13
          }, this), "THAI"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 87,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Setting, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Setting;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = TextHeader;

var _c, _c2;

$RefreshReg$(_c, "Setting");
$RefreshReg$(_c2, "TextHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3giXSwibmFtZXMiOlsicHJpbWFyeXMiLCJjb2xvck5hbWUiLCJTZXR0aW5nIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwic2V0VGhlbWUiLCJjb2xvciIsIl9zZXRTdG9yYWdlIiwiS0VZX1NUT1JBR0UiLCJUSEVNRSIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsInBheWxvYWQiLCJwcmltYXJ5Iiwic2V0TGFuZ3VhZ2UiLCJsYW5nIiwiTEFORyIsImxhbmd1YWdlIiwidGhlbWUiLCJwYWRkaW5nIiwibWFwIiwicm93IiwiaW5kZXgiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiZm9udFNpemUiLCJUZXh0SGVhZGVyIiwic3R5bGVkIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLElBQU1BLFFBQVEsR0FBRyxDQUNmO0FBQUVDLFdBQVMsRUFBRTtBQUFiLENBRGUsRUFFZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUZlLEVBR2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FIZSxFQUlmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBSmUsRUFLZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUxlLEVBTWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FOZSxFQU9mO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBUGUsRUFRZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVJlLEVBU2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FUZSxFQVVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBVmUsRUFXZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVhlLEVBWWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FaZSxFQWFmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBYmUsQ0FBakI7QUFnQmUsU0FBU0MsT0FBVCxPQUEwQztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9CQUMzQkMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FEaUI7QUFBQSxNQUMvQ0MsS0FEK0MsZUFDL0NBLEtBRCtDO0FBQUEsTUFDeENDLFFBRHdDLGVBQ3hDQSxRQUR3Qzs7QUFFdkQsTUFBTUMsUUFBUSxHQUFHLFNBQVhBLFFBQVcsQ0FBQ0MsS0FBRCxFQUFXO0FBQzFCQyw0RUFBVyxDQUFDQyxzREFBVyxDQUFDQyxLQUFiLEVBQW9CQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUwsS0FBZixDQUFwQixDQUFYOztBQUNBTSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXlCUCxLQUF6QjtBQUVBRixZQUFRLENBQUM7QUFDUFUsVUFBSSxFQUFFLGFBREM7QUFFUEMsYUFBTyxFQUFFO0FBQ1BDLGVBQU8sRUFBRVY7QUFERjtBQUZGLEtBQUQsQ0FBUjtBQU1ELEdBVkQ7O0FBV0EsTUFBTVcsV0FBVyxHQUFHLFNBQWRBLFdBQWMsQ0FBQ0MsSUFBRCxFQUFVO0FBQzVCWCw0RUFBVyxDQUFDQyxzREFBVyxDQUFDVyxJQUFiLEVBQW1CVCxJQUFJLENBQUNDLFNBQUwsQ0FBZU8sSUFBZixDQUFuQixDQUFYOztBQUVBZCxZQUFRLENBQUM7QUFDUFUsVUFBSSxFQUFFLGNBREM7QUFFUEMsYUFBTyxFQUFFO0FBQ1BLLGdCQUFRLEVBQUVGO0FBREg7QUFGRixLQUFELENBQVI7QUFNRCxHQVREOztBQVVBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsVUFBRDtBQUFZLFdBQUssRUFBRWYsS0FBSyxDQUFDa0IsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUVFLHFFQUFDLHdDQUFEO0FBQUssWUFBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixXQUFLLEVBQUU7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBOUI7QUFBQSxnQkFDR3hCLFFBQVEsQ0FBQ3lCLEdBQVQsQ0FBYSxVQUFDQyxHQUFELEVBQU1DLEtBQU4sRUFBZ0I7QUFDNUIsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBaUIsY0FBSSxFQUFFLENBQXZCO0FBQUEsaUNBQ0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFO0FBQ0xDLG1CQUFLLEVBQUUsTUFERjtBQUVMQyw2QkFBZSxFQUFFSCxHQUFHLENBQUN6QixTQUZoQjtBQUdMNkIseUJBQVcsRUFBRUosR0FBRyxDQUFDekI7QUFIWixhQUZUO0FBT0UsbUJBQU8sRUFBRTtBQUFBLHFCQUFNTSxRQUFRLENBQUNtQixHQUFHLENBQUN6QixTQUFMLENBQWQ7QUFBQSxhQVBYO0FBQUEsc0JBU0d5QixHQUFHLENBQUN6QjtBQVRQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixXQUFVMEIsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGO0FBZUQsT0FoQkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFxQkUscUVBQUMsVUFBRDtBQUFZLFdBQUssRUFBRXRCLEtBQUssQ0FBQ2tCLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBckJGLGVBc0JFLHFFQUFDLHdDQUFEO0FBQUssWUFBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixXQUFLLEVBQUU7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBOUI7QUFBQSw4QkFDRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxDQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFDRSxjQUFJLEVBQUMsU0FEUDtBQUVFLGVBQUssRUFBRTtBQUFFSSxpQkFBSyxFQUFFO0FBQVQsV0FGVDtBQUdFLGlCQUFPLEVBQUU7QUFBQSxtQkFBTVQsV0FBVyxDQUFDLElBQUQsQ0FBakI7QUFBQSxXQUhYO0FBQUEsa0NBS0UscUVBQUMsZ0VBQUQ7QUFDRSxpQkFBSyxFQUFFO0FBQUVZLHNCQUFRLEVBQUU7QUFBWjtBQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBYUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFJLEVBQUUsQ0FBWDtBQUFBLCtCQUNFLHFFQUFDLDJDQUFEO0FBQ0UsY0FBSSxFQUFDLFNBRFA7QUFFRSxlQUFLLEVBQUU7QUFBRUgsaUJBQUssRUFBRTtBQUFULFdBRlQ7QUFHRSxpQkFBTyxFQUFFO0FBQUEsbUJBQU1ULFdBQVcsQ0FBQyxJQUFELENBQWpCO0FBQUEsV0FIWDtBQUFBLGtDQUtFLHFFQUFDLGdFQUFEO0FBQ0UsaUJBQUssRUFBRTtBQUFFWSxzQkFBUSxFQUFFO0FBQVo7QUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF0QkY7QUFBQSxrQkFERjtBQW1ERDs7R0ExRXVCN0IsTzs7S0FBQUEsTztBQTRFeEIsSUFBTThCLFVBQVUsR0FBR0MseURBQU0sQ0FBQ0MsR0FBVjtBQUFBO0FBQUE7QUFBQSxvWUFJTDtBQUFBLE1BQUdYLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0wsT0FBckI7QUFBQSxDQUpLLENBQWhCO01BQU1jLFUiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svMS5mMjA2MjIyZTAwM2E0M2RiMGU4ZS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQnV0dG9uLCBDb2wsIFJvdyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IF9zZXRTdG9yYWdlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2xvY2FsLXN0b3JhZ2VcIjtcclxuaW1wb3J0IHsgS0VZX1NUT1JBR0UgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzXCI7XHJcbmltcG9ydCB7IEdsb2JhbE91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmNvbnN0IHByaW1hcnlzID0gW1xyXG4gIHsgY29sb3JOYW1lOiBcIiM3ZjAwMDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiNiNzFjMWNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM4ODBlNGZcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMzMTFiOTJcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMxYTIzN2VcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwZDQ3YTFcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDJmNmNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyNjMyMzhcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDRkNDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDM2M2FcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDYwNjRcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM0YTE0OGNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyMTIxMjFcIiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2V0dGluZyh7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIGNvbnN0IHNldFRoZW1lID0gKGNvbG9yKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5USEVNRSwgSlNPTi5zdHJpbmdpZnkoY29sb3IpKTtcclxuICAgIGNvbnNvbGUubG9nKFwiVGhlbWUgPT4gXCIsIGNvbG9yKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1BSSU1BUllcIixcclxuICAgICAgcGF5bG9hZDoge1xyXG4gICAgICAgIHByaW1hcnk6IGNvbG9yLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBzZXRMYW5ndWFnZSA9IChsYW5nKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5MQU5HLCBKU09OLnN0cmluZ2lmeShsYW5nKSk7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9MQU5HVUFHRVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgbGFuZ3VhZ2U6IGxhbmcsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlNFVFRJTkcgUFJJTUFSWTwvVGV4dEhlYWRlcj5cclxuICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBzdHlsZT17eyBwYWRkaW5nOiAxMCB9fT5cclxuICAgICAgICB7cHJpbWFyeXMubWFwKChyb3csIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8Q29sIGtleT17aW5kZXh9IHNwYW49ezN9PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiByb3cuY29sb3JOYW1lLFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogcm93LmNvbG9yTmFtZSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaGVtZShyb3cuY29sb3JOYW1lKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cm93LmNvbG9yTmFtZX1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L1Jvdz5cclxuICAgICAgPFRleHRIZWFkZXIgdGhlbWU9e3N0YXRlLnRoZW1lfT5TRVRUSU5HIExBTkdVQUdFPC9UZXh0SGVhZGVyPlxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IHN0eWxlPXt7IHBhZGRpbmc6IDEwIH19PlxyXG4gICAgICAgIDxDb2wgc3Bhbj17M30+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExhbmd1YWdlKFwiRU5cIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxHbG9iYWxPdXRsaW5lZFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiAyMH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIEVOR0xJU0hcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDxDb2wgc3Bhbj17M30+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExhbmd1YWdlKFwiVEhcIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxHbG9iYWxPdXRsaW5lZFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiAyMH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIFRIQUlcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICA8L1Jvdz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IFRleHRIZWFkZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNTBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcbiAgLW1vei1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIGJveC1zaGFkb3c6IDAgMi44cHggMi4ycHggcmdiKDAgMCAwIC8gMyUpLCAwIDYuN3B4IDUuM3B4IHJnYigwIDAgMCAvIDUlKSxcclxuICAgIDAgMTIuNXB4IDEwcHggcmdiKDAgMCAwIC8gNiUpLCAwIDM5LjNweCAxNy45cHggcmdiKDAgMCAwIC8gMCUpLFxyXG4gICAgMCA0MS44cHggMzMuNHB4IHJnYigwIDAgMCAvIDAlKSwgMCAxMDBweCA4MHB4IHJnYigwIDAgMCAvIDAlKTtcclxuYDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==