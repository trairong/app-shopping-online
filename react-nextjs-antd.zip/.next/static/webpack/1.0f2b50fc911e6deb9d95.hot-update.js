webpackHotUpdate_N_E(1,{

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx",
    _s = $RefreshSig$();








var primarys = [{
  colorName: "#b71c1c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#311b92"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#0d47a1"
}, {
  colorName: "#002f6c"
}, {
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#212121"
}];
function Setting(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_3__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var setTheme = function setTheme(color) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  var setLanguage = function setLanguage(lang) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map(function (row, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
          span: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName,
              borderColor: row.colorName
            },
            onClick: function onClick() {
              return setTheme(row.colorName);
            },
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 54,
            columnNumber: 15
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("EN");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 13
          }, this), "ENGLISH"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("TH");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 13
          }, this), "THAI"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Setting, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Setting;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = TextHeader;

var _c, _c2;

$RefreshReg$(_c, "Setting");
$RefreshReg$(_c2, "TextHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3giXSwibmFtZXMiOlsicHJpbWFyeXMiLCJjb2xvck5hbWUiLCJTZXR0aW5nIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwic2V0VGhlbWUiLCJjb2xvciIsIl9zZXRTdG9yYWdlIiwiS0VZX1NUT1JBR0UiLCJUSEVNRSIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zb2xlIiwibG9nIiwidHlwZSIsInBheWxvYWQiLCJwcmltYXJ5Iiwic2V0TGFuZ3VhZ2UiLCJsYW5nIiwiTEFORyIsImxhbmd1YWdlIiwidGhlbWUiLCJwYWRkaW5nIiwibWFwIiwicm93IiwiaW5kZXgiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiZm9udFNpemUiLCJUZXh0SGVhZGVyIiwic3R5bGVkIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLElBQU1BLFFBQVEsR0FBRyxDQUNmO0FBQUVDLFdBQVMsRUFBRTtBQUFiLENBRGUsRUFFZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUZlLEVBR2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FIZSxFQUlmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBSmUsRUFLZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUxlLEVBTWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FOZSxFQU9mO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBUGUsRUFRZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVJlLEVBU2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FUZSxFQVVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBVmUsQ0FBakI7QUFhZSxTQUFTQyxPQUFULE9BQTBDO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsb0JBQzNCQyx3REFBVSxDQUFDQyxnREFBRCxDQURpQjtBQUFBLE1BQy9DQyxLQUQrQyxlQUMvQ0EsS0FEK0M7QUFBQSxNQUN4Q0MsUUFEd0MsZUFDeENBLFFBRHdDOztBQUV2RCxNQUFNQyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxDQUFDQyxLQUFELEVBQVc7QUFDMUJDLDRFQUFXLENBQUNDLHNEQUFXLENBQUNDLEtBQWIsRUFBb0JDLElBQUksQ0FBQ0MsU0FBTCxDQUFlTCxLQUFmLENBQXBCLENBQVg7O0FBQ0FNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBeUJQLEtBQXpCO0FBRUFGLFlBQVEsQ0FBQztBQUNQVSxVQUFJLEVBQUUsYUFEQztBQUVQQyxhQUFPLEVBQUU7QUFDUEMsZUFBTyxFQUFFVjtBQURGO0FBRkYsS0FBRCxDQUFSO0FBTUQsR0FWRDs7QUFXQSxNQUFNVyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDQyxJQUFELEVBQVU7QUFDNUJYLDRFQUFXLENBQUNDLHNEQUFXLENBQUNXLElBQWIsRUFBbUJULElBQUksQ0FBQ0MsU0FBTCxDQUFlTyxJQUFmLENBQW5CLENBQVg7O0FBRUFkLFlBQVEsQ0FBQztBQUNQVSxVQUFJLEVBQUUsY0FEQztBQUVQQyxhQUFPLEVBQUU7QUFDUEssZ0JBQVEsRUFBRUY7QUFESDtBQUZGLEtBQUQsQ0FBUjtBQU1ELEdBVEQ7O0FBVUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxVQUFEO0FBQVksV0FBSyxFQUFFZixLQUFLLENBQUNrQixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLGdCQUNHeEIsUUFBUSxDQUFDeUIsR0FBVCxDQUFhLFVBQUNDLEdBQUQsRUFBTUMsS0FBTixFQUFnQjtBQUM1Qiw0QkFDRSxxRUFBQyx3Q0FBRDtBQUFpQixjQUFJLEVBQUUsQ0FBdkI7QUFBQSxpQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUU7QUFDTEMsbUJBQUssRUFBRSxNQURGO0FBRUxDLDZCQUFlLEVBQUVILEdBQUcsQ0FBQ3pCLFNBRmhCO0FBR0w2Qix5QkFBVyxFQUFFSixHQUFHLENBQUN6QjtBQUhaLGFBRlQ7QUFPRSxtQkFBTyxFQUFFO0FBQUEscUJBQU1NLFFBQVEsQ0FBQ21CLEdBQUcsQ0FBQ3pCLFNBQUwsQ0FBZDtBQUFBLGFBUFg7QUFBQSxzQkFTR3lCLEdBQUcsQ0FBQ3pCO0FBVFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFdBQVUwQixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFlRCxPQWhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRixlQXFCRSxxRUFBQyxVQUFEO0FBQVksV0FBSyxFQUFFdEIsS0FBSyxDQUFDa0IsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyQkYsZUFzQkUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLDhCQUNFLHFFQUFDLHdDQUFEO0FBQUssWUFBSSxFQUFFLENBQVg7QUFBQSwrQkFDRSxxRUFBQywyQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsZUFBSyxFQUFFO0FBQUVJLGlCQUFLLEVBQUU7QUFBVCxXQUZUO0FBR0UsaUJBQU8sRUFBRTtBQUFBLG1CQUFNVCxXQUFXLENBQUMsSUFBRCxDQUFqQjtBQUFBLFdBSFg7QUFBQSxrQ0FLRSxxRUFBQyxnRUFBRDtBQUNFLGlCQUFLLEVBQUU7QUFBRVksc0JBQVEsRUFBRTtBQUFaO0FBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFhRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxDQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFDRSxjQUFJLEVBQUMsU0FEUDtBQUVFLGVBQUssRUFBRTtBQUFFSCxpQkFBSyxFQUFFO0FBQVQsV0FGVDtBQUdFLGlCQUFPLEVBQUU7QUFBQSxtQkFBTVQsV0FBVyxDQUFDLElBQUQsQ0FBakI7QUFBQSxXQUhYO0FBQUEsa0NBS0UscUVBQUMsZ0VBQUQ7QUFDRSxpQkFBSyxFQUFFO0FBQUVZLHNCQUFRLEVBQUU7QUFBWjtBQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXRCRjtBQUFBLGtCQURGO0FBbUREOztHQTFFdUI3QixPOztLQUFBQSxPO0FBNEV4QixJQUFNOEIsVUFBVSxHQUFHQyx5REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLG9ZQUlMO0FBQUEsTUFBR1gsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTCxPQUFyQjtBQUFBLENBSkssQ0FBaEI7TUFBTWMsVSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay8xLjBmMmI1MGZjOTExZTZkZWI5ZDk1LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50LCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY29udGV4dFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBCdXR0b24sIENvbCwgUm93IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgX3NldFN0b3JhZ2UgfSBmcm9tIFwiLi4vLi4vdXRpbHMvbG9jYWwtc3RvcmFnZVwiO1xyXG5pbXBvcnQgeyBLRVlfU1RPUkFHRSB9IGZyb20gXCIuLi8uLi9jb25zdGFudHNcIjtcclxuaW1wb3J0IHsgR2xvYmFsT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5cclxuY29uc3QgcHJpbWFyeXMgPSBbXHJcbiAgeyBjb2xvck5hbWU6IFwiI2I3MWMxY1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzg4MGU0ZlwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzMxMWI5MlwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzFhMjM3ZVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzBkNDdhMVwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwMmY2Y1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzI2MzIzOFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzAwNGQ0MFwiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzRhMTQ4Y1wiIH0sXHJcbiAgeyBjb2xvck5hbWU6IFwiIzIxMjEyMVwiIH0sXHJcbl07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXR0aW5nKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3Qgc2V0VGhlbWUgPSAoY29sb3IpID0+IHtcclxuICAgIF9zZXRTdG9yYWdlKEtFWV9TVE9SQUdFLlRIRU1FLCBKU09OLnN0cmluZ2lmeShjb2xvcikpO1xyXG4gICAgY29uc29sZS5sb2coXCJUaGVtZSA9PiBcIiwgY29sb3IpO1xyXG5cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogXCJTRVRfUFJJTUFSWVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcHJpbWFyeTogY29sb3IsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIGNvbnN0IHNldExhbmd1YWdlID0gKGxhbmcpID0+IHtcclxuICAgIF9zZXRTdG9yYWdlKEtFWV9TVE9SQUdFLkxBTkcsIEpTT04uc3RyaW5naWZ5KGxhbmcpKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX0xBTkdVQUdFXCIsXHJcbiAgICAgIHBheWxvYWQ6IHtcclxuICAgICAgICBsYW5ndWFnZTogbGFuZyxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxUZXh0SGVhZGVyIHRoZW1lPXtzdGF0ZS50aGVtZX0+U0VUVElORyBQUklNQVJZPC9UZXh0SGVhZGVyPlxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IHN0eWxlPXt7IHBhZGRpbmc6IDEwIH19PlxyXG4gICAgICAgIHtwcmltYXJ5cy5tYXAoKHJvdywgaW5kZXgpID0+IHtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxDb2wga2V5PXtpbmRleH0gc3Bhbj17M30+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHJvdy5jb2xvck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiByb3cuY29sb3JOYW1lLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRoZW1lKHJvdy5jb2xvck5hbWUpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtyb3cuY29sb3JOYW1lfVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvUm93PlxyXG4gICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlNFVFRJTkcgTEFOR1VBR0U8L1RleHRIZWFkZXI+XHJcbiAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgcGFkZGluZzogMTAgfX0+XHJcbiAgICAgICAgPENvbCBzcGFuPXszfT5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZ3VhZ2UoXCJFTlwiKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEdsb2JhbE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IDIwfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgRU5HTElTSFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPENvbCBzcGFuPXszfT5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZ3VhZ2UoXCJUSFwiKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEdsb2JhbE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IDIwfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgVEhBSVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Db2w+XHJcbiAgICAgIDwvUm93PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgVGV4dEhlYWRlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9