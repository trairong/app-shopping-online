webpackHotUpdate_N_E("pages/index",{

/***/ "./src/languages/index.ts":
/*!********************************!*\
  !*** ./src/languages/index.ts ***!
  \********************************/
/*! exports provided: Language */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Language", function() { return Language; });
var langTH = {
  TITLE: ["ค้นหา", "Search"],
  RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
};
var Language = function Language(lang) {
  var SetLanguage = {};
  var indexTH = 0;
  var indexEN = 1;
  var Language = {
    Home: ["หน้าแรก", "HOME"],
    ProductType: ["หมวดสินค้า", "PRODUCT TYPE"],
    ProductList: ["สินค้าที่เลือก", "PRODUCT LIST"],
    ProductHistory: ["สินค้าที่สั่งซื้อแล้ว", "PRODUCT HISTORY"],
    ProductShipping: ["สินค้ากำลังจัดส่ง", "PRODUCT SHIPPING"],
    setting: ["ตั้งค้า", "SETTING"],
    Search: ["ค้นหา", "Search"],
    RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
  };

  var getTH = function getTH() {
    SetLanguage.Home = Language.Home[indexTH];
    SetLanguage.ProductType = Language.ProductType[indexTH];
    SetLanguage.ProductList = Language.ProductList[indexTH];
    SetLanguage.ProductHistory = Language.ProductHistory[indexTH];
    SetLanguage.ProductShipping = Language.ProductShipping[indexTH];
    SetLanguage.setting = Language.setting[indexTH];
    SetLanguage.Search = Language.Search[indexTH];
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexTH];
    return SetLanguage;
  };

  var getEN = function getEN() {
    SetLanguage.Home = Language.Home[indexEN];
    SetLanguage.ProductType = Language.ProductType[indexEN];
    SetLanguage.ProductList = Language.ProductList[indexEN];
    SetLanguage.ProductHistory = Language.ProductHistory[indexEN];
    SetLanguage.ProductShipping = Language.ProductShipping[indexEN];
    SetLanguage.setting = Language.setting[indexEN];
    SetLanguage.Search = Language.Search[indexEN];
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexEN];
    return SetLanguage;
  };

  if (lang.toUpperCase() == "TH") {
    return getTH();
  }

  return getEN();
};
_c = Language;

var _c;

$RefreshReg$(_c, "Language");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2xhbmd1YWdlcy9pbmRleC50cyJdLCJuYW1lcyI6WyJsYW5nVEgiLCJUSVRMRSIsIlJlY29tbWVuZGVkUHJvZHVjdHMiLCJMYW5ndWFnZSIsImxhbmciLCJTZXRMYW5ndWFnZSIsImluZGV4VEgiLCJpbmRleEVOIiwiSG9tZSIsIlByb2R1Y3RUeXBlIiwiUHJvZHVjdExpc3QiLCJQcm9kdWN0SGlzdG9yeSIsIlByb2R1Y3RTaGlwcGluZyIsInNldHRpbmciLCJTZWFyY2giLCJnZXRUSCIsImdldEVOIiwidG9VcHBlckNhc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUEsSUFBTUEsTUFBTSxHQUFHO0FBQ2JDLE9BQUssRUFBRSxDQUFDLE9BQUQsRUFBVSxRQUFWLENBRE07QUFFYkMscUJBQW1CLEVBQUUsQ0FBQyxhQUFELEVBQWdCLHNCQUFoQjtBQUZSLENBQWY7QUFLTyxJQUFNQyxRQUFRLEdBQUcsa0JBQUNDLElBQUQsRUFBa0I7QUFDeEMsTUFBSUMsV0FBZ0IsR0FBRyxFQUF2QjtBQUNBLE1BQUlDLE9BQU8sR0FBRyxDQUFkO0FBQ0EsTUFBSUMsT0FBTyxHQUFHLENBQWQ7QUFFQSxNQUFNSixRQUFRLEdBQUc7QUFDZkssUUFBSSxFQUFFLENBQUMsU0FBRCxFQUFZLE1BQVosQ0FEUztBQUVmQyxlQUFXLEVBQUUsQ0FBQyxZQUFELEVBQWUsY0FBZixDQUZFO0FBR2ZDLGVBQVcsRUFBRSxDQUFDLGdCQUFELEVBQW1CLGNBQW5CLENBSEU7QUFJZkMsa0JBQWMsRUFBRSxDQUFDLHVCQUFELEVBQTBCLGlCQUExQixDQUpEO0FBS2ZDLG1CQUFlLEVBQUUsQ0FBQyxtQkFBRCxFQUFzQixrQkFBdEIsQ0FMRjtBQU1mQyxXQUFPLEVBQUUsQ0FBQyxTQUFELEVBQVksU0FBWixDQU5NO0FBT2ZDLFVBQU0sRUFBRSxDQUFDLE9BQUQsRUFBVSxRQUFWLENBUE87QUFRZlosdUJBQW1CLEVBQUUsQ0FBQyxhQUFELEVBQWdCLHNCQUFoQjtBQVJOLEdBQWpCOztBQVVBLE1BQU1hLEtBQUssR0FBRyxTQUFSQSxLQUFRLEdBQU07QUFDaEJWLGVBQVcsQ0FBQ0csSUFBWixHQUFtQkwsUUFBUSxDQUFDSyxJQUFULENBQWNGLE9BQWQsQ0FBbkI7QUFDQUQsZUFBVyxDQUFDSSxXQUFaLEdBQTBCTixRQUFRLENBQUNNLFdBQVQsQ0FBcUJILE9BQXJCLENBQTFCO0FBQ0FELGVBQVcsQ0FBQ0ssV0FBWixHQUEwQlAsUUFBUSxDQUFDTyxXQUFULENBQXFCSixPQUFyQixDQUExQjtBQUNBRCxlQUFXLENBQUNNLGNBQVosR0FBNkJSLFFBQVEsQ0FBQ1EsY0FBVCxDQUF3QkwsT0FBeEIsQ0FBN0I7QUFDQUQsZUFBVyxDQUFDTyxlQUFaLEdBQThCVCxRQUFRLENBQUNTLGVBQVQsQ0FBeUJOLE9BQXpCLENBQTlCO0FBQ0FELGVBQVcsQ0FBQ1EsT0FBWixHQUFzQlYsUUFBUSxDQUFDVSxPQUFULENBQWlCUCxPQUFqQixDQUF0QjtBQUNBRCxlQUFXLENBQUNTLE1BQVosR0FBcUJYLFFBQVEsQ0FBQ1csTUFBVCxDQUFnQlIsT0FBaEIsQ0FBckI7QUFDQUQsZUFBVyxDQUFDSCxtQkFBWixHQUFrQ0MsUUFBUSxDQUFDRCxtQkFBVCxDQUE2QkksT0FBN0IsQ0FBbEM7QUFDRixXQUFPRCxXQUFQO0FBQ0QsR0FWRDs7QUFXQSxNQUFNVyxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFNO0FBQ2hCWCxlQUFXLENBQUNHLElBQVosR0FBbUJMLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjRCxPQUFkLENBQW5CO0FBQ0FGLGVBQVcsQ0FBQ0ksV0FBWixHQUEwQk4sUUFBUSxDQUFDTSxXQUFULENBQXFCRixPQUFyQixDQUExQjtBQUNBRixlQUFXLENBQUNLLFdBQVosR0FBMEJQLFFBQVEsQ0FBQ08sV0FBVCxDQUFxQkgsT0FBckIsQ0FBMUI7QUFDQUYsZUFBVyxDQUFDTSxjQUFaLEdBQTZCUixRQUFRLENBQUNRLGNBQVQsQ0FBd0JKLE9BQXhCLENBQTdCO0FBQ0FGLGVBQVcsQ0FBQ08sZUFBWixHQUE4QlQsUUFBUSxDQUFDUyxlQUFULENBQXlCTCxPQUF6QixDQUE5QjtBQUNBRixlQUFXLENBQUNRLE9BQVosR0FBc0JWLFFBQVEsQ0FBQ1UsT0FBVCxDQUFpQk4sT0FBakIsQ0FBdEI7QUFDQUYsZUFBVyxDQUFDUyxNQUFaLEdBQXFCWCxRQUFRLENBQUNXLE1BQVQsQ0FBZ0JQLE9BQWhCLENBQXJCO0FBQ0FGLGVBQVcsQ0FBQ0gsbUJBQVosR0FBa0NDLFFBQVEsQ0FBQ0QsbUJBQVQsQ0FBNkJLLE9BQTdCLENBQWxDO0FBQ0YsV0FBT0YsV0FBUDtBQUNELEdBVkQ7O0FBWUEsTUFBSUQsSUFBSSxDQUFDYSxXQUFMLE1BQXNCLElBQTFCLEVBQWdDO0FBQzlCLFdBQU9GLEtBQUssRUFBWjtBQUNEOztBQUNELFNBQU9DLEtBQUssRUFBWjtBQUNELENBMUNNO0tBQU1iLFEiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNGNlMGQ1NjJhNDhlNDRkM2Q1MDQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGxhbmdUSCA9IHtcclxuICBUSVRMRTogW1wi4LiE4LmJ4LiZ4Lir4LiyXCIsIFwiU2VhcmNoXCJdLFxyXG4gIFJlY29tbWVuZGVkUHJvZHVjdHM6IFtcIuC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1wiLCBcIlJlY29tbWVuZGVkIFByb2R1Y3RzXCJdLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IExhbmd1YWdlID0gKGxhbmc6IHN0cmluZykgPT4ge1xyXG4gIGxldCBTZXRMYW5ndWFnZTogYW55ID0ge307XHJcbiAgbGV0IGluZGV4VEggPSAwO1xyXG4gIGxldCBpbmRleEVOID0gMTtcclxuXHJcbiAgY29uc3QgTGFuZ3VhZ2UgPSB7XHJcbiAgICBIb21lOiBbXCLguKvguJnguYnguLLguYHguKPguIFcIiwgXCJIT01FXCJdLFxyXG4gICAgUHJvZHVjdFR5cGU6IFtcIuC4q+C4oeC4p+C4lOC4quC4tOC4meC4hOC5ieC4slwiLCBcIlBST0RVQ1QgVFlQRVwiXSxcclxuICAgIFByb2R1Y3RMaXN0OiBbXCLguKrguLTguJnguITguYnguLLguJfguLXguYjguYDguKXguLfguK3guIFcIiwgXCJQUk9EVUNUIExJU1RcIl0sXHJcbiAgICBQcm9kdWN0SGlzdG9yeTogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LiX4Li14LmI4Liq4Lix4LmI4LiH4LiL4Li34LmJ4Lit4LmB4Lil4LmJ4LinXCIsIFwiUFJPRFVDVCBISVNUT1JZXCJdLFxyXG4gICAgUHJvZHVjdFNoaXBwaW5nOiBbXCLguKrguLTguJnguITguYnguLLguIHguLPguKXguLHguIfguIjguLHguJTguKrguYjguIdcIiwgXCJQUk9EVUNUIFNISVBQSU5HXCJdLFxyXG4gICAgc2V0dGluZzogW1wi4LiV4Lix4LmJ4LiH4LiE4LmJ4LiyXCIsIFwiU0VUVElOR1wiXSxcclxuICAgIFNlYXJjaDogW1wi4LiE4LmJ4LiZ4Lir4LiyXCIsIFwiU2VhcmNoXCJdLFxyXG4gICAgUmVjb21tZW5kZWRQcm9kdWN0czogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LmB4LiZ4Liw4LiZ4LizXCIsIFwiUmVjb21tZW5kZWQgUHJvZHVjdHNcIl0sXHJcbiAgfTtcclxuICBjb25zdCBnZXRUSCA9ICgpID0+IHtcclxuICAgICAgU2V0TGFuZ3VhZ2UuSG9tZSA9IExhbmd1YWdlLkhvbWVbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RUeXBlID0gTGFuZ3VhZ2UuUHJvZHVjdFR5cGVbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RMaXN0ID0gTGFuZ3VhZ2UuUHJvZHVjdExpc3RbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RIaXN0b3J5ID0gTGFuZ3VhZ2UuUHJvZHVjdEhpc3RvcnlbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RTaGlwcGluZyA9IExhbmd1YWdlLlByb2R1Y3RTaGlwcGluZ1tpbmRleFRIXTtcclxuICAgICAgU2V0TGFuZ3VhZ2Uuc2V0dGluZyA9IExhbmd1YWdlLnNldHRpbmdbaW5kZXhUSF07XHJcbiAgICAgIFNldExhbmd1YWdlLlNlYXJjaCA9IExhbmd1YWdlLlNlYXJjaFtpbmRleFRIXTtcclxuICAgICAgU2V0TGFuZ3VhZ2UuUmVjb21tZW5kZWRQcm9kdWN0cyA9IExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHNbaW5kZXhUSF07XHJcbiAgICByZXR1cm4gU2V0TGFuZ3VhZ2U7XHJcbiAgfTtcclxuICBjb25zdCBnZXRFTiA9ICgpID0+IHtcclxuICAgICAgU2V0TGFuZ3VhZ2UuSG9tZSA9IExhbmd1YWdlLkhvbWVbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RUeXBlID0gTGFuZ3VhZ2UuUHJvZHVjdFR5cGVbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RMaXN0ID0gTGFuZ3VhZ2UuUHJvZHVjdExpc3RbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RIaXN0b3J5ID0gTGFuZ3VhZ2UuUHJvZHVjdEhpc3RvcnlbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlByb2R1Y3RTaGlwcGluZyA9IExhbmd1YWdlLlByb2R1Y3RTaGlwcGluZ1tpbmRleEVOXTtcclxuICAgICAgU2V0TGFuZ3VhZ2Uuc2V0dGluZyA9IExhbmd1YWdlLnNldHRpbmdbaW5kZXhFTl07XHJcbiAgICAgIFNldExhbmd1YWdlLlNlYXJjaCA9IExhbmd1YWdlLlNlYXJjaFtpbmRleEVOXTtcclxuICAgICAgU2V0TGFuZ3VhZ2UuUmVjb21tZW5kZWRQcm9kdWN0cyA9IExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHNbaW5kZXhFTl07XHJcbiAgICByZXR1cm4gU2V0TGFuZ3VhZ2U7XHJcbiAgfTtcclxuXHJcbiAgaWYgKGxhbmcudG9VcHBlckNhc2UoKSA9PSBcIlRIXCIpIHtcclxuICAgIHJldHVybiBnZXRUSCgpO1xyXG4gIH1cclxuICByZXR1cm4gZ2V0RU4oKTtcclxufTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==