webpackHotUpdate_N_E("pages/index",{

/***/ "./src/languages/index.ts":
/*!********************************!*\
  !*** ./src/languages/index.ts ***!
  \********************************/
/*! exports provided: Language */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Language", function() { return Language; });
var langTH = {
  TITLE: ["ค้นหา", "Search"],
  RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
};
var Language = function Language(lang) {
  var SetLanguage = {};
  var indexTH = 0;
  var indexEN = 1;
  var Language = {
    Home: ["หน้าแรก", "HOME"],
    ProductType: ["หมวดสินค้า", "PRODUCT TYPE"],
    Search: ["ค้นหา", "Search"],
    RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
  };

  var getTH = function getTH() {
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexTH];
    SetLanguage.Home = Language.Home[indexTH];
    SetLanguage.ProductType = Language.ProductType[indexTH];
    return SetLanguage;
  };

  var getEN = function getEN() {
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexEN];
    SetLanguage.Home = Language.Home[indexEN];
    SetLanguage.ProductType = Language.ProductType[indexEN];
    return SetLanguage;
  };

  if (lang.toUpperCase() == "TH") {
    return getTH();
  }

  return getEN();
};
_c = Language;

var _c;

$RefreshReg$(_c, "Language");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2xhbmd1YWdlcy9pbmRleC50cyJdLCJuYW1lcyI6WyJsYW5nVEgiLCJUSVRMRSIsIlJlY29tbWVuZGVkUHJvZHVjdHMiLCJMYW5ndWFnZSIsImxhbmciLCJTZXRMYW5ndWFnZSIsImluZGV4VEgiLCJpbmRleEVOIiwiSG9tZSIsIlByb2R1Y3RUeXBlIiwiU2VhcmNoIiwiZ2V0VEgiLCJnZXRFTiIsInRvVXBwZXJDYXNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBLElBQU1BLE1BQU0sR0FBRztBQUNiQyxPQUFLLEVBQUUsQ0FBQyxPQUFELEVBQVUsUUFBVixDQURNO0FBRWJDLHFCQUFtQixFQUFFLENBQUMsYUFBRCxFQUFnQixzQkFBaEI7QUFGUixDQUFmO0FBS08sSUFBTUMsUUFBUSxHQUFHLGtCQUFDQyxJQUFELEVBQWtCO0FBQ3hDLE1BQUlDLFdBQWdCLEdBQUcsRUFBdkI7QUFDQSxNQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUNBLE1BQUlDLE9BQU8sR0FBRyxDQUFkO0FBRUEsTUFBTUosUUFBUSxHQUFHO0FBQ2ZLLFFBQUksRUFBRSxDQUFDLFNBQUQsRUFBWSxNQUFaLENBRFM7QUFFZkMsZUFBVyxFQUFFLENBQUMsWUFBRCxFQUFlLGNBQWYsQ0FGRTtBQUdmQyxVQUFNLEVBQUUsQ0FBQyxPQUFELEVBQVUsUUFBVixDQUhPO0FBSWZSLHVCQUFtQixFQUFFLENBQUMsYUFBRCxFQUFnQixzQkFBaEI7QUFKTixHQUFqQjs7QUFNQSxNQUFNUyxLQUFLLEdBQUcsU0FBUkEsS0FBUSxHQUFNO0FBQ2xCTixlQUFXLENBQUNILG1CQUFaLEdBQWtDQyxRQUFRLENBQUNELG1CQUFULENBQTZCSSxPQUE3QixDQUFsQztBQUNBRCxlQUFXLENBQUNHLElBQVosR0FBbUJMLFFBQVEsQ0FBQ0ssSUFBVCxDQUFjRixPQUFkLENBQW5CO0FBQ0FELGVBQVcsQ0FBQ0ksV0FBWixHQUEwQk4sUUFBUSxDQUFDTSxXQUFULENBQXFCSCxPQUFyQixDQUExQjtBQUNBLFdBQU9ELFdBQVA7QUFDRCxHQUxEOztBQU1BLE1BQU1PLEtBQUssR0FBRyxTQUFSQSxLQUFRLEdBQU07QUFDbEJQLGVBQVcsQ0FBQ0gsbUJBQVosR0FBa0NDLFFBQVEsQ0FBQ0QsbUJBQVQsQ0FBNkJLLE9BQTdCLENBQWxDO0FBQ0FGLGVBQVcsQ0FBQ0csSUFBWixHQUFtQkwsUUFBUSxDQUFDSyxJQUFULENBQWNELE9BQWQsQ0FBbkI7QUFDQUYsZUFBVyxDQUFDSSxXQUFaLEdBQTBCTixRQUFRLENBQUNNLFdBQVQsQ0FBcUJGLE9BQXJCLENBQTFCO0FBQ0EsV0FBT0YsV0FBUDtBQUNELEdBTEQ7O0FBT0EsTUFBSUQsSUFBSSxDQUFDUyxXQUFMLE1BQXNCLElBQTFCLEVBQWdDO0FBQzlCLFdBQU9GLEtBQUssRUFBWjtBQUNEOztBQUNELFNBQU9DLEtBQUssRUFBWjtBQUNELENBNUJNO0tBQU1ULFEiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguOWQ1NTAzYmJlYTRhOTlkNzJmNGMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGxhbmdUSCA9IHtcclxuICBUSVRMRTogW1wi4LiE4LmJ4LiZ4Lir4LiyXCIsIFwiU2VhcmNoXCJdLFxyXG4gIFJlY29tbWVuZGVkUHJvZHVjdHM6IFtcIuC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1wiLCBcIlJlY29tbWVuZGVkIFByb2R1Y3RzXCJdLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IExhbmd1YWdlID0gKGxhbmc6IHN0cmluZykgPT4ge1xyXG4gIGxldCBTZXRMYW5ndWFnZTogYW55ID0ge307XHJcbiAgbGV0IGluZGV4VEggPSAwO1xyXG4gIGxldCBpbmRleEVOID0gMTtcclxuXHJcbiAgY29uc3QgTGFuZ3VhZ2UgPSB7XHJcbiAgICBIb21lOiBbXCLguKvguJnguYnguLLguYHguKPguIFcIiwgXCJIT01FXCJdLFxyXG4gICAgUHJvZHVjdFR5cGU6IFtcIuC4q+C4oeC4p+C4lOC4quC4tOC4meC4hOC5ieC4slwiLCBcIlBST0RVQ1QgVFlQRVwiXSxcclxuICAgIFNlYXJjaDogW1wi4LiE4LmJ4LiZ4Lir4LiyXCIsIFwiU2VhcmNoXCJdLFxyXG4gICAgUmVjb21tZW5kZWRQcm9kdWN0czogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LmB4LiZ4Liw4LiZ4LizXCIsIFwiUmVjb21tZW5kZWQgUHJvZHVjdHNcIl0sXHJcbiAgfTtcclxuICBjb25zdCBnZXRUSCA9ICgpID0+IHtcclxuICAgIFNldExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHMgPSBMYW5ndWFnZS5SZWNvbW1lbmRlZFByb2R1Y3RzW2luZGV4VEhdO1xyXG4gICAgU2V0TGFuZ3VhZ2UuSG9tZSA9IExhbmd1YWdlLkhvbWVbaW5kZXhUSF07XHJcbiAgICBTZXRMYW5ndWFnZS5Qcm9kdWN0VHlwZSA9IExhbmd1YWdlLlByb2R1Y3RUeXBlW2luZGV4VEhdO1xyXG4gICAgcmV0dXJuIFNldExhbmd1YWdlO1xyXG4gIH07XHJcbiAgY29uc3QgZ2V0RU4gPSAoKSA9PiB7XHJcbiAgICBTZXRMYW5ndWFnZS5SZWNvbW1lbmRlZFByb2R1Y3RzID0gTGFuZ3VhZ2UuUmVjb21tZW5kZWRQcm9kdWN0c1tpbmRleEVOXTtcclxuICAgIFNldExhbmd1YWdlLkhvbWUgPSBMYW5ndWFnZS5Ib21lW2luZGV4RU5dO1xyXG4gICAgU2V0TGFuZ3VhZ2UuUHJvZHVjdFR5cGUgPSBMYW5ndWFnZS5Qcm9kdWN0VHlwZVtpbmRleEVOXTtcclxuICAgIHJldHVybiBTZXRMYW5ndWFnZTtcclxuICB9O1xyXG5cclxuICBpZiAobGFuZy50b1VwcGVyQ2FzZSgpID09IFwiVEhcIikge1xyXG4gICAgcmV0dXJuIGdldFRIKCk7XHJcbiAgfVxyXG4gIHJldHVybiBnZXRFTigpO1xyXG59O1xyXG4iXSwic291cmNlUm9vdCI6IiJ9