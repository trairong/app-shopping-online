webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-header.tsx":
/*!*************************************!*\
  !*** ./src/components/c-header.tsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CHeader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Account */ "./node_modules/@2fd/ant-design-icons/lib/Account.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/AccountCircle */ "./node_modules/@2fd/ant-design-icons/lib/AccountCircle.js");
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Cart */ "./node_modules/@2fd/ant-design-icons/lib/Cart.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/ViewGrid */ "./node_modules/@2fd/ant-design-icons/lib/ViewGrid.js");
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/BellOutline */ "./node_modules/@2fd/ant-design-icons/lib/BellOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-header.tsx",
    _s = $RefreshSig$();












var Header = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Header,
    Footer = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Footer,
    Sider = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Sider,
    Content = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Content;
function CHeader(_ref) {
  _s();

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_6__["Context"]),
      state = _useContext.state;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      lang = _useState[0],
      setlang = _useState[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_12__["Language"])(state.language));
  }, [state.language]);

  var menu = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"], {
    style: {
      width: 200
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["UserOutlined"], {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 32
      }, this),
      children: "Profile"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default.a, {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 32
      }, this),
      children: "Logout"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Headers, {
      theme: state.theme,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        style: {
          height: "100%",
          display: "flex",
          alignItems: "center"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            display: "flex",
            height: '100%'
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Images, {
            src: "/images/shopping_1.png",
            preview: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 12,
          style: {
            display: "flex",
            alignItems: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Input"], {
            placeholder: "INPUT SEARCH",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            },
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["SearchOutlined"], {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 51,
              columnNumber: 21
            }, this),
            children: lang.Search
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            textAlign: "end"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 66,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 63,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            overlay: menu,
            placement: "bottomLeft",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: "primary",
              shape: "circle",
              icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default.a, {
                style: {
                  fontSize: 30
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 79,
                columnNumber: 23
              }, this),
              style: {
                width: 50,
                height: 50
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 76,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(CHeader, "Je3D6FiphRcJoYgNdEyT0Gr7Fqw=");

_c = CHeader;
var Headers = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(Header).withConfig({
  displayName: "c-header__Headers",
  componentId: "sc-18zra2i-0"
})(["background-color:", ";box-shadow:0px 0px 5px #000000;padding:0px;height:80px;position:sticky;top:0px;z-index:3;"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = Headers;
var Images = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"]).withConfig({
  displayName: "c-header__Images",
  componentId: "sc-18zra2i-1"
})(["height:100%;width:100px;padding-left:0px;"]);
_c3 = Images;

var _c, _c2, _c3;

$RefreshReg$(_c, "CHeader");
$RefreshReg$(_c2, "Headers");
$RefreshReg$(_c3, "Images");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1oZWFkZXIudHN4Il0sIm5hbWVzIjpbIkhlYWRlciIsIkxheW91dCIsIkZvb3RlciIsIlNpZGVyIiwiQ29udGVudCIsIkNIZWFkZXIiLCJ1c2VDb250ZXh0IiwiQ29udGV4dCIsInN0YXRlIiwidXNlU3RhdGUiLCJsYW5nIiwic2V0bGFuZyIsInVzZUVmZmVjdCIsIkxhbmd1YWdlIiwibGFuZ3VhZ2UiLCJtZW51Iiwid2lkdGgiLCJmb250U2l6ZSIsInRoZW1lIiwiaGVpZ2h0IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJTZWFyY2giLCJ0ZXh0QWxpZ24iLCJIZWFkZXJzIiwic3R5bGVkIiwicHJpbWFyeSIsIkltYWdlcyIsIkltYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBRVFBLE0sR0FBbUNDLDJDLENBQW5DRCxNO0lBQVFFLE0sR0FBMkJELDJDLENBQTNCQyxNO0lBQVFDLEssR0FBbUJGLDJDLENBQW5CRSxLO0lBQU9DLE8sR0FBWUgsMkMsQ0FBWkcsTztBQUloQixTQUFTQyxPQUFULE9BQTBDO0FBQUE7O0FBQUE7O0FBQUEsb0JBQ3JDQyx3REFBVSxDQUFDQyxnREFBRCxDQUQyQjtBQUFBLE1BQy9DQyxLQUQrQyxlQUMvQ0EsS0FEK0M7O0FBQUEsa0JBRS9CQyxzREFBUSxDQUFNLElBQU4sQ0FGdUI7QUFBQSxNQUVoREMsSUFGZ0Q7QUFBQSxNQUUxQ0MsT0FGMEM7O0FBSXZEQyx5REFBUyxDQUFDLFlBQU07QUFDZEQsV0FBTyxDQUFDRSw0REFBUSxDQUFDTCxLQUFLLENBQUNNLFFBQVAsQ0FBVCxDQUFQO0FBQ0QsR0FGUSxFQUVOLENBQUNOLEtBQUssQ0FBQ00sUUFBUCxDQUZNLENBQVQ7O0FBSUEsTUFBTUMsSUFBSSxnQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFNBQUssRUFBRTtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUFiO0FBQUEsNEJBQ0UscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQW1CLFVBQUksZUFBRSxxRUFBQyw4REFBRDtBQUFjLGFBQUssRUFBRTtBQUFFQyxrQkFBUSxFQUFFO0FBQVo7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUF6QjtBQUFBO0FBQUEsT0FBZSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUFtQixVQUFJLGVBQUUscUVBQUMsd0VBQUQ7QUFBYSxhQUFLLEVBQUU7QUFBRUEsa0JBQVEsRUFBRTtBQUFaO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBekI7QUFBQTtBQUFBLE9BQWUsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7O0FBV0Esc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxPQUFEO0FBQVMsV0FBSyxFQUFFVCxLQUFLLENBQUNVLEtBQXRCO0FBQUEsNkJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxhQUFLLEVBQUU7QUFBRUMsZ0JBQU0sRUFBRSxNQUFWO0FBQWtCQyxpQkFBTyxFQUFFLE1BQTNCO0FBQW1DQyxvQkFBVSxFQUFFO0FBQS9DLFNBQVo7QUFBQSxnQ0FDRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQVksZUFBSyxFQUFFO0FBQUVELG1CQUFPLEVBQUUsTUFBWDtBQUFtQkQsa0JBQU0sRUFBRTtBQUEzQixXQUFuQjtBQUFBLGlDQUNFLHFFQUFDLE1BQUQ7QUFBUSxlQUFHLEVBQUMsd0JBQVo7QUFBcUMsbUJBQU8sRUFBRTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUlFLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLEVBQVQ7QUFBYSxlQUFLLEVBQUU7QUFBRUMsbUJBQU8sRUFBRSxNQUFYO0FBQW1CQyxzQkFBVSxFQUFFO0FBQS9CLFdBQXBCO0FBQUEsa0NBQ0UscUVBQUMsMENBQUQ7QUFDRSx1QkFBVyxFQUFDLGNBRGQ7QUFFRSxpQkFBSyxFQUFFO0FBQUVDLDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUI7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBS0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFO0FBQUVELDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUIsYUFGVDtBQUdFLGdCQUFJLGVBQUUscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUFBLHNCQUtHYixJQUFJLENBQUNjO0FBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkYsZUFpQkUscUVBQUMsd0NBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFZLGVBQUssRUFBRTtBQUFFQyxxQkFBUyxFQUFFO0FBQWIsV0FBbkI7QUFBQSxrQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMsNkVBQUQ7QUFBYSxtQkFBSyxFQUFFO0FBQUVSLHdCQUFRLEVBQUU7QUFBWjtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUhSO0FBSUUsaUJBQUssRUFBRTtBQUFFRCxtQkFBSyxFQUFFLEVBQVQ7QUFBYUcsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFPRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMscUVBQUQ7QUFBTSxtQkFBSyxFQUFFO0FBQUVGLHdCQUFRLEVBQUU7QUFBWjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSFI7QUFJRSxpQkFBSyxFQUFFO0FBQUVELG1CQUFLLEVBQUUsRUFBVDtBQUFhRyxvQkFBTSxFQUFFO0FBQXJCO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFQRixlQWFFLHFFQUFDLDJDQUFEO0FBQ0UsZ0JBQUksRUFBQyxTQURQO0FBRUUsaUJBQUssRUFBQyxRQUZSO0FBR0UsZ0JBQUksZUFBRSxxRUFBQywwRUFBRDtBQUFVLG1CQUFLLEVBQUU7QUFBRUYsd0JBQVEsRUFBRTtBQUFaO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSFI7QUFJRSxpQkFBSyxFQUFFO0FBQUVELG1CQUFLLEVBQUUsRUFBVDtBQUFhRyxvQkFBTSxFQUFFO0FBQXJCO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFiRixlQW1CRSxxRUFBQyw2Q0FBRDtBQUFVLG1CQUFPLEVBQUVKLElBQW5CO0FBQXlCLHFCQUFTLEVBQUMsWUFBbkM7QUFBQSxtQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGtCQUFJLEVBQUMsU0FEUDtBQUVFLG1CQUFLLEVBQUMsUUFGUjtBQUdFLGtCQUFJLGVBQUUscUVBQUMsOEVBQUQ7QUFBZSxxQkFBSyxFQUFFO0FBQUVFLDBCQUFRLEVBQUU7QUFBWjtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUhSO0FBSUUsbUJBQUssRUFBRTtBQUFFRCxxQkFBSyxFQUFFLEVBQVQ7QUFBYUcsc0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQTJERDs7R0E5RXVCZCxPOztLQUFBQSxPO0FBZ0Z4QixJQUFNcUIsT0FBTyxHQUFHQyxpRUFBTSxDQUFDM0IsTUFBRCxDQUFUO0FBQUE7QUFBQTtBQUFBLHdIQUNTO0FBQUEsTUFBR2tCLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ1UsT0FBckI7QUFBQSxDQURULENBQWI7TUFBTUYsTztBQVdOLElBQU1HLE1BQU0sR0FBR0YsaUVBQU0sQ0FBQ0csMENBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxpREFBWjtNQUFNRCxNIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjY5YjcxYjExYjM5Mzc2OGFiZjMwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb2wsIFJvdywgTGF5b3V0LCBJbnB1dCwgQnV0dG9uLCBJbWFnZSwgRHJvcGRvd24sIE1lbnUgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IEF1ZGlvT3V0bGluZWQsIFNlYXJjaE91dGxpbmVkLCBVc2VyT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi9jb250ZXh0XCI7XHJcbmltcG9ydCBBY2NvdW50SWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9BY2NvdW50XCI7XHJcbmltcG9ydCBBY2NvdW50Q2lyY2xlIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0FjY291bnRDaXJjbGVcIjtcclxuaW1wb3J0IENhcnQgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQ2FydFwiO1xyXG5pbXBvcnQgVmlld0dyaWQgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvVmlld0dyaWRcIjtcclxuaW1wb3J0IEJlbGxPdXRsaW5lIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0JlbGxPdXRsaW5lXCI7XHJcbmltcG9ydCB7IExhbmd1YWdlIH0gZnJvbSBcIi4uL2xhbmd1YWdlc1wiO1xyXG5cclxuY29uc3QgeyBIZWFkZXIsIEZvb3RlciwgU2lkZXIsIENvbnRlbnQgfSA9IExheW91dDtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ0hlYWRlcih7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUgfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3QgW2xhbmcsIHNldGxhbmddID0gdXNlU3RhdGU8YW55PihudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldGxhbmcoTGFuZ3VhZ2Uoc3RhdGUubGFuZ3VhZ2UpKTtcclxuICB9LCBbc3RhdGUubGFuZ3VhZ2VdKTtcclxuXHJcbiAgY29uc3QgbWVudSA9IChcclxuICAgIDxNZW51IHN0eWxlPXt7IHdpZHRoOiAyMDAgfX0+XHJcbiAgICAgIDxNZW51Lkl0ZW0ga2V5PVwiMVwiIGljb249ezxVc2VyT3V0bGluZWQgc3R5bGU9e3sgZm9udFNpemU6IDIwIH19IC8+fT5cclxuICAgICAgICBQcm9maWxlXHJcbiAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICA8TWVudS5JdGVtIGtleT1cIjFcIiBpY29uPXs8QWNjb3VudEljb24gc3R5bGU9e3sgZm9udFNpemU6IDIwIH19IC8+fT5cclxuICAgICAgICBMb2dvdXRcclxuICAgICAgPC9NZW51Lkl0ZW0+XHJcbiAgICA8L01lbnU+XHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxIZWFkZXJzIHRoZW1lPXtzdGF0ZS50aGVtZX0+XHJcbiAgICAgICAgPFJvdyBzdHlsZT17eyBoZWlnaHQ6IFwiMTAwJVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgIDxDb2wgbWQ9ezZ9IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiICxoZWlnaHQ6ICcxMDAlJ319PlxyXG4gICAgICAgICAgICA8SW1hZ2VzIHNyYz1cIi9pbWFnZXMvc2hvcHBpbmdfMS5wbmdcIiBwcmV2aWV3PXtmYWxzZX0gLz5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgPENvbCBtZD17MTJ9IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19PlxyXG4gICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIklOUFVUIFNFQVJDSFwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwLCBib3hTaGFkb3c6IFwiMHB4IDBweCAycHggIzAwMDAwMFwiIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwLCBib3hTaGFkb3c6IFwiMHB4IDBweCAycHggIzAwMDAwMFwiIH19XHJcbiAgICAgICAgICAgICAgaWNvbj17PFNlYXJjaE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2xhbmcuU2VhcmNofVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgPENvbCBtZD17Nn0gc3R5bGU9e3sgdGV4dEFsaWduOiBcImVuZFwiIH19PlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICBpY29uPXs8QmVsbE91dGxpbmUgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICBpY29uPXs8Q2FydCBzdHlsZT17eyBmb250U2l6ZTogMzAgfX0gLz59XHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgc2hhcGU9XCJjaXJjbGVcIlxyXG4gICAgICAgICAgICAgIGljb249ezxWaWV3R3JpZCBzdHlsZT17eyBmb250U2l6ZTogMzAgfX0gLz59XHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxEcm9wZG93biBvdmVybGF5PXttZW51fSBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgc2hhcGU9XCJjaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PEFjY291bnRDaXJjbGUgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwIH19PlxyXG4gICAgICAgICAgICAgIFJFR0lTVEVSXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwLCBtYXJnaW5SaWdodDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgTE9HSU5cclxuICAgICAgICAgICAgPC9CdXR0b24+ICovfVxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPC9Sb3c+XHJcbiAgICAgIDwvSGVhZGVycz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IEhlYWRlcnMgPSBzdHlsZWQoSGVhZGVyKWBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgcGFkZGluZzogMHB4O1xyXG4gIGhlaWdodDogODBweDtcclxuICAvKiBkaXNwbGF5OiBmbGV4OyAqL1xyXG4gIHBvc2l0aW9uOiBzdGlja3k7XHJcbiAgdG9wOiAwcHg7XHJcbiAgei1pbmRleDogMztcclxuYDtcclxuXHJcbmNvbnN0IEltYWdlcyA9IHN0eWxlZChJbWFnZSlgXHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHdpZHRoOiAxMDBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDBweDtcclxuYDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==