webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-sider.tsx":
/*!************************************!*\
  !*** ./src/components/c-sider.tsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CSider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _constants_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constants/index */ "./src/constants/index.ts");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Home */ "./node_modules/@2fd/ant-design-icons/lib/Home.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/History */ "./node_modules/@2fd/ant-design-icons/lib/History.js");
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/FormatListBulletedSquare */ "./node_modules/@2fd/ant-design-icons/lib/FormatListBulletedSquare.js");
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/CogOutline */ "./node_modules/@2fd/ant-design-icons/lib/CogOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/TruckDeliveryOutline */ "./node_modules/@2fd/ant-design-icons/lib/TruckDeliveryOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Shopping */ "./node_modules/@2fd/ant-design-icons/lib/Shopping.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__);




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-sider.tsx",
    _s = $RefreshSig$();












function CSider(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      menuKey = _useState[0],
      setMenuKey = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      isLoading = _useState2[0],
      setIsLoading = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      lang = _useState3[0],
      setlang = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    collapsed: false
  }),
      collapsed = _useState4[0],
      setCollapsed = _useState4[1];

  var MIST_MENU = [{
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HOME,
    title: lang.Home,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].PRODUCT,
    title: lang.ProductType,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].LIST_PRODUCT,
    title: "รายการที่เลือก",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HISTORY,
    title: "สินค้าที่สั่งซื้อแล้ว",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].TRANSPORT,
    title: "สินค้ากำลังจัดส่ง",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].SETTING,
    title: "ตั้งค่า",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 13
    }, this)
  }];
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    if (MIST_MENU) {
      setMenuKey(MIST_MENU[0].key);
    }

    setIsLoading(true);
  }, [state.language]);

  var onCollapse = function onCollapse(collapsed) {
    console.log(collapsed);
    setCollapsed({
      collapsed: collapsed
    });
  };

  var RouteMenu = function RouteMenu(item) {
    console.log(item);
    dispatch({
      type: "SET_ROUT_MUNU",
      payload: {
        routMenu: item.key
      }
    });
    setMenuKey(item.key);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {}, [lang, MIST_MENU]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Siders, {
      collapsible: true,
      collapsed: collapsed.collapsed,
      onCollapse: onCollapse,
      theme: state.theme,
      width: 250,
      children: isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"], {
        mode: "inline",
        defaultSelectedKeys: [menuKey],
        className: "Menu",
        children: MIST_MENU.map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"].Item, {
            className: "siderMenu",
            icon: item.icon,
            onClick: function onClick() {
              return RouteMenu(item);
            },
            children: item.title
          }, item.key, false, {
            fileName: _jsxFileName,
            lineNumber: 107,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 96,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(CSider, "lT0bVH58Hvo0u6evPnbvqrRRUiQ=");

_c = CSider;
var Siders = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_3__["Layout"].Sider).withConfig({
  displayName: "c-sider__Siders",
  componentId: "o7xxc1-0"
})(["box-shadow:0px 0px 5px #000000;background-color:", ";overflow:hidden;.ant-menu-inline .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-menu-vertical .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-layout-sider-trigger{background-color:", ";}.ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected{background-color:", " !important;color:#fff;height:60px;padding-left:24px;display:flex;align-items:center;margin:0px;}.ant-menu-submenu > .ant-menu-submenu-title{height:60px;display:flex;align-items:center;color:", ";margin:0px;}.ant-menu-submenu-arrow{color:", ";}.siderMenu{height:60px;padding-left:24px;display:flex;align-items:center;color:", ";margin:0px;}.Menu{height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:10px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.3);border-radius:0px;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}}"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
}, function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
}, function (_ref5) {
  var theme = _ref5.theme;
  return theme.primary;
}, function (_ref6) {
  var theme = _ref6.theme;
  return theme.primary;
}, function (_ref7) {
  var theme = _ref7.theme;
  return theme.primary;
}, function (_ref8) {
  var theme = _ref8.theme;
  return theme.primary;
});
_c2 = Siders;

var _c, _c2;

$RefreshReg$(_c, "CSider");
$RefreshReg$(_c2, "Siders");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./src/languages/index.ts":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1zaWRlci50c3giXSwibmFtZXMiOlsiQ1NpZGVyIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlU3RhdGUiLCJtZW51S2V5Iiwic2V0TWVudUtleSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImxhbmciLCJzZXRsYW5nIiwiY29sbGFwc2VkIiwic2V0Q29sbGFwc2VkIiwiTUlTVF9NRU5VIiwia2V5IiwiTUVOVSIsIkhPTUUiLCJ0aXRsZSIsIkhvbWUiLCJpY29uIiwiZm9udFNpemUiLCJQUk9EVUNUIiwiUHJvZHVjdFR5cGUiLCJMSVNUX1BST0RVQ1QiLCJISVNUT1JZIiwiVFJBTlNQT1JUIiwiU0VUVElORyIsInVzZUVmZmVjdCIsImxhbmd1YWdlIiwib25Db2xsYXBzZSIsImNvbnNvbGUiLCJsb2ciLCJSb3V0ZU1lbnUiLCJpdGVtIiwidHlwZSIsInBheWxvYWQiLCJyb3V0TWVudSIsInRoZW1lIiwibWFwIiwiaW5kZXgiLCJTaWRlcnMiLCJzdHlsZWQiLCJMYXlvdXQiLCJTaWRlciIsInByaW1hcnkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBU0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBS2UsU0FBU0EsTUFBVCxPQUF5QztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9CQUMxQkMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FEZ0I7QUFBQSxNQUM5Q0MsS0FEOEMsZUFDOUNBLEtBRDhDO0FBQUEsTUFDdkNDLFFBRHVDLGVBQ3ZDQSxRQUR1Qzs7QUFBQSxrQkFFeEJDLHNEQUFRLEVBRmdCO0FBQUEsTUFFL0NDLE9BRitDO0FBQUEsTUFFdENDLFVBRnNDOztBQUFBLG1CQUdwQkYsc0RBQVEsQ0FBQyxLQUFELENBSFk7QUFBQSxNQUcvQ0csU0FIK0M7QUFBQSxNQUdwQ0MsWUFIb0M7O0FBQUEsbUJBSTlCSixzREFBUSxFQUpzQjtBQUFBLE1BSS9DSyxJQUorQztBQUFBLE1BSXpDQyxPQUp5Qzs7QUFBQSxtQkFNcEJOLHNEQUFRLENBQUM7QUFDekNPLGFBQVMsRUFBRTtBQUQ4QixHQUFELENBTlk7QUFBQSxNQU0vQ0EsU0FOK0M7QUFBQSxNQU1wQ0MsWUFOb0M7O0FBVXRELE1BQU1DLFNBQVMsR0FBRyxDQUNoQjtBQUNFQyxPQUFHLEVBQUVDLDJEQUFJLENBQUNDLElBRFo7QUFFRUMsU0FBSyxFQUFFUixJQUFJLENBQUNTLElBRmQ7QUFHRUMsUUFBSSxlQUFFLHFFQUFDLHFFQUFEO0FBQU0sV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQURnQixFQU1oQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNNLE9BRFo7QUFFRUosU0FBSyxFQUFFUixJQUFJLENBQUNhLFdBRmQ7QUFHRUgsUUFBSSxlQUFFLHFFQUFDLDBFQUFEO0FBQWMsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FOZ0IsRUFXaEI7QUFDRU4sT0FBRyxFQUFFQywyREFBSSxDQUFDUSxZQURaO0FBRUVOLFNBQUssRUFBRSxnQkFGVDtBQUdFRSxRQUFJLGVBQUUscUVBQUMseUZBQUQ7QUFBOEIsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FYZ0IsRUFnQmhCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ1MsT0FEWjtBQUVFUCxTQUFLLEVBQUUsdUJBRlQ7QUFHRUUsUUFBSSxlQUFFLHFFQUFDLHdFQUFEO0FBQWEsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FoQmdCLEVBcUJoQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNVLFNBRFo7QUFFRVIsU0FBSyxFQUFFLG1CQUZUO0FBR0VFLFFBQUksZUFBRSxxRUFBQyxzRkFBRDtBQUEwQixXQUFLLEVBQUU7QUFBRUMsZ0JBQVEsRUFBRTtBQUFaO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQXJCZ0IsRUEwQmhCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ1csT0FEWjtBQUVFVCxTQUFLLEVBQUUsU0FGVDtBQUdFRSxRQUFJLGVBQUUscUVBQUMsNEVBQUQ7QUFBZ0IsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0ExQmdCLENBQWxCO0FBaUNBTyx5REFBUyxDQUFDLFlBQU07QUFDZCxRQUFJZCxTQUFKLEVBQWU7QUFDYlAsZ0JBQVUsQ0FBQ08sU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxHQUFkLENBQVY7QUFDRDs7QUFDRE4sZ0JBQVksQ0FBQyxJQUFELENBQVo7QUFDRCxHQUxRLEVBS04sQ0FBQ04sS0FBSyxDQUFDMEIsUUFBUCxDQUxNLENBQVQ7O0FBT0EsTUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ2xCLFNBQUQsRUFBZTtBQUNoQ21CLFdBQU8sQ0FBQ0MsR0FBUixDQUFZcEIsU0FBWjtBQUNBQyxnQkFBWSxDQUFDO0FBQUVELGVBQVMsRUFBVEE7QUFBRixLQUFELENBQVo7QUFDRCxHQUhEOztBQUtBLE1BQU1xQixTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDQyxJQUFELEVBQVU7QUFDMUJILFdBQU8sQ0FBQ0MsR0FBUixDQUFZRSxJQUFaO0FBQ0E5QixZQUFRLENBQUM7QUFDUCtCLFVBQUksRUFBRSxlQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQQyxnQkFBUSxFQUFFSCxJQUFJLENBQUNuQjtBQURSO0FBRkYsS0FBRCxDQUFSO0FBTUFSLGNBQVUsQ0FBQzJCLElBQUksQ0FBQ25CLEdBQU4sQ0FBVjtBQUNELEdBVEQ7O0FBV0FhLHlEQUFTLENBQUMsWUFBTSxDQUFFLENBQVQsRUFBVyxDQUFDbEIsSUFBRCxFQUFPSSxTQUFQLENBQVgsQ0FBVDtBQUVBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsTUFBRDtBQUNFLGlCQUFXLE1BRGI7QUFFRSxlQUFTLEVBQUVGLFNBQVMsQ0FBQ0EsU0FGdkI7QUFHRSxnQkFBVSxFQUFFa0IsVUFIZDtBQUlFLFdBQUssRUFBRTNCLEtBQUssQ0FBQ21DLEtBSmY7QUFLRSxXQUFLLEVBQUUsR0FMVDtBQUFBLGdCQU9HOUIsU0FBUyxpQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFlBQUksRUFBQyxRQUFYO0FBQW9CLDJCQUFtQixFQUFFLENBQUNGLE9BQUQsQ0FBekM7QUFBb0QsaUJBQVMsRUFBQyxNQUE5RDtBQUFBLGtCQUNHUSxTQUFTLENBQUN5QixHQUFWLENBQWMsVUFBQ0wsSUFBRCxFQUFPTSxLQUFQLEVBQWlCO0FBQzlCLDhCQUNFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUVFLHFCQUFTLEVBQUMsV0FGWjtBQUdFLGdCQUFJLEVBQUVOLElBQUksQ0FBQ2QsSUFIYjtBQUlFLG1CQUFPLEVBQUU7QUFBQSxxQkFBTWEsU0FBUyxDQUFDQyxJQUFELENBQWY7QUFBQSxhQUpYO0FBQUEsc0JBTUdBLElBQUksQ0FBQ2hCO0FBTlIsYUFDT2dCLElBQUksQ0FBQ25CLEdBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQVVELFNBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBNEJEOztHQWhHdUJmLE07O0tBQUFBLE07QUFrR3hCLElBQU15QyxNQUFNLEdBQUdDLGlFQUFNLENBQUNDLDJDQUFNLENBQUNDLEtBQVIsQ0FBVDtBQUFBO0FBQUE7QUFBQSxvNkJBRVU7QUFBQSxNQUFHTixLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0FGVixFQVdZO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBWFosRUFjWTtBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQWRaLEVBMEJDO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBMUJELEVBOEJDO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBOUJELEVBcUNDO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBckNELEVBdURjO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBdkRkLENBQVo7TUFBTUosTSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5hMjc1YjkxNmM2MWFiNTM3YjBlYy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBCcmVhZGNydW1iLCBMYXlvdXQsIE1lbnUgfSBmcm9tIFwiYW50ZFwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBEZXNrdG9wT3V0bGluZWQsXHJcbiAgUGllQ2hhcnRPdXRsaW5lZCxcclxuICBGaWxlT3V0bGluZWQsXHJcbiAgVGVhbU91dGxpbmVkLFxyXG4gIFVzZXJPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgRm9vdGVyIH0gZnJvbSBcImFudGQvbGliL2xheW91dC9sYXlvdXRcIjtcclxuaW1wb3J0IFN1Yk1lbnUgZnJvbSBcImFudGQvbGliL21lbnUvU3ViTWVudVwiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRcIjtcclxuaW1wb3J0IHsgUk9VVEVfTUVOVSBhcyBNRU5VIH0gZnJvbSBcIi4uL2NvbnN0YW50cy9pbmRleFwiO1xyXG5pbXBvcnQgSG9tZSBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9Ib21lXCI7XHJcbmltcG9ydCBIaXN0b3J5SWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9IaXN0b3J5XCI7XHJcbmltcG9ydCBGb3JtYXRMaXN0QnVsbGV0ZWRTcXVhcmVJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0Zvcm1hdExpc3RCdWxsZXRlZFNxdWFyZVwiO1xyXG5pbXBvcnQgQ29nT3V0bGluZUljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQ29nT3V0bGluZVwiO1xyXG5pbXBvcnQgVHJ1Y2tEZWxpdmVyeU91dGxpbmVJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1RydWNrRGVsaXZlcnlPdXRsaW5lXCI7XHJcbmltcG9ydCBTaG9wcGluZ0ljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvU2hvcHBpbmdcIjtcclxuaW1wb3J0IHsgTGFuZ3VhZ2UgfSBmcm9tIFwiLi4vbGFuZ3VhZ2VzXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENTaWRlcih7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIGNvbnN0IFttZW51S2V5LCBzZXRNZW51S2V5XSA9IHVzZVN0YXRlPHN0cmluZz4oKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsYW5nLCBzZXRsYW5nXSA9IHVzZVN0YXRlPGFueT4oKTtcclxuXHJcbiAgY29uc3QgW2NvbGxhcHNlZCwgc2V0Q29sbGFwc2VkXSA9IHVzZVN0YXRlKHtcclxuICAgIGNvbGxhcHNlZDogZmFsc2UsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IE1JU1RfTUVOVSA9IFtcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhPTUUsXHJcbiAgICAgIHRpdGxlOiBsYW5nLkhvbWUsXHJcbiAgICAgIGljb246IDxIb21lIHN0eWxlPXt7IGZvbnRTaXplOiAyNSB9fSAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogTUVOVS5QUk9EVUNULFxyXG4gICAgICB0aXRsZTogbGFuZy5Qcm9kdWN0VHlwZSxcclxuICAgICAgaWNvbjogPFNob3BwaW5nSWNvbiBzdHlsZT17eyBmb250U2l6ZTogMjUgfX0gLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IE1FTlUuTElTVF9QUk9EVUNULFxyXG4gICAgICB0aXRsZTogXCLguKPguLLguKLguIHguLLguKPguJfguLXguYjguYDguKXguLfguK3guIFcIixcclxuICAgICAgaWNvbjogPEZvcm1hdExpc3RCdWxsZXRlZFNxdWFyZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhJU1RPUlksXHJcbiAgICAgIHRpdGxlOiBcIuC4quC4tOC4meC4hOC5ieC4suC4l+C4teC5iOC4quC4seC5iOC4h+C4i+C4t+C5ieC4reC5geC4peC5ieC4p1wiLFxyXG4gICAgICBpY29uOiA8SGlzdG9yeUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlRSQU5TUE9SVCxcclxuICAgICAgdGl0bGU6IFwi4Liq4Li04LiZ4LiE4LmJ4Liy4LiB4Liz4Lil4Lix4LiH4LiI4Lix4LiU4Liq4LmI4LiHXCIsXHJcbiAgICAgIGljb246IDxUcnVja0RlbGl2ZXJ5T3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlNFVFRJTkcsXHJcbiAgICAgIHRpdGxlOiBcIuC4leC4seC5ieC4h+C4hOC5iOC4slwiLFxyXG4gICAgICBpY29uOiA8Q29nT3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKE1JU1RfTUVOVSkge1xyXG4gICAgICBzZXRNZW51S2V5KE1JU1RfTUVOVVswXS5rZXkpO1xyXG4gICAgfVxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gIH0sIFtzdGF0ZS5sYW5ndWFnZV0pO1xyXG5cclxuICBjb25zdCBvbkNvbGxhcHNlID0gKGNvbGxhcHNlZCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coY29sbGFwc2VkKTtcclxuICAgIHNldENvbGxhcHNlZCh7IGNvbGxhcHNlZCB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBSb3V0ZU1lbnUgPSAoaXRlbSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coaXRlbSk7XHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1JPVVRfTVVOVVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcm91dE1lbnU6IGl0ZW0ua2V5LFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBzZXRNZW51S2V5KGl0ZW0ua2V5KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge30sIFtsYW5nLCBNSVNUX01FTlVdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxTaWRlcnNcclxuICAgICAgICBjb2xsYXBzaWJsZVxyXG4gICAgICAgIGNvbGxhcHNlZD17Y29sbGFwc2VkLmNvbGxhcHNlZH1cclxuICAgICAgICBvbkNvbGxhcHNlPXtvbkNvbGxhcHNlfVxyXG4gICAgICAgIHRoZW1lPXtzdGF0ZS50aGVtZX1cclxuICAgICAgICB3aWR0aD17MjUwfVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8TWVudSBtb2RlPVwiaW5saW5lXCIgZGVmYXVsdFNlbGVjdGVkS2V5cz17W21lbnVLZXldfSBjbGFzc05hbWU9XCJNZW51XCI+XHJcbiAgICAgICAgICAgIHtNSVNUX01FTlUubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8TWVudS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5rZXl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGVyTWVudVwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gUm91dGVNZW51KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvU2lkZXJzPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgU2lkZXJzID0gc3R5bGVkKExheW91dC5TaWRlcilgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggIzAwMDAwMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgLmFudC1tZW51LWlubGluZSAuYW50LW1lbnUtaXRlbTpub3QoOmxhc3QtY2hpbGQpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXZlcnRpY2FsIC5hbnQtbWVudS1pdGVtOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuICAuYW50LWxheW91dC1zaWRlci10cmlnZ2VyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgfVxyXG4gIC5hbnQtbWVudTpub3QoLmFudC1tZW51LWhvcml6b250YWwpIC5hbnQtbWVudS1pdGVtLXNlbGVjdGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXN1Ym1lbnUgPiAuYW50LW1lbnUtc3VibWVudS10aXRsZSB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIC5hbnQtbWVudS1zdWJtZW51LWFycm93IHtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuICAuc2lkZXJNZW51IHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMjRweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcblxyXG4gIC5NZW51IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgd2lkdGg6IDEwcHg7XHJcbiAgICB9XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9