webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-sider.tsx":
/*!************************************!*\
  !*** ./src/components/c-sider.tsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CSider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _constants_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constants/index */ "./src/constants/index.ts");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Home */ "./node_modules/@2fd/ant-design-icons/lib/Home.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/History */ "./node_modules/@2fd/ant-design-icons/lib/History.js");
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/FormatListBulletedSquare */ "./node_modules/@2fd/ant-design-icons/lib/FormatListBulletedSquare.js");
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/CogOutline */ "./node_modules/@2fd/ant-design-icons/lib/CogOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/TruckDeliveryOutline */ "./node_modules/@2fd/ant-design-icons/lib/TruckDeliveryOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Shopping */ "./node_modules/@2fd/ant-design-icons/lib/Shopping.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-sider.tsx",
    _s = $RefreshSig$();













function CSider(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      menuKey = _useState[0],
      setMenuKey = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      isLoading = _useState2[0],
      setIsLoading = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      lang = _useState3[0],
      setlang = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    collapsed: false
  }),
      collapsed = _useState4[0],
      setCollapsed = _useState4[1];

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    var langs = Object(_languages__WEBPACK_IMPORTED_MODULE_13__["Language"])(state.language);
    console.log("langs.......", langs);
    setlang(langs);
  }, [state.language]);
  var MIST_MENU = [{
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HOME,
    title: lang.Home,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].PRODUCT,
    title: lang.ProductType,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].LIST_PRODUCT,
    title: "รายการที่เลือก",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HISTORY,
    title: "สินค้าที่สั่งซื้อแล้ว",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].TRANSPORT,
    title: "สินค้ากำลังจัดส่ง",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].SETTING,
    title: "ตั้งค่า",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 13
    }, this)
  }];
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    if (MIST_MENU) {
      setMenuKey(MIST_MENU[0].key);
    }

    setIsLoading(true);
  }, [state.language]);

  var onCollapse = function onCollapse(collapsed) {
    console.log(collapsed);
    setCollapsed({
      collapsed: collapsed
    });
  };

  var RouteMenu = function RouteMenu(item) {
    console.log(item);
    dispatch({
      type: "SET_ROUT_MUNU",
      payload: {
        routMenu: item.key
      }
    });
    setMenuKey(item.key);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {}, [lang, MIST_MENU]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Siders, {
      collapsible: true,
      collapsed: collapsed.collapsed,
      onCollapse: onCollapse,
      theme: state.theme,
      width: 250,
      children: isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"], {
        mode: "inline",
        defaultSelectedKeys: [menuKey],
        className: "Menu",
        children: MIST_MENU.map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"].Item, {
            className: "siderMenu",
            icon: item.icon,
            onClick: function onClick() {
              return RouteMenu(item);
            },
            children: item.title
          }, item.key, false, {
            fileName: _jsxFileName,
            lineNumber: 112,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 101,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(CSider, "N82JM6b+9rehuNAFDymKUNSO8CM=");

_c = CSider;
var Siders = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_3__["Layout"].Sider).withConfig({
  displayName: "c-sider__Siders",
  componentId: "o7xxc1-0"
})(["box-shadow:0px 0px 5px #000000;background-color:", ";overflow:hidden;.ant-menu-inline .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-menu-vertical .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-layout-sider-trigger{background-color:", ";}.ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected{background-color:", " !important;color:#fff;height:60px;padding-left:24px;display:flex;align-items:center;margin:0px;}.ant-menu-submenu > .ant-menu-submenu-title{height:60px;display:flex;align-items:center;color:", ";margin:0px;}.ant-menu-submenu-arrow{color:", ";}.siderMenu{height:60px;padding-left:24px;display:flex;align-items:center;color:", ";margin:0px;}.Menu{height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:10px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.3);border-radius:0px;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}}"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
}, function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
}, function (_ref5) {
  var theme = _ref5.theme;
  return theme.primary;
}, function (_ref6) {
  var theme = _ref6.theme;
  return theme.primary;
}, function (_ref7) {
  var theme = _ref7.theme;
  return theme.primary;
}, function (_ref8) {
  var theme = _ref8.theme;
  return theme.primary;
});
_c2 = Siders;

var _c, _c2;

$RefreshReg$(_c, "CSider");
$RefreshReg$(_c2, "Siders");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1zaWRlci50c3giXSwibmFtZXMiOlsiQ1NpZGVyIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlU3RhdGUiLCJtZW51S2V5Iiwic2V0TWVudUtleSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImxhbmciLCJzZXRsYW5nIiwiY29sbGFwc2VkIiwic2V0Q29sbGFwc2VkIiwidXNlRWZmZWN0IiwibGFuZ3MiLCJMYW5ndWFnZSIsImxhbmd1YWdlIiwiY29uc29sZSIsImxvZyIsIk1JU1RfTUVOVSIsImtleSIsIk1FTlUiLCJIT01FIiwidGl0bGUiLCJIb21lIiwiaWNvbiIsImZvbnRTaXplIiwiUFJPRFVDVCIsIlByb2R1Y3RUeXBlIiwiTElTVF9QUk9EVUNUIiwiSElTVE9SWSIsIlRSQU5TUE9SVCIsIlNFVFRJTkciLCJvbkNvbGxhcHNlIiwiUm91dGVNZW51IiwiaXRlbSIsInR5cGUiLCJwYXlsb2FkIiwicm91dE1lbnUiLCJ0aGVtZSIsIm1hcCIsImluZGV4IiwiU2lkZXJzIiwic3R5bGVkIiwiTGF5b3V0IiwiU2lkZXIiLCJwcmltYXJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFTQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUllLFNBQVNBLE1BQVQsT0FBeUM7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQSxvQkFDMUJDLHdEQUFVLENBQUNDLGdEQUFELENBRGdCO0FBQUEsTUFDOUNDLEtBRDhDLGVBQzlDQSxLQUQ4QztBQUFBLE1BQ3ZDQyxRQUR1QyxlQUN2Q0EsUUFEdUM7O0FBQUEsa0JBRXhCQyxzREFBUSxFQUZnQjtBQUFBLE1BRS9DQyxPQUYrQztBQUFBLE1BRXRDQyxVQUZzQzs7QUFBQSxtQkFHcEJGLHNEQUFRLENBQUMsS0FBRCxDQUhZO0FBQUEsTUFHL0NHLFNBSCtDO0FBQUEsTUFHcENDLFlBSG9DOztBQUFBLG1CQUk5Qkosc0RBQVEsRUFKc0I7QUFBQSxNQUkvQ0ssSUFKK0M7QUFBQSxNQUl6Q0MsT0FKeUM7O0FBQUEsbUJBTXBCTixzREFBUSxDQUFDO0FBQ3pDTyxhQUFTLEVBQUU7QUFEOEIsR0FBRCxDQU5ZO0FBQUEsTUFNL0NBLFNBTitDO0FBQUEsTUFNcENDLFlBTm9DOztBQVN0REMseURBQVMsQ0FBQyxZQUFNO0FBQ2QsUUFBSUMsS0FBSyxHQUFHQyw0REFBUSxDQUFDYixLQUFLLENBQUNjLFFBQVAsQ0FBcEI7QUFDQUMsV0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QkosS0FBNUI7QUFDQUosV0FBTyxDQUFDSSxLQUFELENBQVA7QUFDRCxHQUpRLEVBSU4sQ0FBQ1osS0FBSyxDQUFDYyxRQUFQLENBSk0sQ0FBVDtBQU1BLE1BQU1HLFNBQVMsR0FBRyxDQUNoQjtBQUNFQyxPQUFHLEVBQUVDLDJEQUFJLENBQUNDLElBRFo7QUFFRUMsU0FBSyxFQUFFZCxJQUFJLENBQUNlLElBRmQ7QUFHRUMsUUFBSSxlQUFFLHFFQUFDLHFFQUFEO0FBQU0sV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQURnQixFQU1oQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNNLE9BRFo7QUFFRUosU0FBSyxFQUFFZCxJQUFJLENBQUNtQixXQUZkO0FBR0VILFFBQUksZUFBRSxxRUFBQywwRUFBRDtBQUFjLFdBQUssRUFBRTtBQUFFQyxnQkFBUSxFQUFFO0FBQVo7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBTmdCLEVBV2hCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ1EsWUFEWjtBQUVFTixTQUFLLEVBQUUsZ0JBRlQ7QUFHRUUsUUFBSSxlQUFFLHFFQUFDLHlGQUFEO0FBQThCLFdBQUssRUFBRTtBQUFFQyxnQkFBUSxFQUFFO0FBQVo7QUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBWGdCLEVBZ0JoQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNTLE9BRFo7QUFFRVAsU0FBSyxFQUFFLHVCQUZUO0FBR0VFLFFBQUksZUFBRSxxRUFBQyx3RUFBRDtBQUFhLFdBQUssRUFBRTtBQUFFQyxnQkFBUSxFQUFFO0FBQVo7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBaEJnQixFQXFCaEI7QUFDRU4sT0FBRyxFQUFFQywyREFBSSxDQUFDVSxTQURaO0FBRUVSLFNBQUssRUFBRSxtQkFGVDtBQUdFRSxRQUFJLGVBQUUscUVBQUMsc0ZBQUQ7QUFBMEIsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FyQmdCLEVBMEJoQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNXLE9BRFo7QUFFRVQsU0FBSyxFQUFFLFNBRlQ7QUFHRUUsUUFBSSxlQUFFLHFFQUFDLDRFQUFEO0FBQWdCLFdBQUssRUFBRTtBQUFFQyxnQkFBUSxFQUFFO0FBQVo7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBMUJnQixDQUFsQjtBQWlDQWIseURBQVMsQ0FBQyxZQUFNO0FBQ2QsUUFBSU0sU0FBSixFQUFlO0FBQ2JiLGdCQUFVLENBQUNhLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsR0FBZCxDQUFWO0FBQ0Q7O0FBQ0RaLGdCQUFZLENBQUMsSUFBRCxDQUFaO0FBQ0QsR0FMUSxFQUtOLENBQUNOLEtBQUssQ0FBQ2MsUUFBUCxDQUxNLENBQVQ7O0FBT0EsTUFBTWlCLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUN0QixTQUFELEVBQWU7QUFDaENNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZUCxTQUFaO0FBQ0FDLGdCQUFZLENBQUM7QUFBRUQsZUFBUyxFQUFUQTtBQUFGLEtBQUQsQ0FBWjtBQUNELEdBSEQ7O0FBS0EsTUFBTXVCLFNBQVMsR0FBRyxTQUFaQSxTQUFZLENBQUNDLElBQUQsRUFBVTtBQUMxQmxCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZaUIsSUFBWjtBQUNBaEMsWUFBUSxDQUFDO0FBQ1BpQyxVQUFJLEVBQUUsZUFEQztBQUVQQyxhQUFPLEVBQUU7QUFDUEMsZ0JBQVEsRUFBRUgsSUFBSSxDQUFDZjtBQURSO0FBRkYsS0FBRCxDQUFSO0FBTUFkLGNBQVUsQ0FBQzZCLElBQUksQ0FBQ2YsR0FBTixDQUFWO0FBQ0QsR0FURDs7QUFXQVAseURBQVMsQ0FBQyxZQUFNLENBQUUsQ0FBVCxFQUFXLENBQUNKLElBQUQsRUFBT1UsU0FBUCxDQUFYLENBQVQ7QUFFQSxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLE1BQUQ7QUFDRSxpQkFBVyxNQURiO0FBRUUsZUFBUyxFQUFFUixTQUFTLENBQUNBLFNBRnZCO0FBR0UsZ0JBQVUsRUFBRXNCLFVBSGQ7QUFJRSxXQUFLLEVBQUUvQixLQUFLLENBQUNxQyxLQUpmO0FBS0UsV0FBSyxFQUFFLEdBTFQ7QUFBQSxnQkFPR2hDLFNBQVMsaUJBQ1IscUVBQUMseUNBQUQ7QUFBTSxZQUFJLEVBQUMsUUFBWDtBQUFvQiwyQkFBbUIsRUFBRSxDQUFDRixPQUFELENBQXpDO0FBQW9ELGlCQUFTLEVBQUMsTUFBOUQ7QUFBQSxrQkFDR2MsU0FBUyxDQUFDcUIsR0FBVixDQUFjLFVBQUNMLElBQUQsRUFBT00sS0FBUCxFQUFpQjtBQUM5Qiw4QkFDRSxxRUFBQyx5Q0FBRCxDQUFNLElBQU47QUFFRSxxQkFBUyxFQUFDLFdBRlo7QUFHRSxnQkFBSSxFQUFFTixJQUFJLENBQUNWLElBSGI7QUFJRSxtQkFBTyxFQUFFO0FBQUEscUJBQU1TLFNBQVMsQ0FBQ0MsSUFBRCxDQUFmO0FBQUEsYUFKWDtBQUFBLHNCQU1HQSxJQUFJLENBQUNaO0FBTlIsYUFDT1ksSUFBSSxDQUFDZixHQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREY7QUFVRCxTQVhBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQTRCRDs7R0FyR3VCckIsTTs7S0FBQUEsTTtBQXVHeEIsSUFBTTJDLE1BQU0sR0FBR0MsaUVBQU0sQ0FBQ0MsMkNBQU0sQ0FBQ0MsS0FBUixDQUFUO0FBQUE7QUFBQTtBQUFBLG82QkFFVTtBQUFBLE1BQUdOLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQUZWLEVBV1k7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0FYWixFQWNZO0FBQUEsTUFBR1AsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBZFosRUEwQkM7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0ExQkQsRUE4QkM7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0E5QkQsRUFxQ0M7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0FyQ0QsRUF1RGM7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0F2RGQsQ0FBWjtNQUFNSixNIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmQ0NmY1Y2NkMmUzYjc5ODE2N2Y2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgUmVhY3RFbGVtZW50LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJyZWFkY3J1bWIsIExheW91dCwgTWVudSB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIERlc2t0b3BPdXRsaW5lZCxcclxuICBQaWVDaGFydE91dGxpbmVkLFxyXG4gIEZpbGVPdXRsaW5lZCxcclxuICBUZWFtT3V0bGluZWQsXHJcbiAgVXNlck91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tIFwiYW50ZC9saWIvbGF5b3V0L2xheW91dFwiO1xyXG5pbXBvcnQgU3ViTWVudSBmcm9tIFwiYW50ZC9saWIvbWVudS9TdWJNZW51XCI7XHJcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dFwiO1xyXG5pbXBvcnQgeyBST1VURV9NRU5VIGFzIE1FTlUgfSBmcm9tIFwiLi4vY29uc3RhbnRzL2luZGV4XCI7XHJcbmltcG9ydCBIb21lIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0hvbWVcIjtcclxuaW1wb3J0IEhpc3RvcnlJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0hpc3RvcnlcIjtcclxuaW1wb3J0IEZvcm1hdExpc3RCdWxsZXRlZFNxdWFyZUljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvRm9ybWF0TGlzdEJ1bGxldGVkU3F1YXJlXCI7XHJcbmltcG9ydCBDb2dPdXRsaW5lSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9Db2dPdXRsaW5lXCI7XHJcbmltcG9ydCBUcnVja0RlbGl2ZXJ5T3V0bGluZUljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvVHJ1Y2tEZWxpdmVyeU91dGxpbmVcIjtcclxuaW1wb3J0IFNob3BwaW5nSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9TaG9wcGluZ1wiO1xyXG5pbXBvcnQgeyBMYW5ndWFnZSB9IGZyb20gXCIuLi9sYW5ndWFnZXNcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ1NpZGVyKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3QgW21lbnVLZXksIHNldE1lbnVLZXldID0gdXNlU3RhdGU8c3RyaW5nPigpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xhbmcsIHNldGxhbmddID0gdXNlU3RhdGU8YW55PigpO1xyXG5cclxuICBjb25zdCBbY29sbGFwc2VkLCBzZXRDb2xsYXBzZWRdID0gdXNlU3RhdGUoe1xyXG4gICAgY29sbGFwc2VkOiBmYWxzZSxcclxuICB9KTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IGxhbmdzID0gTGFuZ3VhZ2Uoc3RhdGUubGFuZ3VhZ2UpO1xyXG4gICAgY29uc29sZS5sb2coXCJsYW5ncy4uLi4uLi5cIiwgbGFuZ3MpO1xyXG4gICAgc2V0bGFuZyhsYW5ncyk7XHJcbiAgfSwgW3N0YXRlLmxhbmd1YWdlXSk7XHJcblxyXG4gIGNvbnN0IE1JU1RfTUVOVSA9IFtcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhPTUUsXHJcbiAgICAgIHRpdGxlOiBsYW5nLkhvbWUsXHJcbiAgICAgIGljb246IDxIb21lIHN0eWxlPXt7IGZvbnRTaXplOiAyNSB9fSAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogTUVOVS5QUk9EVUNULFxyXG4gICAgICB0aXRsZTogbGFuZy5Qcm9kdWN0VHlwZSxcclxuICAgICAgaWNvbjogPFNob3BwaW5nSWNvbiBzdHlsZT17eyBmb250U2l6ZTogMjUgfX0gLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IE1FTlUuTElTVF9QUk9EVUNULFxyXG4gICAgICB0aXRsZTogXCLguKPguLLguKLguIHguLLguKPguJfguLXguYjguYDguKXguLfguK3guIFcIixcclxuICAgICAgaWNvbjogPEZvcm1hdExpc3RCdWxsZXRlZFNxdWFyZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhJU1RPUlksXHJcbiAgICAgIHRpdGxlOiBcIuC4quC4tOC4meC4hOC5ieC4suC4l+C4teC5iOC4quC4seC5iOC4h+C4i+C4t+C5ieC4reC5geC4peC5ieC4p1wiLFxyXG4gICAgICBpY29uOiA8SGlzdG9yeUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlRSQU5TUE9SVCxcclxuICAgICAgdGl0bGU6IFwi4Liq4Li04LiZ4LiE4LmJ4Liy4LiB4Liz4Lil4Lix4LiH4LiI4Lix4LiU4Liq4LmI4LiHXCIsXHJcbiAgICAgIGljb246IDxUcnVja0RlbGl2ZXJ5T3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlNFVFRJTkcsXHJcbiAgICAgIHRpdGxlOiBcIuC4leC4seC5ieC4h+C4hOC5iOC4slwiLFxyXG4gICAgICBpY29uOiA8Q29nT3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKE1JU1RfTUVOVSkge1xyXG4gICAgICBzZXRNZW51S2V5KE1JU1RfTUVOVVswXS5rZXkpO1xyXG4gICAgfVxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gIH0sIFtzdGF0ZS5sYW5ndWFnZV0pO1xyXG5cclxuICBjb25zdCBvbkNvbGxhcHNlID0gKGNvbGxhcHNlZCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coY29sbGFwc2VkKTtcclxuICAgIHNldENvbGxhcHNlZCh7IGNvbGxhcHNlZCB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBSb3V0ZU1lbnUgPSAoaXRlbSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coaXRlbSk7XHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1JPVVRfTVVOVVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcm91dE1lbnU6IGl0ZW0ua2V5LFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBzZXRNZW51S2V5KGl0ZW0ua2V5KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge30sIFtsYW5nLCBNSVNUX01FTlVdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxTaWRlcnNcclxuICAgICAgICBjb2xsYXBzaWJsZVxyXG4gICAgICAgIGNvbGxhcHNlZD17Y29sbGFwc2VkLmNvbGxhcHNlZH1cclxuICAgICAgICBvbkNvbGxhcHNlPXtvbkNvbGxhcHNlfVxyXG4gICAgICAgIHRoZW1lPXtzdGF0ZS50aGVtZX1cclxuICAgICAgICB3aWR0aD17MjUwfVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8TWVudSBtb2RlPVwiaW5saW5lXCIgZGVmYXVsdFNlbGVjdGVkS2V5cz17W21lbnVLZXldfSBjbGFzc05hbWU9XCJNZW51XCI+XHJcbiAgICAgICAgICAgIHtNSVNUX01FTlUubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8TWVudS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5rZXl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGVyTWVudVwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gUm91dGVNZW51KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvU2lkZXJzPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgU2lkZXJzID0gc3R5bGVkKExheW91dC5TaWRlcilgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggIzAwMDAwMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgLmFudC1tZW51LWlubGluZSAuYW50LW1lbnUtaXRlbTpub3QoOmxhc3QtY2hpbGQpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXZlcnRpY2FsIC5hbnQtbWVudS1pdGVtOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuICAuYW50LWxheW91dC1zaWRlci10cmlnZ2VyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgfVxyXG4gIC5hbnQtbWVudTpub3QoLmFudC1tZW51LWhvcml6b250YWwpIC5hbnQtbWVudS1pdGVtLXNlbGVjdGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXN1Ym1lbnUgPiAuYW50LW1lbnUtc3VibWVudS10aXRsZSB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIC5hbnQtbWVudS1zdWJtZW51LWFycm93IHtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuICAuc2lkZXJNZW51IHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMjRweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcblxyXG4gIC5NZW51IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgd2lkdGg6IDEwcHg7XHJcbiAgICB9XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9