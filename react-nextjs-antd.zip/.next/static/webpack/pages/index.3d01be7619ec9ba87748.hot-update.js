webpackHotUpdate_N_E("pages/index",{

/***/ "./src/languages/index.ts":
/*!********************************!*\
  !*** ./src/languages/index.ts ***!
  \********************************/
/*! exports provided: Language */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Language", function() { return Language; });
var langTH = {
  TITLE: ["ค้นหา", "Search"],
  RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
};
var Language = function Language(lang) {
  var SetLanguage = {};
  var indexTH = 0;
  var indexEN = 1;
  var Language = {
    Home: ["หน้าแรก", "HOME"],
    ProductType: ["หมวดสินค้า", "PRODUCT TYPE"],
    ProductList: ["สินค้าที่เลือก", "PRODUCT LIST"],
    ProductHistory: ["สินค้าที่สั่งซื้อแล้ว", "PRODUCT HISTORY"],
    ProductShipping: ["สินค้ากำลังจัดส่ง", "PRODUCT SHIPPING"],
    Search: ["ค้นหา", "Search"],
    RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"]
  };

  var getTH = function getTH() {
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexTH];
    SetLanguage.Home = Language.Home[indexTH];
    SetLanguage.ProductType = Language.ProductType[indexTH];
    return SetLanguage;
  };

  var getEN = function getEN() {
    SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexEN];
    SetLanguage.Home = Language.Home[indexEN];
    SetLanguage.ProductType = Language.ProductType[indexEN];
    return SetLanguage;
  };

  if (lang.toUpperCase() == "TH") {
    return getTH();
  }

  return getEN();
};
_c = Language;

var _c;

$RefreshReg$(_c, "Language");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2xhbmd1YWdlcy9pbmRleC50cyJdLCJuYW1lcyI6WyJsYW5nVEgiLCJUSVRMRSIsIlJlY29tbWVuZGVkUHJvZHVjdHMiLCJMYW5ndWFnZSIsImxhbmciLCJTZXRMYW5ndWFnZSIsImluZGV4VEgiLCJpbmRleEVOIiwiSG9tZSIsIlByb2R1Y3RUeXBlIiwiUHJvZHVjdExpc3QiLCJQcm9kdWN0SGlzdG9yeSIsIlByb2R1Y3RTaGlwcGluZyIsIlNlYXJjaCIsImdldFRIIiwiZ2V0RU4iLCJ0b1VwcGVyQ2FzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQSxJQUFNQSxNQUFNLEdBQUc7QUFDYkMsT0FBSyxFQUFFLENBQUMsT0FBRCxFQUFVLFFBQVYsQ0FETTtBQUViQyxxQkFBbUIsRUFBRSxDQUFDLGFBQUQsRUFBZ0Isc0JBQWhCO0FBRlIsQ0FBZjtBQUtPLElBQU1DLFFBQVEsR0FBRyxrQkFBQ0MsSUFBRCxFQUFrQjtBQUN4QyxNQUFJQyxXQUFnQixHQUFHLEVBQXZCO0FBQ0EsTUFBSUMsT0FBTyxHQUFHLENBQWQ7QUFDQSxNQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUVBLE1BQU1KLFFBQVEsR0FBRztBQUNmSyxRQUFJLEVBQUUsQ0FBQyxTQUFELEVBQVksTUFBWixDQURTO0FBRWZDLGVBQVcsRUFBRSxDQUFDLFlBQUQsRUFBZSxjQUFmLENBRkU7QUFHZkMsZUFBVyxFQUFFLENBQUMsZ0JBQUQsRUFBbUIsY0FBbkIsQ0FIRTtBQUlmQyxrQkFBYyxFQUFFLENBQUMsdUJBQUQsRUFBMEIsaUJBQTFCLENBSkQ7QUFLZkMsbUJBQWUsRUFBRSxDQUFDLG1CQUFELEVBQXNCLGtCQUF0QixDQUxGO0FBTWZDLFVBQU0sRUFBRSxDQUFDLE9BQUQsRUFBVSxRQUFWLENBTk87QUFPZlgsdUJBQW1CLEVBQUUsQ0FBQyxhQUFELEVBQWdCLHNCQUFoQjtBQVBOLEdBQWpCOztBQVNBLE1BQU1ZLEtBQUssR0FBRyxTQUFSQSxLQUFRLEdBQU07QUFDbEJULGVBQVcsQ0FBQ0gsbUJBQVosR0FBa0NDLFFBQVEsQ0FBQ0QsbUJBQVQsQ0FBNkJJLE9BQTdCLENBQWxDO0FBQ0FELGVBQVcsQ0FBQ0csSUFBWixHQUFtQkwsUUFBUSxDQUFDSyxJQUFULENBQWNGLE9BQWQsQ0FBbkI7QUFDQUQsZUFBVyxDQUFDSSxXQUFaLEdBQTBCTixRQUFRLENBQUNNLFdBQVQsQ0FBcUJILE9BQXJCLENBQTFCO0FBQ0EsV0FBT0QsV0FBUDtBQUNELEdBTEQ7O0FBTUEsTUFBTVUsS0FBSyxHQUFHLFNBQVJBLEtBQVEsR0FBTTtBQUNsQlYsZUFBVyxDQUFDSCxtQkFBWixHQUFrQ0MsUUFBUSxDQUFDRCxtQkFBVCxDQUE2QkssT0FBN0IsQ0FBbEM7QUFDQUYsZUFBVyxDQUFDRyxJQUFaLEdBQW1CTCxRQUFRLENBQUNLLElBQVQsQ0FBY0QsT0FBZCxDQUFuQjtBQUNBRixlQUFXLENBQUNJLFdBQVosR0FBMEJOLFFBQVEsQ0FBQ00sV0FBVCxDQUFxQkYsT0FBckIsQ0FBMUI7QUFDQSxXQUFPRixXQUFQO0FBQ0QsR0FMRDs7QUFPQSxNQUFJRCxJQUFJLENBQUNZLFdBQUwsTUFBc0IsSUFBMUIsRUFBZ0M7QUFDOUIsV0FBT0YsS0FBSyxFQUFaO0FBQ0Q7O0FBQ0QsU0FBT0MsS0FBSyxFQUFaO0FBQ0QsQ0EvQk07S0FBTVosUSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4zZDAxYmU3NjE5ZWM5YmE4Nzc0OC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgbGFuZ1RIID0ge1xyXG4gIFRJVExFOiBbXCLguITguYnguJnguKvguLJcIiwgXCJTZWFyY2hcIl0sXHJcbiAgUmVjb21tZW5kZWRQcm9kdWN0czogW1wi4Liq4Li04LiZ4LiE4LmJ4Liy4LmB4LiZ4Liw4LiZ4LizXCIsIFwiUmVjb21tZW5kZWQgUHJvZHVjdHNcIl0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgTGFuZ3VhZ2UgPSAobGFuZzogc3RyaW5nKSA9PiB7XHJcbiAgbGV0IFNldExhbmd1YWdlOiBhbnkgPSB7fTtcclxuICBsZXQgaW5kZXhUSCA9IDA7XHJcbiAgbGV0IGluZGV4RU4gPSAxO1xyXG5cclxuICBjb25zdCBMYW5ndWFnZSA9IHtcclxuICAgIEhvbWU6IFtcIuC4q+C4meC5ieC4suC5geC4o+C4gVwiLCBcIkhPTUVcIl0sXHJcbiAgICBQcm9kdWN0VHlwZTogW1wi4Lir4Lih4Lin4LiU4Liq4Li04LiZ4LiE4LmJ4LiyXCIsIFwiUFJPRFVDVCBUWVBFXCJdLFxyXG4gICAgUHJvZHVjdExpc3Q6IFtcIuC4quC4tOC4meC4hOC5ieC4suC4l+C4teC5iOC5gOC4peC4t+C4reC4gVwiLCBcIlBST0RVQ1QgTElTVFwiXSxcclxuICAgIFByb2R1Y3RIaXN0b3J5OiBbXCLguKrguLTguJnguITguYnguLLguJfguLXguYjguKrguLHguYjguIfguIvguLfguYnguK3guYHguKXguYnguKdcIiwgXCJQUk9EVUNUIEhJU1RPUllcIl0sXHJcbiAgICBQcm9kdWN0U2hpcHBpbmc6IFtcIuC4quC4tOC4meC4hOC5ieC4suC4geC4s+C4peC4seC4h+C4iOC4seC4lOC4quC5iOC4h1wiLCBcIlBST0RVQ1QgU0hJUFBJTkdcIl0sXHJcbiAgICBTZWFyY2g6IFtcIuC4hOC5ieC4meC4q+C4slwiLCBcIlNlYXJjaFwiXSxcclxuICAgIFJlY29tbWVuZGVkUHJvZHVjdHM6IFtcIuC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1wiLCBcIlJlY29tbWVuZGVkIFByb2R1Y3RzXCJdLFxyXG4gIH07XHJcbiAgY29uc3QgZ2V0VEggPSAoKSA9PiB7XHJcbiAgICBTZXRMYW5ndWFnZS5SZWNvbW1lbmRlZFByb2R1Y3RzID0gTGFuZ3VhZ2UuUmVjb21tZW5kZWRQcm9kdWN0c1tpbmRleFRIXTtcclxuICAgIFNldExhbmd1YWdlLkhvbWUgPSBMYW5ndWFnZS5Ib21lW2luZGV4VEhdO1xyXG4gICAgU2V0TGFuZ3VhZ2UuUHJvZHVjdFR5cGUgPSBMYW5ndWFnZS5Qcm9kdWN0VHlwZVtpbmRleFRIXTtcclxuICAgIHJldHVybiBTZXRMYW5ndWFnZTtcclxuICB9O1xyXG4gIGNvbnN0IGdldEVOID0gKCkgPT4ge1xyXG4gICAgU2V0TGFuZ3VhZ2UuUmVjb21tZW5kZWRQcm9kdWN0cyA9IExhbmd1YWdlLlJlY29tbWVuZGVkUHJvZHVjdHNbaW5kZXhFTl07XHJcbiAgICBTZXRMYW5ndWFnZS5Ib21lID0gTGFuZ3VhZ2UuSG9tZVtpbmRleEVOXTtcclxuICAgIFNldExhbmd1YWdlLlByb2R1Y3RUeXBlID0gTGFuZ3VhZ2UuUHJvZHVjdFR5cGVbaW5kZXhFTl07XHJcbiAgICByZXR1cm4gU2V0TGFuZ3VhZ2U7XHJcbiAgfTtcclxuXHJcbiAgaWYgKGxhbmcudG9VcHBlckNhc2UoKSA9PSBcIlRIXCIpIHtcclxuICAgIHJldHVybiBnZXRUSCgpO1xyXG4gIH1cclxuICByZXR1cm4gZ2V0RU4oKTtcclxufTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==