webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-sider.tsx":
/*!************************************!*\
  !*** ./src/components/c-sider.tsx ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CSider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _constants_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constants/index */ "./src/constants/index.ts");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Home */ "./node_modules/@2fd/ant-design-icons/lib/Home.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/History */ "./node_modules/@2fd/ant-design-icons/lib/History.js");
/* harmony import */ var _2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/FormatListBulletedSquare */ "./node_modules/@2fd/ant-design-icons/lib/FormatListBulletedSquare.js");
/* harmony import */ var _2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/CogOutline */ "./node_modules/@2fd/ant-design-icons/lib/CogOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/TruckDeliveryOutline */ "./node_modules/@2fd/ant-design-icons/lib/TruckDeliveryOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Shopping */ "./node_modules/@2fd/ant-design-icons/lib/Shopping.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-sider.tsx",
    _s = $RefreshSig$();













function CSider(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      menuKey = _useState[0],
      setMenuKey = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false),
      isLoading = _useState2[0],
      setIsLoading = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(),
      lang = _useState3[0],
      setlang = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    collapsed: false
  }),
      collapsed = _useState4[0],
      setCollapsed = _useState4[1];

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    var langs = Object(_languages__WEBPACK_IMPORTED_MODULE_13__["Language"])(state.language);
    console.log("langs.......", langs);
    setlang(langs);
  }, []);
  var MIST_MENU = [{
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HOME,
    title: lang.Home,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Home__WEBPACK_IMPORTED_MODULE_7___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].PRODUCT,
    title: lang.ProductType,
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Shopping__WEBPACK_IMPORTED_MODULE_12___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].LIST_PRODUCT,
    title: "รายการที่เลือก",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_FormatListBulletedSquare__WEBPACK_IMPORTED_MODULE_9___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].HISTORY,
    title: "สินค้าที่สั่งซื้อแล้ว",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_History__WEBPACK_IMPORTED_MODULE_8___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].TRANSPORT,
    title: "สินค้ากำลังจัดส่ง",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_TruckDeliveryOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 13
    }, this)
  }, {
    key: _constants_index__WEBPACK_IMPORTED_MODULE_6__["ROUTE_MENU"].SETTING,
    title: "ตั้งค่า",
    icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_CogOutline__WEBPACK_IMPORTED_MODULE_10___default.a, {
      style: {
        fontSize: 25
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 13
    }, this)
  }];
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {
    if (MIST_MENU) {
      setMenuKey(MIST_MENU[0].key);
    }

    setIsLoading(true);
  }, [state.language]);

  var onCollapse = function onCollapse(collapsed) {
    console.log(collapsed);
    setCollapsed({
      collapsed: collapsed
    });
  };

  var RouteMenu = function RouteMenu(item) {
    console.log(item);
    dispatch({
      type: "SET_ROUT_MUNU",
      payload: {
        routMenu: item.key
      }
    });
    setMenuKey(item.key);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(function () {}, [lang, MIST_MENU]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Siders, {
      collapsible: true,
      collapsed: collapsed.collapsed,
      onCollapse: onCollapse,
      theme: state.theme,
      width: 250,
      children: isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"], {
        mode: "inline",
        defaultSelectedKeys: [menuKey],
        className: "Menu",
        children: MIST_MENU.map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_3__["Menu"].Item, {
            className: "siderMenu",
            icon: item.icon,
            onClick: function onClick() {
              return RouteMenu(item);
            },
            children: item.title
          }, item.key, false, {
            fileName: _jsxFileName,
            lineNumber: 112,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 101,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(CSider, "N82JM6b+9rehuNAFDymKUNSO8CM=");

_c = CSider;
var Siders = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_3__["Layout"].Sider).withConfig({
  displayName: "c-sider__Siders",
  componentId: "o7xxc1-0"
})(["box-shadow:0px 0px 5px #000000;background-color:", ";overflow:hidden;.ant-menu-inline .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-menu-vertical .ant-menu-item:not(:last-child){margin-bottom:0px;}.ant-layout-sider-trigger{background-color:", ";}.ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected{background-color:", " !important;color:#fff;height:60px;padding-left:24px;display:flex;align-items:center;margin:0px;}.ant-menu-submenu > .ant-menu-submenu-title{height:60px;display:flex;align-items:center;color:", ";margin:0px;}.ant-menu-submenu-arrow{color:", ";}.siderMenu{height:60px;padding-left:24px;display:flex;align-items:center;color:", ";margin:0px;}.Menu{height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:10px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.3);border-radius:0px;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}}"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
}, function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
}, function (_ref5) {
  var theme = _ref5.theme;
  return theme.primary;
}, function (_ref6) {
  var theme = _ref6.theme;
  return theme.primary;
}, function (_ref7) {
  var theme = _ref7.theme;
  return theme.primary;
}, function (_ref8) {
  var theme = _ref8.theme;
  return theme.primary;
});
_c2 = Siders;

var _c, _c2;

$RefreshReg$(_c, "CSider");
$RefreshReg$(_c2, "Siders");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1zaWRlci50c3giXSwibmFtZXMiOlsiQ1NpZGVyIiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlU3RhdGUiLCJtZW51S2V5Iiwic2V0TWVudUtleSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImxhbmciLCJzZXRsYW5nIiwiY29sbGFwc2VkIiwic2V0Q29sbGFwc2VkIiwidXNlRWZmZWN0IiwibGFuZ3MiLCJMYW5ndWFnZSIsImxhbmd1YWdlIiwiY29uc29sZSIsImxvZyIsIk1JU1RfTUVOVSIsImtleSIsIk1FTlUiLCJIT01FIiwidGl0bGUiLCJIb21lIiwiaWNvbiIsImZvbnRTaXplIiwiUFJPRFVDVCIsIlByb2R1Y3RUeXBlIiwiTElTVF9QUk9EVUNUIiwiSElTVE9SWSIsIlRSQU5TUE9SVCIsIlNFVFRJTkciLCJvbkNvbGxhcHNlIiwiUm91dGVNZW51IiwiaXRlbSIsInR5cGUiLCJwYXlsb2FkIiwicm91dE1lbnUiLCJ0aGVtZSIsIm1hcCIsImluZGV4IiwiU2lkZXJzIiwic3R5bGVkIiwiTGF5b3V0IiwiU2lkZXIiLCJwcmltYXJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFTQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUllLFNBQVNBLE1BQVQsT0FBeUM7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQSxvQkFDMUJDLHdEQUFVLENBQUNDLGdEQUFELENBRGdCO0FBQUEsTUFDOUNDLEtBRDhDLGVBQzlDQSxLQUQ4QztBQUFBLE1BQ3ZDQyxRQUR1QyxlQUN2Q0EsUUFEdUM7O0FBQUEsa0JBRXhCQyxzREFBUSxFQUZnQjtBQUFBLE1BRS9DQyxPQUYrQztBQUFBLE1BRXRDQyxVQUZzQzs7QUFBQSxtQkFHcEJGLHNEQUFRLENBQUMsS0FBRCxDQUhZO0FBQUEsTUFHL0NHLFNBSCtDO0FBQUEsTUFHcENDLFlBSG9DOztBQUFBLG1CQUk5Qkosc0RBQVEsRUFKc0I7QUFBQSxNQUkvQ0ssSUFKK0M7QUFBQSxNQUl6Q0MsT0FKeUM7O0FBQUEsbUJBTXBCTixzREFBUSxDQUFDO0FBQ3pDTyxhQUFTLEVBQUU7QUFEOEIsR0FBRCxDQU5ZO0FBQUEsTUFNL0NBLFNBTitDO0FBQUEsTUFNcENDLFlBTm9DOztBQVN0REMseURBQVMsQ0FBQyxZQUFNO0FBQ2QsUUFBSUMsS0FBSyxHQUFHQyw0REFBUSxDQUFDYixLQUFLLENBQUNjLFFBQVAsQ0FBcEI7QUFDQUMsV0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QkosS0FBNUI7QUFDQUosV0FBTyxDQUFDSSxLQUFELENBQVA7QUFDRCxHQUpRLEVBSU4sRUFKTSxDQUFUO0FBTUEsTUFBTUssU0FBUyxHQUFHLENBQ2hCO0FBQ0VDLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ0MsSUFEWjtBQUVFQyxTQUFLLEVBQUVkLElBQUksQ0FBQ2UsSUFGZDtBQUdFQyxRQUFJLGVBQUUscUVBQUMscUVBQUQ7QUFBTSxXQUFLLEVBQUU7QUFBRUMsZ0JBQVEsRUFBRTtBQUFaO0FBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBRGdCLEVBTWhCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ00sT0FEWjtBQUVFSixTQUFLLEVBQUVkLElBQUksQ0FBQ21CLFdBRmQ7QUFHRUgsUUFBSSxlQUFFLHFFQUFDLDBFQUFEO0FBQWMsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FOZ0IsRUFXaEI7QUFDRU4sT0FBRyxFQUFFQywyREFBSSxDQUFDUSxZQURaO0FBRUVOLFNBQUssRUFBRSxnQkFGVDtBQUdFRSxRQUFJLGVBQUUscUVBQUMseUZBQUQ7QUFBOEIsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FYZ0IsRUFnQmhCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ1MsT0FEWjtBQUVFUCxTQUFLLEVBQUUsdUJBRlQ7QUFHRUUsUUFBSSxlQUFFLHFFQUFDLHdFQUFEO0FBQWEsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0FoQmdCLEVBcUJoQjtBQUNFTixPQUFHLEVBQUVDLDJEQUFJLENBQUNVLFNBRFo7QUFFRVIsU0FBSyxFQUFFLG1CQUZUO0FBR0VFLFFBQUksZUFBRSxxRUFBQyxzRkFBRDtBQUEwQixXQUFLLEVBQUU7QUFBRUMsZ0JBQVEsRUFBRTtBQUFaO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQXJCZ0IsRUEwQmhCO0FBQ0VOLE9BQUcsRUFBRUMsMkRBQUksQ0FBQ1csT0FEWjtBQUVFVCxTQUFLLEVBQUUsU0FGVDtBQUdFRSxRQUFJLGVBQUUscUVBQUMsNEVBQUQ7QUFBZ0IsV0FBSyxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsR0ExQmdCLENBQWxCO0FBaUNBYix5REFBUyxDQUFDLFlBQU07QUFDZCxRQUFJTSxTQUFKLEVBQWU7QUFDYmIsZ0JBQVUsQ0FBQ2EsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxHQUFkLENBQVY7QUFDRDs7QUFDRFosZ0JBQVksQ0FBQyxJQUFELENBQVo7QUFDRCxHQUxRLEVBS04sQ0FBQ04sS0FBSyxDQUFDYyxRQUFQLENBTE0sQ0FBVDs7QUFPQSxNQUFNaUIsVUFBVSxHQUFHLFNBQWJBLFVBQWEsQ0FBQ3RCLFNBQUQsRUFBZTtBQUNoQ00sV0FBTyxDQUFDQyxHQUFSLENBQVlQLFNBQVo7QUFDQUMsZ0JBQVksQ0FBQztBQUFFRCxlQUFTLEVBQVRBO0FBQUYsS0FBRCxDQUFaO0FBQ0QsR0FIRDs7QUFLQSxNQUFNdUIsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQ0MsSUFBRCxFQUFVO0FBQzFCbEIsV0FBTyxDQUFDQyxHQUFSLENBQVlpQixJQUFaO0FBQ0FoQyxZQUFRLENBQUM7QUFDUGlDLFVBQUksRUFBRSxlQURDO0FBRVBDLGFBQU8sRUFBRTtBQUNQQyxnQkFBUSxFQUFFSCxJQUFJLENBQUNmO0FBRFI7QUFGRixLQUFELENBQVI7QUFNQWQsY0FBVSxDQUFDNkIsSUFBSSxDQUFDZixHQUFOLENBQVY7QUFDRCxHQVREOztBQVdBUCx5REFBUyxDQUFDLFlBQU0sQ0FBRSxDQUFULEVBQVcsQ0FBQ0osSUFBRCxFQUFPVSxTQUFQLENBQVgsQ0FBVDtBQUVBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsTUFBRDtBQUNFLGlCQUFXLE1BRGI7QUFFRSxlQUFTLEVBQUVSLFNBQVMsQ0FBQ0EsU0FGdkI7QUFHRSxnQkFBVSxFQUFFc0IsVUFIZDtBQUlFLFdBQUssRUFBRS9CLEtBQUssQ0FBQ3FDLEtBSmY7QUFLRSxXQUFLLEVBQUUsR0FMVDtBQUFBLGdCQU9HaEMsU0FBUyxpQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFlBQUksRUFBQyxRQUFYO0FBQW9CLDJCQUFtQixFQUFFLENBQUNGLE9BQUQsQ0FBekM7QUFBb0QsaUJBQVMsRUFBQyxNQUE5RDtBQUFBLGtCQUNHYyxTQUFTLENBQUNxQixHQUFWLENBQWMsVUFBQ0wsSUFBRCxFQUFPTSxLQUFQLEVBQWlCO0FBQzlCLDhCQUNFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUVFLHFCQUFTLEVBQUMsV0FGWjtBQUdFLGdCQUFJLEVBQUVOLElBQUksQ0FBQ1YsSUFIYjtBQUlFLG1CQUFPLEVBQUU7QUFBQSxxQkFBTVMsU0FBUyxDQUFDQyxJQUFELENBQWY7QUFBQSxhQUpYO0FBQUEsc0JBTUdBLElBQUksQ0FBQ1o7QUFOUixhQUNPWSxJQUFJLENBQUNmLEdBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQVVELFNBWEE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLG1CQURGO0FBNEJEOztHQXJHdUJyQixNOztLQUFBQSxNO0FBdUd4QixJQUFNMkMsTUFBTSxHQUFHQyxpRUFBTSxDQUFDQywyQ0FBTSxDQUFDQyxLQUFSLENBQVQ7QUFBQTtBQUFBO0FBQUEsbzZCQUVVO0FBQUEsTUFBR04sS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTyxPQUFyQjtBQUFBLENBRlYsRUFXWTtBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQVhaLEVBY1k7QUFBQSxNQUFHUCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNPLE9BQXJCO0FBQUEsQ0FkWixFQTBCQztBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQTFCRCxFQThCQztBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQTlCRCxFQXFDQztBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQXJDRCxFQXVEYztBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ08sT0FBckI7QUFBQSxDQXZEZCxDQUFaO01BQU1KLE0iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguY2IyNjcxMjc3OGE3MjYxNjQ4ZTEuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnJlYWRjcnVtYiwgTGF5b3V0LCBNZW51IH0gZnJvbSBcImFudGRcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgRGVza3RvcE91dGxpbmVkLFxyXG4gIFBpZUNoYXJ0T3V0bGluZWQsXHJcbiAgRmlsZU91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBVc2VyT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gXCJhbnRkL2xpYi9sYXlvdXQvbGF5b3V0XCI7XHJcbmltcG9ydCBTdWJNZW51IGZyb20gXCJhbnRkL2xpYi9tZW51L1N1Yk1lbnVcIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi9jb250ZXh0XCI7XHJcbmltcG9ydCB7IFJPVVRFX01FTlUgYXMgTUVOVSB9IGZyb20gXCIuLi9jb25zdGFudHMvaW5kZXhcIjtcclxuaW1wb3J0IEhvbWUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSG9tZVwiO1xyXG5pbXBvcnQgSGlzdG9yeUljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvSGlzdG9yeVwiO1xyXG5pbXBvcnQgRm9ybWF0TGlzdEJ1bGxldGVkU3F1YXJlSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9Gb3JtYXRMaXN0QnVsbGV0ZWRTcXVhcmVcIjtcclxuaW1wb3J0IENvZ091dGxpbmVJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NvZ091dGxpbmVcIjtcclxuaW1wb3J0IFRydWNrRGVsaXZlcnlPdXRsaW5lSWNvbiBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9UcnVja0RlbGl2ZXJ5T3V0bGluZVwiO1xyXG5pbXBvcnQgU2hvcHBpbmdJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1Nob3BwaW5nXCI7XHJcbmltcG9ydCB7IExhbmd1YWdlIH0gZnJvbSBcIi4uL2xhbmd1YWdlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDU2lkZXIoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlLCBkaXNwYXRjaCB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICBjb25zdCBbbWVudUtleSwgc2V0TWVudUtleV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KCk7XHJcblxyXG4gIGNvbnN0IFtjb2xsYXBzZWQsIHNldENvbGxhcHNlZF0gPSB1c2VTdGF0ZSh7XHJcbiAgICBjb2xsYXBzZWQ6IGZhbHNlLFxyXG4gIH0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgbGFuZ3MgPSBMYW5ndWFnZShzdGF0ZS5sYW5ndWFnZSk7XHJcbiAgICBjb25zb2xlLmxvZyhcImxhbmdzLi4uLi4uLlwiLCBsYW5ncyk7XHJcbiAgICBzZXRsYW5nKGxhbmdzKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IE1JU1RfTUVOVSA9IFtcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhPTUUsXHJcbiAgICAgIHRpdGxlOiBsYW5nLkhvbWUsXHJcbiAgICAgIGljb246IDxIb21lIHN0eWxlPXt7IGZvbnRTaXplOiAyNSB9fSAvPixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogTUVOVS5QUk9EVUNULFxyXG4gICAgICB0aXRsZTogbGFuZy5Qcm9kdWN0VHlwZSxcclxuICAgICAgaWNvbjogPFNob3BwaW5nSWNvbiBzdHlsZT17eyBmb250U2l6ZTogMjUgfX0gLz4sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IE1FTlUuTElTVF9QUk9EVUNULFxyXG4gICAgICB0aXRsZTogXCLguKPguLLguKLguIHguLLguKPguJfguLXguYjguYDguKXguLfguK3guIFcIixcclxuICAgICAgaWNvbjogPEZvcm1hdExpc3RCdWxsZXRlZFNxdWFyZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLkhJU1RPUlksXHJcbiAgICAgIHRpdGxlOiBcIuC4quC4tOC4meC4hOC5ieC4suC4l+C4teC5iOC4quC4seC5iOC4h+C4i+C4t+C5ieC4reC5geC4peC5ieC4p1wiLFxyXG4gICAgICBpY29uOiA8SGlzdG9yeUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlRSQU5TUE9SVCxcclxuICAgICAgdGl0bGU6IFwi4Liq4Li04LiZ4LiE4LmJ4Liy4LiB4Liz4Lil4Lix4LiH4LiI4Lix4LiU4Liq4LmI4LiHXCIsXHJcbiAgICAgIGljb246IDxUcnVja0RlbGl2ZXJ5T3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBNRU5VLlNFVFRJTkcsXHJcbiAgICAgIHRpdGxlOiBcIuC4leC4seC5ieC4h+C4hOC5iOC4slwiLFxyXG4gICAgICBpY29uOiA8Q29nT3V0bGluZUljb24gc3R5bGU9e3sgZm9udFNpemU6IDI1IH19IC8+LFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKE1JU1RfTUVOVSkge1xyXG4gICAgICBzZXRNZW51S2V5KE1JU1RfTUVOVVswXS5rZXkpO1xyXG4gICAgfVxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gIH0sIFtzdGF0ZS5sYW5ndWFnZV0pO1xyXG5cclxuICBjb25zdCBvbkNvbGxhcHNlID0gKGNvbGxhcHNlZCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coY29sbGFwc2VkKTtcclxuICAgIHNldENvbGxhcHNlZCh7IGNvbGxhcHNlZCB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBSb3V0ZU1lbnUgPSAoaXRlbSkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coaXRlbSk7XHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1JPVVRfTVVOVVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgcm91dE1lbnU6IGl0ZW0ua2V5LFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBzZXRNZW51S2V5KGl0ZW0ua2V5KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge30sIFtsYW5nLCBNSVNUX01FTlVdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxTaWRlcnNcclxuICAgICAgICBjb2xsYXBzaWJsZVxyXG4gICAgICAgIGNvbGxhcHNlZD17Y29sbGFwc2VkLmNvbGxhcHNlZH1cclxuICAgICAgICBvbkNvbGxhcHNlPXtvbkNvbGxhcHNlfVxyXG4gICAgICAgIHRoZW1lPXtzdGF0ZS50aGVtZX1cclxuICAgICAgICB3aWR0aD17MjUwfVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8TWVudSBtb2RlPVwiaW5saW5lXCIgZGVmYXVsdFNlbGVjdGVkS2V5cz17W21lbnVLZXldfSBjbGFzc05hbWU9XCJNZW51XCI+XHJcbiAgICAgICAgICAgIHtNSVNUX01FTlUubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8TWVudS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5rZXl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGVyTWVudVwiXHJcbiAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gUm91dGVNZW51KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvU2lkZXJzPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgU2lkZXJzID0gc3R5bGVkKExheW91dC5TaWRlcilgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCA1cHggIzAwMDAwMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgLmFudC1tZW51LWlubGluZSAuYW50LW1lbnUtaXRlbTpub3QoOmxhc3QtY2hpbGQpIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXZlcnRpY2FsIC5hbnQtbWVudS1pdGVtOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxuICAuYW50LWxheW91dC1zaWRlci10cmlnZ2VyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgfVxyXG4gIC5hbnQtbWVudTpub3QoLmFudC1tZW51LWhvcml6b250YWwpIC5hbnQtbWVudS1pdGVtLXNlbGVjdGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcbiAgLmFudC1tZW51LXN1Ym1lbnUgPiAuYW50LW1lbnUtc3VibWVudS10aXRsZSB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgfVxyXG4gIC5hbnQtbWVudS1zdWJtZW51LWFycm93IHtcclxuICAgIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuICAuc2lkZXJNZW51IHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMjRweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICBtYXJnaW46IDBweDtcclxuICB9XHJcblxyXG4gIC5NZW51IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgd2lkdGg6IDEwcHg7XHJcbiAgICB9XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgfVxyXG5cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX07XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9