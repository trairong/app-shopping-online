webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-header.tsx":
/*!*************************************!*\
  !*** ./src/components/c-header.tsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CHeader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Account */ "./node_modules/@2fd/ant-design-icons/lib/Account.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/AccountCircle */ "./node_modules/@2fd/ant-design-icons/lib/AccountCircle.js");
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Cart */ "./node_modules/@2fd/ant-design-icons/lib/Cart.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/ViewGrid */ "./node_modules/@2fd/ant-design-icons/lib/ViewGrid.js");
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/BellOutline */ "./node_modules/@2fd/ant-design-icons/lib/BellOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-header.tsx",
    _s = $RefreshSig$();












var Header = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Header,
    Footer = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Footer,
    Sider = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Sider,
    Content = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Content;
function CHeader(_ref) {
  _s();

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_6__["Context"]),
      state = _useContext.state;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      lang = _useState[0],
      setlang = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      isLoad = _useState2[0],
      setisLoad = _useState2[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_12__["Language"])(state.language));
    setisLoad(true);
  }, [state.language]);
  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {}, [lang]);

  var menu = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"], {
    style: {
      width: 200
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["UserOutlined"], {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 32
      }, this),
      children: "Profile"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default.a, {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 32
      }, this),
      children: "Logout"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, this);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Headers, {
      theme: state.theme,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        style: {
          height: "100%",
          display: "flex",
          alignItems: "center"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            display: "flex",
            height: '100%'
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Images, {
            src: "/images/shopping_1.png",
            preview: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 12,
          style: {
            display: "flex",
            alignItems: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Input"], {
            placeholder: "INPUT SEARCH",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            },
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["SearchOutlined"], {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 57,
              columnNumber: 21
            }, this),
            children: lang.Search
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 54,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            textAlign: "end"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 66,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 63,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 78,
              columnNumber: 21
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            overlay: menu,
            placement: "bottomLeft",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: "primary",
              shape: "circle",
              icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default.a, {
                style: {
                  fontSize: 30
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 23
              }, this),
              style: {
                width: 50,
                height: 50
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 82,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(CHeader, "Vu1mDzOW0q9wjGM6Zu4R7QE0EFs=");

_c = CHeader;
var Headers = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(Header).withConfig({
  displayName: "c-header__Headers",
  componentId: "sc-18zra2i-0"
})(["background-color:", ";box-shadow:0px 0px 5px #000000;padding:0px;height:80px;position:sticky;top:0px;z-index:3;"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = Headers;
var Images = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"]).withConfig({
  displayName: "c-header__Images",
  componentId: "sc-18zra2i-1"
})(["height:100%;width:100px;padding-left:0px;"]);
_c3 = Images;

var _c, _c2, _c3;

$RefreshReg$(_c, "CHeader");
$RefreshReg$(_c2, "Headers");
$RefreshReg$(_c3, "Images");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1oZWFkZXIudHN4Il0sIm5hbWVzIjpbIkhlYWRlciIsIkxheW91dCIsIkZvb3RlciIsIlNpZGVyIiwiQ29udGVudCIsIkNIZWFkZXIiLCJ1c2VDb250ZXh0IiwiQ29udGV4dCIsInN0YXRlIiwidXNlU3RhdGUiLCJsYW5nIiwic2V0bGFuZyIsImlzTG9hZCIsInNldGlzTG9hZCIsInVzZUVmZmVjdCIsIkxhbmd1YWdlIiwibGFuZ3VhZ2UiLCJtZW51Iiwid2lkdGgiLCJmb250U2l6ZSIsInRoZW1lIiwiaGVpZ2h0IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJTZWFyY2giLCJ0ZXh0QWxpZ24iLCJIZWFkZXJzIiwic3R5bGVkIiwicHJpbWFyeSIsIkltYWdlcyIsIkltYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBRVFBLE0sR0FBbUNDLDJDLENBQW5DRCxNO0lBQVFFLE0sR0FBMkJELDJDLENBQTNCQyxNO0lBQVFDLEssR0FBbUJGLDJDLENBQW5CRSxLO0lBQU9DLE8sR0FBWUgsMkMsQ0FBWkcsTztBQUloQixTQUFTQyxPQUFULE9BQTBDO0FBQUE7O0FBQUE7O0FBQUEsb0JBQ3JDQyx3REFBVSxDQUFDQyxnREFBRCxDQUQyQjtBQUFBLE1BQy9DQyxLQUQrQyxlQUMvQ0EsS0FEK0M7O0FBQUEsa0JBRS9CQyxzREFBUSxDQUFNLElBQU4sQ0FGdUI7QUFBQSxNQUVoREMsSUFGZ0Q7QUFBQSxNQUUxQ0MsT0FGMEM7O0FBQUEsbUJBRzNCRixzREFBUSxDQUFDLEtBQUQsQ0FIbUI7QUFBQSxNQUdoREcsTUFIZ0Q7QUFBQSxNQUd4Q0MsU0FId0M7O0FBS3ZEQyx5REFBUyxDQUFDLFlBQU07QUFDZEgsV0FBTyxDQUFDSSw0REFBUSxDQUFDUCxLQUFLLENBQUNRLFFBQVAsQ0FBVCxDQUFQO0FBQ0FILGFBQVMsQ0FBQyxJQUFELENBQVQ7QUFDRCxHQUhRLEVBR04sQ0FBQ0wsS0FBSyxDQUFDUSxRQUFQLENBSE0sQ0FBVDtBQUtBRix5REFBUyxDQUFDLFlBQU0sQ0FFZixDQUZRLEVBRU4sQ0FBQ0osSUFBRCxDQUZNLENBQVQ7O0FBSUEsTUFBTU8sSUFBSSxnQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFNBQUssRUFBRTtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUFiO0FBQUEsNEJBQ0UscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQW1CLFVBQUksZUFBRSxxRUFBQyw4REFBRDtBQUFjLGFBQUssRUFBRTtBQUFFQyxrQkFBUSxFQUFFO0FBQVo7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUF6QjtBQUFBO0FBQUEsT0FBZSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUFtQixVQUFJLGVBQUUscUVBQUMsd0VBQUQ7QUFBYSxhQUFLLEVBQUU7QUFBRUEsa0JBQVEsRUFBRTtBQUFaO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBekI7QUFBQTtBQUFBLE9BQWUsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7O0FBV0Esc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxPQUFEO0FBQVMsV0FBSyxFQUFFWCxLQUFLLENBQUNZLEtBQXRCO0FBQUEsNkJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxhQUFLLEVBQUU7QUFBRUMsZ0JBQU0sRUFBRSxNQUFWO0FBQWtCQyxpQkFBTyxFQUFFLE1BQTNCO0FBQW1DQyxvQkFBVSxFQUFFO0FBQS9DLFNBQVo7QUFBQSxnQ0FDRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQVksZUFBSyxFQUFFO0FBQUVELG1CQUFPLEVBQUUsTUFBWDtBQUFtQkQsa0JBQU0sRUFBRTtBQUEzQixXQUFuQjtBQUFBLGlDQUNFLHFFQUFDLE1BQUQ7QUFBUSxlQUFHLEVBQUMsd0JBQVo7QUFBcUMsbUJBQU8sRUFBRTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUlFLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLEVBQVQ7QUFBYSxlQUFLLEVBQUU7QUFBRUMsbUJBQU8sRUFBRSxNQUFYO0FBQW1CQyxzQkFBVSxFQUFFO0FBQS9CLFdBQXBCO0FBQUEsa0NBQ0UscUVBQUMsMENBQUQ7QUFDRSx1QkFBVyxFQUFDLGNBRGQ7QUFFRSxpQkFBSyxFQUFFO0FBQUVDLDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUI7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBS0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFFO0FBQUVELDBCQUFZLEVBQUUsQ0FBaEI7QUFBbUJDLHVCQUFTLEVBQUU7QUFBOUIsYUFGVDtBQUdFLGdCQUFJLGVBQUUscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUFBLHNCQUtHZixJQUFJLENBQUNnQjtBQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGLGVBaUJFLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBWSxlQUFLLEVBQUU7QUFBRUMscUJBQVMsRUFBRTtBQUFiLFdBQW5CO0FBQUEsa0NBQ0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFDLFFBRlI7QUFHRSxnQkFBSSxlQUFFLHFFQUFDLDZFQUFEO0FBQWEsbUJBQUssRUFBRTtBQUFFUix3QkFBUSxFQUFFO0FBQVo7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFIUjtBQUlFLGlCQUFLLEVBQUU7QUFBRUQsbUJBQUssRUFBRSxFQUFUO0FBQWFHLG9CQUFNLEVBQUU7QUFBckI7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBT0UscUVBQUMsMkNBQUQ7QUFDRSxnQkFBSSxFQUFDLFNBRFA7QUFFRSxpQkFBSyxFQUFDLFFBRlI7QUFHRSxnQkFBSSxlQUFFLHFFQUFDLHFFQUFEO0FBQU0sbUJBQUssRUFBRTtBQUFFRix3QkFBUSxFQUFFO0FBQVo7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUhSO0FBSUUsaUJBQUssRUFBRTtBQUFFRCxtQkFBSyxFQUFFLEVBQVQ7QUFBYUcsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUEYsZUFhRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMsMEVBQUQ7QUFBVSxtQkFBSyxFQUFFO0FBQUVGLHdCQUFRLEVBQUU7QUFBWjtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUhSO0FBSUUsaUJBQUssRUFBRTtBQUFFRCxtQkFBSyxFQUFFLEVBQVQ7QUFBYUcsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBYkYsZUFtQkUscUVBQUMsNkNBQUQ7QUFBVSxtQkFBTyxFQUFFSixJQUFuQjtBQUF5QixxQkFBUyxFQUFDLFlBQW5DO0FBQUEsbUNBQ0UscUVBQUMsMkNBQUQ7QUFDRSxrQkFBSSxFQUFDLFNBRFA7QUFFRSxtQkFBSyxFQUFDLFFBRlI7QUFHRSxrQkFBSSxlQUFFLHFFQUFDLDhFQUFEO0FBQWUscUJBQUssRUFBRTtBQUFFRSwwQkFBUSxFQUFFO0FBQVo7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFIUjtBQUlFLG1CQUFLLEVBQUU7QUFBRUQscUJBQUssRUFBRSxFQUFUO0FBQWFHLHNCQUFNLEVBQUU7QUFBckI7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsbUJBREY7QUEyREQ7O0dBcEZ1QmhCLE87O0tBQUFBLE87QUFzRnhCLElBQU11QixPQUFPLEdBQUdDLGlFQUFNLENBQUM3QixNQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsd0hBQ1M7QUFBQSxNQUFHb0IsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDVSxPQUFyQjtBQUFBLENBRFQsQ0FBYjtNQUFNRixPO0FBV04sSUFBTUcsTUFBTSxHQUFHRixpRUFBTSxDQUFDRywwQ0FBRCxDQUFUO0FBQUE7QUFBQTtBQUFBLGlEQUFaO01BQU1ELE0iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYTI3OTIxZTFiMWI3ZTNkMjY2MTIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbCwgUm93LCBMYXlvdXQsIElucHV0LCBCdXR0b24sIEltYWdlLCBEcm9wZG93biwgTWVudSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQXVkaW9PdXRsaW5lZCwgU2VhcmNoT3V0bGluZWQsIFVzZXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRcIjtcclxuaW1wb3J0IEFjY291bnRJY29uIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0FjY291bnRcIjtcclxuaW1wb3J0IEFjY291bnRDaXJjbGUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudENpcmNsZVwiO1xyXG5pbXBvcnQgQ2FydCBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9DYXJ0XCI7XHJcbmltcG9ydCBWaWV3R3JpZCBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9WaWV3R3JpZFwiO1xyXG5pbXBvcnQgQmVsbE91dGxpbmUgZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQmVsbE91dGxpbmVcIjtcclxuaW1wb3J0IHsgTGFuZ3VhZ2UgfSBmcm9tIFwiLi4vbGFuZ3VhZ2VzXCI7XHJcblxyXG5jb25zdCB7IEhlYWRlciwgRm9vdGVyLCBTaWRlciwgQ29udGVudCB9ID0gTGF5b3V0O1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDSGVhZGVyKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KG51bGwpO1xyXG4gIGNvbnN0IFtpc0xvYWQsIHNldGlzTG9hZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldGxhbmcoTGFuZ3VhZ2Uoc3RhdGUubGFuZ3VhZ2UpKTtcclxuICAgIHNldGlzTG9hZCh0cnVlKVxyXG4gIH0sIFtzdGF0ZS5sYW5ndWFnZV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG5cclxuICB9LCBbbGFuZ10pXHJcblxyXG4gIGNvbnN0IG1lbnUgPSAoXHJcbiAgICA8TWVudSBzdHlsZT17eyB3aWR0aDogMjAwIH19PlxyXG4gICAgICA8TWVudS5JdGVtIGtleT1cIjFcIiBpY29uPXs8VXNlck91dGxpbmVkIHN0eWxlPXt7IGZvbnRTaXplOiAyMCB9fSAvPn0+XHJcbiAgICAgICAgUHJvZmlsZVxyXG4gICAgICA8L01lbnUuSXRlbT5cclxuICAgICAgPE1lbnUuSXRlbSBrZXk9XCIxXCIgaWNvbj17PEFjY291bnRJY29uIHN0eWxlPXt7IGZvbnRTaXplOiAyMCB9fSAvPn0+XHJcbiAgICAgICAgTG9nb3V0XHJcbiAgICAgIDwvTWVudS5JdGVtPlxyXG4gICAgPC9NZW51PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8SGVhZGVycyB0aGVtZT17c3RhdGUudGhlbWV9PlxyXG4gICAgICAgIDxSb3cgc3R5bGU9e3sgaGVpZ2h0OiBcIjEwMCVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICA8Q29sIG1kPXs2fSBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiAsaGVpZ2h0OiAnMTAwJSd9fT5cclxuICAgICAgICAgICAgPEltYWdlcyBzcmM9XCIvaW1hZ2VzL3Nob3BwaW5nXzEucG5nXCIgcHJldmlldz17ZmFsc2V9IC8+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgbWQ9ezEyfSBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJTlBVVCBTRUFSQ0hcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMCwgYm94U2hhZG93OiBcIjBweCAwcHggMnB4ICMwMDAwMDBcIiB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMCwgYm94U2hhZG93OiBcIjBweCAwcHggMnB4ICMwMDAwMDBcIiB9fVxyXG4gICAgICAgICAgICAgIGljb249ezxTZWFyY2hPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtsYW5nLlNlYXJjaH1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgbWQ9ezZ9IHN0eWxlPXt7IHRleHRBbGlnbjogXCJlbmRcIiB9fT5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBzaGFwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgaWNvbj17PEJlbGxPdXRsaW5lIHN0eWxlPXt7IGZvbnRTaXplOiAzMCB9fSAvPn1cclxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTAsIGhlaWdodDogNTAgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBzaGFwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgaWNvbj17PENhcnQgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICBpY29uPXs8Vmlld0dyaWQgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8RHJvcGRvd24gb3ZlcmxheT17bWVudX0gcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgIGljb249ezxBY2NvdW50Q2lyY2xlIHN0eWxlPXt7IGZvbnRTaXplOiAzMCB9fSAvPn1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcblxyXG4gICAgICAgICAgICB7LyogPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMCB9fT5cclxuICAgICAgICAgICAgICBSRUdJU1RFUlxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMCwgbWFyZ2luUmlnaHQ6IDEwIH19PlxyXG4gICAgICAgICAgICAgIExPR0lOXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPiAqL31cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG4gICAgICA8L0hlYWRlcnM+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBIZWFkZXJzID0gc3R5bGVkKEhlYWRlcilgXHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBib3gtc2hhZG93OiAwcHggMHB4IDVweCAjMDAwMDAwO1xyXG4gIHBhZGRpbmc6IDBweDtcclxuICBoZWlnaHQ6IDgwcHg7XHJcbiAgLyogZGlzcGxheTogZmxleDsgKi9cclxuICBwb3NpdGlvbjogc3RpY2t5O1xyXG4gIHRvcDogMHB4O1xyXG4gIHotaW5kZXg6IDM7XHJcbmA7XHJcblxyXG5jb25zdCBJbWFnZXMgPSBzdHlsZWQoSW1hZ2UpYFxyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwcHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=