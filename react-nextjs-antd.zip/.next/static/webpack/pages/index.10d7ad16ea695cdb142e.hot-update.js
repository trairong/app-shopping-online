webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/c-header.tsx":
/*!*************************************!*\
  !*** ./src/components/c-header.tsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CHeader; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../context */ "./src/context/index.tsx");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Account */ "./node_modules/@2fd/ant-design-icons/lib/Account.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/AccountCircle */ "./node_modules/@2fd/ant-design-icons/lib/AccountCircle.js");
/* harmony import */ var _2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/Cart */ "./node_modules/@2fd/ant-design-icons/lib/Cart.js");
/* harmony import */ var _2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/ViewGrid */ "./node_modules/@2fd/ant-design-icons/lib/ViewGrid.js");
/* harmony import */ var _2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @2fd/ant-design-icons/lib/BellOutline */ "./node_modules/@2fd/ant-design-icons/lib/BellOutline.js");
/* harmony import */ var _2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\c-header.tsx",
    _s = $RefreshSig$();












var Header = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Header,
    Footer = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Footer,
    Sider = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Sider,
    Content = antd__WEBPACK_IMPORTED_MODULE_2__["Layout"].Content;
function CHeader(_ref) {
  _s();

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_6__["Context"]),
      state = _useContext.state;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(null),
      lang = _useState[0],
      setlang = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      isLoad = _useState2[0],
      setisLoad = _useState2[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_12__["Language"])(state.language));
    setisLoad(true);
  }, [state.language]);
  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {}, [lang]);

  var menu = /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"], {
    style: {
      width: 200
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["UserOutlined"], {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 32
      }, this),
      children: "Profile"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Menu"].Item, {
      icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Account__WEBPACK_IMPORTED_MODULE_7___default.a, {
        style: {
          fontSize: 20
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 32
      }, this),
      children: "Logout"
    }, "1", false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, this);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: isLoad && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Headers, {
      theme: state.theme,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        style: {
          height: "100%",
          display: "flex",
          alignItems: "center"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            display: "flex",
            height: "100%"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Images, {
            src: "/images/shopping_1.png",
            preview: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 12,
          style: {
            display: "flex",
            alignItems: "center"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Input"], {
            placeholder: "INPUT SEARCH",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            style: {
              borderRadius: 0,
              boxShadow: "0px 0px 2px #000000"
            },
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__["SearchOutlined"], {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 58,
              columnNumber: 23
            }, this),
            children: lang.Search
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          md: 6,
          style: {
            textAlign: "end"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_BellOutline__WEBPACK_IMPORTED_MODULE_11___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_Cart__WEBPACK_IMPORTED_MODULE_9___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
            type: "primary",
            shape: "circle",
            icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_ViewGrid__WEBPACK_IMPORTED_MODULE_10___default.a, {
              style: {
                fontSize: 30
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 23
            }, this),
            style: {
              width: 50,
              height: 50
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Dropdown"], {
            overlay: menu,
            placement: "bottomLeft",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Button"], {
              type: "primary",
              shape: "circle",
              icon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_2fd_ant_design_icons_lib_AccountCircle__WEBPACK_IMPORTED_MODULE_8___default.a, {
                style: {
                  fontSize: 30
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 25
              }, this),
              style: {
                width: 50,
                height: 50
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 83,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 11
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

_s(CHeader, "Vu1mDzOW0q9wjGM6Zu4R7QE0EFs=");

_c = CHeader;
var Headers = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(Header).withConfig({
  displayName: "c-header__Headers",
  componentId: "sc-18zra2i-0"
})(["background-color:", ";box-shadow:0px 0px 5px #000000;padding:0px;height:80px;position:sticky;top:0px;z-index:3;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = Headers;
var Images = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"]).withConfig({
  displayName: "c-header__Images",
  componentId: "sc-18zra2i-1"
})(["height:100%;width:100px;padding-left:0px;"]);
_c3 = Images;

var _c, _c2, _c3;

$RefreshReg$(_c, "CHeader");
$RefreshReg$(_c2, "Headers");
$RefreshReg$(_c3, "Images");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvYy1oZWFkZXIudHN4Il0sIm5hbWVzIjpbIkhlYWRlciIsIkxheW91dCIsIkZvb3RlciIsIlNpZGVyIiwiQ29udGVudCIsIkNIZWFkZXIiLCJ1c2VDb250ZXh0IiwiQ29udGV4dCIsInN0YXRlIiwidXNlU3RhdGUiLCJsYW5nIiwic2V0bGFuZyIsImlzTG9hZCIsInNldGlzTG9hZCIsInVzZUVmZmVjdCIsIkxhbmd1YWdlIiwibGFuZ3VhZ2UiLCJtZW51Iiwid2lkdGgiLCJmb250U2l6ZSIsInRoZW1lIiwiaGVpZ2h0IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJTZWFyY2giLCJ0ZXh0QWxpZ24iLCJIZWFkZXJzIiwic3R5bGVkIiwicHJpbWFyeSIsIkltYWdlcyIsIkltYWdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBRVFBLE0sR0FBbUNDLDJDLENBQW5DRCxNO0lBQVFFLE0sR0FBMkJELDJDLENBQTNCQyxNO0lBQVFDLEssR0FBbUJGLDJDLENBQW5CRSxLO0lBQU9DLE8sR0FBWUgsMkMsQ0FBWkcsTztBQUloQixTQUFTQyxPQUFULE9BQTBDO0FBQUE7O0FBQUE7O0FBQUEsb0JBQ3JDQyx3REFBVSxDQUFDQyxnREFBRCxDQUQyQjtBQUFBLE1BQy9DQyxLQUQrQyxlQUMvQ0EsS0FEK0M7O0FBQUEsa0JBRS9CQyxzREFBUSxDQUFNLElBQU4sQ0FGdUI7QUFBQSxNQUVoREMsSUFGZ0Q7QUFBQSxNQUUxQ0MsT0FGMEM7O0FBQUEsbUJBRzNCRixzREFBUSxDQUFDLEtBQUQsQ0FIbUI7QUFBQSxNQUdoREcsTUFIZ0Q7QUFBQSxNQUd4Q0MsU0FId0M7O0FBS3ZEQyx5REFBUyxDQUFDLFlBQU07QUFDZEgsV0FBTyxDQUFDSSw0REFBUSxDQUFDUCxLQUFLLENBQUNRLFFBQVAsQ0FBVCxDQUFQO0FBQ0FILGFBQVMsQ0FBQyxJQUFELENBQVQ7QUFDRCxHQUhRLEVBR04sQ0FBQ0wsS0FBSyxDQUFDUSxRQUFQLENBSE0sQ0FBVDtBQUtBRix5REFBUyxDQUFDLFlBQU0sQ0FBRSxDQUFULEVBQVcsQ0FBQ0osSUFBRCxDQUFYLENBQVQ7O0FBRUEsTUFBTU8sSUFBSSxnQkFDUixxRUFBQyx5Q0FBRDtBQUFNLFNBQUssRUFBRTtBQUFFQyxXQUFLLEVBQUU7QUFBVCxLQUFiO0FBQUEsNEJBQ0UscUVBQUMseUNBQUQsQ0FBTSxJQUFOO0FBQW1CLFVBQUksZUFBRSxxRUFBQyw4REFBRDtBQUFjLGFBQUssRUFBRTtBQUFFQyxrQkFBUSxFQUFFO0FBQVo7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUF6QjtBQUFBO0FBQUEsT0FBZSxHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUlFLHFFQUFDLHlDQUFELENBQU0sSUFBTjtBQUFtQixVQUFJLGVBQUUscUVBQUMsd0VBQUQ7QUFBYSxhQUFLLEVBQUU7QUFBRUEsa0JBQVEsRUFBRTtBQUFaO0FBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FBekI7QUFBQTtBQUFBLE9BQWUsR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7O0FBV0Esc0JBQ0U7QUFBQSxjQUNHUCxNQUFNLGlCQUNMLHFFQUFDLE9BQUQ7QUFBUyxXQUFLLEVBQUVKLEtBQUssQ0FBQ1ksS0FBdEI7QUFBQSw2QkFDRSxxRUFBQyx3Q0FBRDtBQUNFLGFBQUssRUFBRTtBQUFFQyxnQkFBTSxFQUFFLE1BQVY7QUFBa0JDLGlCQUFPLEVBQUUsTUFBM0I7QUFBbUNDLG9CQUFVLEVBQUU7QUFBL0MsU0FEVDtBQUFBLGdDQUdFLHFFQUFDLHdDQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBWSxlQUFLLEVBQUU7QUFBRUQsbUJBQU8sRUFBRSxNQUFYO0FBQW1CRCxrQkFBTSxFQUFFO0FBQTNCLFdBQW5CO0FBQUEsaUNBQ0UscUVBQUMsTUFBRDtBQUFRLGVBQUcsRUFBQyx3QkFBWjtBQUFxQyxtQkFBTyxFQUFFO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGLGVBTUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFFLEVBQUUsRUFBVDtBQUFhLGVBQUssRUFBRTtBQUFFQyxtQkFBTyxFQUFFLE1BQVg7QUFBbUJDLHNCQUFVLEVBQUU7QUFBL0IsV0FBcEI7QUFBQSxrQ0FDRSxxRUFBQywwQ0FBRDtBQUNFLHVCQUFXLEVBQUMsY0FEZDtBQUVFLGlCQUFLLEVBQUU7QUFBRUMsMEJBQVksRUFBRSxDQUFoQjtBQUFtQkMsdUJBQVMsRUFBRTtBQUE5QjtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFLRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUU7QUFBRUQsMEJBQVksRUFBRSxDQUFoQjtBQUFtQkMsdUJBQVMsRUFBRTtBQUE5QixhQUZUO0FBR0UsZ0JBQUksZUFBRSxxRUFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUhSO0FBQUEsc0JBS0dmLElBQUksQ0FBQ2dCO0FBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTkYsZUFtQkUscUVBQUMsd0NBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFZLGVBQUssRUFBRTtBQUFFQyxxQkFBUyxFQUFFO0FBQWIsV0FBbkI7QUFBQSxrQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMsNkVBQUQ7QUFBYSxtQkFBSyxFQUFFO0FBQUVSLHdCQUFRLEVBQUU7QUFBWjtBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUhSO0FBSUUsaUJBQUssRUFBRTtBQUFFRCxtQkFBSyxFQUFFLEVBQVQ7QUFBYUcsb0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFPRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUMsUUFGUjtBQUdFLGdCQUFJLGVBQUUscUVBQUMscUVBQUQ7QUFBTSxtQkFBSyxFQUFFO0FBQUVGLHdCQUFRLEVBQUU7QUFBWjtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSFI7QUFJRSxpQkFBSyxFQUFFO0FBQUVELG1CQUFLLEVBQUUsRUFBVDtBQUFhRyxvQkFBTSxFQUFFO0FBQXJCO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFQRixlQWFFLHFFQUFDLDJDQUFEO0FBQ0UsZ0JBQUksRUFBQyxTQURQO0FBRUUsaUJBQUssRUFBQyxRQUZSO0FBR0UsZ0JBQUksZUFBRSxxRUFBQywwRUFBRDtBQUFVLG1CQUFLLEVBQUU7QUFBRUYsd0JBQVEsRUFBRTtBQUFaO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSFI7QUFJRSxpQkFBSyxFQUFFO0FBQUVELG1CQUFLLEVBQUUsRUFBVDtBQUFhRyxvQkFBTSxFQUFFO0FBQXJCO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFiRixlQW1CRSxxRUFBQyw2Q0FBRDtBQUFVLG1CQUFPLEVBQUVKLElBQW5CO0FBQXlCLHFCQUFTLEVBQUMsWUFBbkM7QUFBQSxtQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGtCQUFJLEVBQUMsU0FEUDtBQUVFLG1CQUFLLEVBQUMsUUFGUjtBQUdFLGtCQUFJLGVBQUUscUVBQUMsOEVBQUQ7QUFBZSxxQkFBSyxFQUFFO0FBQUVFLDBCQUFRLEVBQUU7QUFBWjtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUhSO0FBSUUsbUJBQUssRUFBRTtBQUFFRCxxQkFBSyxFQUFFLEVBQVQ7QUFBYUcsc0JBQU0sRUFBRTtBQUFyQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSixtQkFERjtBQXdERDs7R0EvRXVCaEIsTzs7S0FBQUEsTztBQWlGeEIsSUFBTXVCLE9BQU8sR0FBR0MsaUVBQU0sQ0FBQzdCLE1BQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSxxT0FDUztBQUFBLE1BQUdvQixLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNVLE9BQXJCO0FBQUEsQ0FEVCxDQUFiO01BQU1GLE87QUFjTixJQUFNRyxNQUFNLEdBQUdGLGlFQUFNLENBQUNHLDBDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsaURBQVo7TUFBTUQsTSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4xMGQ3YWQxNmVhNjk1Y2RiMTQyZS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29sLCBSb3csIExheW91dCwgSW5wdXQsIEJ1dHRvbiwgSW1hZ2UsIERyb3Bkb3duLCBNZW51IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBBdWRpb091dGxpbmVkLCBTZWFyY2hPdXRsaW5lZCwgVXNlck91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IENvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dFwiO1xyXG5pbXBvcnQgQWNjb3VudEljb24gZnJvbSBcIkAyZmQvYW50LWRlc2lnbi1pY29ucy9saWIvQWNjb3VudFwiO1xyXG5pbXBvcnQgQWNjb3VudENpcmNsZSBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9BY2NvdW50Q2lyY2xlXCI7XHJcbmltcG9ydCBDYXJ0IGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL0NhcnRcIjtcclxuaW1wb3J0IFZpZXdHcmlkIGZyb20gXCJAMmZkL2FudC1kZXNpZ24taWNvbnMvbGliL1ZpZXdHcmlkXCI7XHJcbmltcG9ydCBCZWxsT3V0bGluZSBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9CZWxsT3V0bGluZVwiO1xyXG5pbXBvcnQgeyBMYW5ndWFnZSB9IGZyb20gXCIuLi9sYW5ndWFnZXNcIjtcclxuXHJcbmNvbnN0IHsgSGVhZGVyLCBGb290ZXIsIFNpZGVyLCBDb250ZW50IH0gPSBMYXlvdXQ7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENIZWFkZXIoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIGNvbnN0IFtsYW5nLCBzZXRsYW5nXSA9IHVzZVN0YXRlPGFueT4obnVsbCk7XHJcbiAgY29uc3QgW2lzTG9hZCwgc2V0aXNMb2FkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldGxhbmcoTGFuZ3VhZ2Uoc3RhdGUubGFuZ3VhZ2UpKTtcclxuICAgIHNldGlzTG9hZCh0cnVlKTtcclxuICB9LCBbc3RhdGUubGFuZ3VhZ2VdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHt9LCBbbGFuZ10pO1xyXG5cclxuICBjb25zdCBtZW51ID0gKFxyXG4gICAgPE1lbnUgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fT5cclxuICAgICAgPE1lbnUuSXRlbSBrZXk9XCIxXCIgaWNvbj17PFVzZXJPdXRsaW5lZCBzdHlsZT17eyBmb250U2l6ZTogMjAgfX0gLz59PlxyXG4gICAgICAgIFByb2ZpbGVcclxuICAgICAgPC9NZW51Lkl0ZW0+XHJcbiAgICAgIDxNZW51Lkl0ZW0ga2V5PVwiMVwiIGljb249ezxBY2NvdW50SWNvbiBzdHlsZT17eyBmb250U2l6ZTogMjAgfX0gLz59PlxyXG4gICAgICAgIExvZ291dFxyXG4gICAgICA8L01lbnUuSXRlbT5cclxuICAgIDwvTWVudT5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge2lzTG9hZCAmJiAoXHJcbiAgICAgICAgPEhlYWRlcnMgdGhlbWU9e3N0YXRlLnRoZW1lfT5cclxuICAgICAgICAgIDxSb3dcclxuICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjEwMCVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPENvbCBtZD17Nn0gc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGhlaWdodDogXCIxMDAlXCIgfX0+XHJcbiAgICAgICAgICAgICAgPEltYWdlcyBzcmM9XCIvaW1hZ2VzL3Nob3BwaW5nXzEucG5nXCIgcHJldmlldz17ZmFsc2V9IC8+XHJcbiAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICA8Q29sIG1kPXsxMn0gc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIklOUFVUIFNFQVJDSFwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXJSYWRpdXM6IDAsIGJveFNoYWRvdzogXCIwcHggMHB4IDJweCAjMDAwMDAwXCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlclJhZGl1czogMCwgYm94U2hhZG93OiBcIjBweCAwcHggMnB4ICMwMDAwMDBcIiB9fVxyXG4gICAgICAgICAgICAgICAgaWNvbj17PFNlYXJjaE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtsYW5nLlNlYXJjaH1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgIDxDb2wgbWQ9ezZ9IHN0eWxlPXt7IHRleHRBbGlnbjogXCJlbmRcIiB9fT5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaGFwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8QmVsbE91dGxpbmUgc3R5bGU9e3sgZm9udFNpemU6IDMwIH19IC8+fVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwLCBoZWlnaHQ6IDUwIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBzaGFwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8Q2FydCBzdHlsZT17eyBmb250U2l6ZTogMzAgfX0gLz59XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTAsIGhlaWdodDogNTAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHNoYXBlPVwiY2lyY2xlXCJcclxuICAgICAgICAgICAgICAgIGljb249ezxWaWV3R3JpZCBzdHlsZT17eyBmb250U2l6ZTogMzAgfX0gLz59XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTAsIGhlaWdodDogNTAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxEcm9wZG93biBvdmVybGF5PXttZW51fSBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgc2hhcGU9XCJjaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8QWNjb3VudENpcmNsZSBzdHlsZT17eyBmb250U2l6ZTogMzAgfX0gLz59XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MCwgaGVpZ2h0OiA1MCB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgIDwvSGVhZGVycz5cclxuICAgICAgKX1cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IEhlYWRlcnMgPSBzdHlsZWQoSGVhZGVyKWBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgcGFkZGluZzogMHB4O1xyXG4gIGhlaWdodDogODBweDtcclxuICAvKiBkaXNwbGF5OiBmbGV4OyAqL1xyXG4gIHBvc2l0aW9uOiBzdGlja3k7XHJcbiAgdG9wOiAwcHg7XHJcbiAgei1pbmRleDogMztcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAxMHB4IDZweCAtNnB4ICM3Nzc7XHJcbiAgYm94LXNoYWRvdzogMCAxMHB4IDZweCAtNnB4ICM3Nzc7XHJcbmA7XHJcblxyXG5jb25zdCBJbWFnZXMgPSBzdHlsZWQoSW1hZ2UpYFxyXG4gIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwcHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAwcHg7XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=