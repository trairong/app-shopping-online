(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([[4],{

/***/ "./src/components/pages/home.tsx":
/*!***************************************!*\
  !*** ./src/components/pages/home.tsx ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../languages */ "./src/languages/index.ts");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\home.tsx",
    _s = $RefreshSig$();




 // import {
//     DesktopOutlined,
//     PieChartOutlined,
//     FileOutlined,
//     TeamOutlined,
//     SampleNextArrow,
//   } from "@ant-design/icons";

 // import { SET_LANGUAGE } from "../../languages";

function Home(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      isLoad = _useState[0],
      setisLoad = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      lang = _useState2[0],
      setlang = _useState2[1];

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    setlang(Object(_languages__WEBPACK_IMPORTED_MODULE_6__["Language"])(state.language));
    setisLoad(true);
  }, [state.language]);
  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {}, [lang]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: isLoad && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Contents, {
      theme: state.theme,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Carousel"], {
        autoplay: true,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              // maxWidth: 800,
              // minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              minWidth: 800,
              minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            preview: false,
            src: "./images/carousel3.png",
            style: {
              minWidth: 800,
              minHeight: 300,
              width: "100%",
              height: "auto",
              objectFit: "cover",
              margin: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: lang.RecommendedProducts
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Carousel"], {
        autoplay: true,
        children: [1, 2, 3, 4, 5, 6].map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 100,
                  columnNumber: 23
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 23
                }, _this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 106,
                  columnNumber: 23
                }, _this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 105,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 109,
                  columnNumber: 23
                }, _this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 112,
                  columnNumber: 23
                }, _this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 111,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                span: 4,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                  src: "./images/product1.png"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 115,
                  columnNumber: 23
                }, _this), " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 21
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 19
            }, _this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 97,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E22\u0E2D\u0E14\u0E19\u0E34\u0E22\u0E21"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 122,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        gutter: [8, 8],
        style: {
          padding: 16
        },
        children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
            span: 4,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title={'product'+item}
            , {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                src: "./images/product1.png"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 145,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  width: "100%",
                  padding: 5
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Buys, {
                  theme: state.theme,
                  children: "2500.00"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 147,
                  columnNumber: 23
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Rate"], {
                  allowHalf: true,
                  defaultValue: 3,
                  style: {
                    color: state.theme.primary
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 148,
                  columnNumber: 23
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 146,
                columnNumber: 21
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 19
            }, _this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 141,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 138,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        style: {
          justifyContent: "center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Paginations, {
          theme: state.theme,
          defaultCurrent: 10,
          total: 50
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
        theme: state.theme,
        children: "\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32\u0E42\u0E1B\u0E23\u0E42\u0E21\u0E0A\u0E31\u0E48\u0E19"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 11
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
        gutter: [16, 16],
        style: {
          padding: 16
        },
        children: [1, 2, 3, 4].map(function (item, index) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
            span: 24,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title="Default size card"
            // extra={<a href="#">More{item}</a>}
            , {
              style: {
                padding: 5,
                width: "100%"
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(ColImages, {
                  span: 12,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
                    src: "./images/product1.png",
                    style: {
                      width: "100%"
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 174,
                    columnNumber: 25
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 23
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                  span: 12,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E0A\u0E37\u0E48\u0E2D\u0E2A\u0E34\u0E19\u0E04\u0E49\u0E32"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E23\u0E32\u0E04\u0E32"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 181,
                    columnNumber: 25
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                    children: "\u0E23\u0E32\u0E22\u0E25\u0E30\u0E40\u0E2D\u0E35\u0E22\u0E14"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 182,
                    columnNumber: 25
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 179,
                  columnNumber: 23
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 172,
                columnNumber: 21
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 167,
              columnNumber: 19
            }, _this)
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 166,
            columnNumber: 17
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 163,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

_s(Home, "132B++9bCzg8cP1mM3GBIwnr/WA=");

_c = Home;
var ColImages = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"]).withConfig({
  displayName: "home__ColImages",
  componentId: "sc-1mqvku9-0"
})(["display:flex;justify-content:center;align-items:center;.ant-image{width:50%;}"]);
_c2 = ColImages;
var Contents = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "home__Contents",
  componentId: "sc-1mqvku9-1"
})(["height:100%;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c3 = Contents;
var Carousels = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Carousel"]).withConfig({
  displayName: "home__Carousels",
  componentId: "sc-1mqvku9-2"
})(["box-shadow:0px 0px 3px #546e7a;"]);
var Cards = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Card"]).withConfig({
  displayName: "home__Cards",
  componentId: "sc-1mqvku9-3"
})([".ant-card-body{padding:5px;}box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"]);
_c4 = Cards;
var Buys = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "home__Buys",
  componentId: "sc-1mqvku9-4"
})(["position:absolute;top:0px;right:0;background-color:", ";color:#fff;padding:5px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;"], function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
});
_c5 = Buys;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "home__TextHeader",
  componentId: "sc-1mqvku9-5"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
});
_c6 = TextHeader;
var Paginations = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Pagination"]).withConfig({
  displayName: "home__Paginations",
  componentId: "sc-1mqvku9-6"
})([".ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-pagination-item-active a{color:#fff !important;}"], function (_ref5) {
  var theme = _ref5.theme;
  return theme.primary;
});
_c7 = Paginations;

var _c, _c2, _c3, _c4, _c5, _c6, _c7;

$RefreshReg$(_c, "Home");
$RefreshReg$(_c2, "ColImages");
$RefreshReg$(_c3, "Contents");
$RefreshReg$(_c4, "Cards");
$RefreshReg$(_c5, "Buys");
$RefreshReg$(_c6, "TextHeader");
$RefreshReg$(_c7, "Paginations");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvaG9tZS50c3giXSwibmFtZXMiOlsiSG9tZSIsInVzZUNvbnRleHQiLCJDb250ZXh0Iiwic3RhdGUiLCJkaXNwYXRjaCIsInVzZVN0YXRlIiwiaXNMb2FkIiwic2V0aXNMb2FkIiwibGFuZyIsInNldGxhbmciLCJ1c2VFZmZlY3QiLCJMYW5ndWFnZSIsImxhbmd1YWdlIiwidGhlbWUiLCJ3aWR0aCIsImhlaWdodCIsIm9iamVjdEZpdCIsIm1hcmdpbiIsIm1pbldpZHRoIiwibWluSGVpZ2h0IiwiUmVjb21tZW5kZWRQcm9kdWN0cyIsIm1hcCIsIml0ZW0iLCJpbmRleCIsInBhZGRpbmciLCJjb2xvciIsInByaW1hcnkiLCJqdXN0aWZ5Q29udGVudCIsIkNvbEltYWdlcyIsInN0eWxlZCIsIkNvbCIsIkNvbnRlbnRzIiwiZGl2IiwiQ2Fyb3VzZWxzIiwiQ2Fyb3VzZWwiLCJDYXJkcyIsIkNhcmQiLCJCdXlzIiwiVGV4dEhlYWRlciIsIlBhZ2luYXRpb25zIiwiUGFnaW5hdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztDQUdBOztBQUllLFNBQVNBLElBQVQsT0FBdUM7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQSxvQkFDeEJDLHdEQUFVLENBQUNDLGdEQUFELENBRGM7QUFBQSxNQUM1Q0MsS0FENEMsZUFDNUNBLEtBRDRDO0FBQUEsTUFDckNDLFFBRHFDLGVBQ3JDQSxRQURxQzs7QUFBQSxrQkFFeEJDLHNEQUFRLENBQUMsS0FBRCxDQUZnQjtBQUFBLE1BRTdDQyxNQUY2QztBQUFBLE1BRXJDQyxTQUZxQzs7QUFBQSxtQkFHNUJGLHNEQUFRLEVBSG9CO0FBQUEsTUFHN0NHLElBSDZDO0FBQUEsTUFHdkNDLE9BSHVDOztBQUtwREMseURBQVMsQ0FBQyxZQUFNO0FBQ2RELFdBQU8sQ0FBQ0UsMkRBQVEsQ0FBQ1IsS0FBSyxDQUFDUyxRQUFQLENBQVQsQ0FBUDtBQUNBTCxhQUFTLENBQUMsSUFBRCxDQUFUO0FBQ0QsR0FIUSxFQUdOLENBQUNKLEtBQUssQ0FBQ1MsUUFBUCxDQUhNLENBQVQ7QUFJQUYseURBQVMsQ0FBQyxZQUFNLENBQUUsQ0FBVCxFQUFXLENBQUNGLElBQUQsQ0FBWCxDQUFUO0FBQ0Esc0JBQ0U7QUFBQSxjQUNHRixNQUFNLGlCQUNMLHFFQUFDLFFBQUQ7QUFBVSxXQUFLLEVBQUVILEtBQUssQ0FBQ1UsS0FBdkI7QUFBQSw4QkFDRSxxRUFBQyw2Q0FBRDtBQUFVLGdCQUFRLE1BQWxCO0FBQUEsZ0NBQ0UscUVBQUMsd0NBQUQ7QUFBQSxpQ0FDRSxxRUFBQywwQ0FBRDtBQUNFLG1CQUFPLEVBQUUsS0FEWDtBQUVFLGVBQUcsRUFBQyx3QkFGTjtBQUdFLGlCQUFLLEVBQUU7QUFDTDtBQUNBO0FBQ0FDLG1CQUFLLEVBQUUsTUFIRjtBQUlMQyxvQkFBTSxFQUFFLE1BSkg7QUFLTEMsdUJBQVMsRUFBRSxPQUxOO0FBTUxDLG9CQUFNLEVBQUU7QUFOSDtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBZUUscUVBQUMsd0NBQUQ7QUFBQSxpQ0FDRSxxRUFBQywwQ0FBRDtBQUNFLG1CQUFPLEVBQUUsS0FEWDtBQUVFLGVBQUcsRUFBQyx3QkFGTjtBQUdFLGlCQUFLLEVBQUU7QUFDTEMsc0JBQVEsRUFBRSxHQURMO0FBRUxDLHVCQUFTLEVBQUUsR0FGTjtBQUdMTCxtQkFBSyxFQUFFLE1BSEY7QUFJTEMsb0JBQU0sRUFBRSxNQUpIO0FBS0xDLHVCQUFTLEVBQUUsT0FMTjtBQU1MQyxvQkFBTSxFQUFFO0FBTkg7QUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFmRixlQTZCRSxxRUFBQyx3Q0FBRDtBQUFBLGlDQUNFLHFFQUFDLDBDQUFEO0FBQ0UsbUJBQU8sRUFBRSxLQURYO0FBRUUsZUFBRyxFQUFDLHdCQUZOO0FBR0UsaUJBQUssRUFBRTtBQUNMQyxzQkFBUSxFQUFFLEdBREw7QUFFTEMsdUJBQVMsRUFBRSxHQUZOO0FBR0xMLG1CQUFLLEVBQUUsTUFIRjtBQUlMQyxvQkFBTSxFQUFFLE1BSkg7QUFLTEMsdUJBQVMsRUFBRSxPQUxOO0FBTUxDLG9CQUFNLEVBQUU7QUFOSDtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQTZDRSxxRUFBQyxVQUFEO0FBQVksYUFBSyxFQUFFZCxLQUFLLENBQUNVLEtBQXpCO0FBQUEsa0JBQ0dMLElBQUksQ0FBQ1k7QUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBN0NGLGVBK0RFLHFFQUFDLDZDQUFEO0FBQVUsZ0JBQVEsTUFBbEI7QUFBQSxrQkFDRyxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCLENBQWhCLEVBQW1CQyxHQUFuQixDQUF1QixVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDdkMsOEJBQ0U7QUFBQSxtQ0FDRSxxRUFBQyx3Q0FBRDtBQUFBLHNDQUNFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsdUNBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRSxxRUFBQyx3Q0FBRDtBQUFLLG9CQUFJLEVBQUUsQ0FBWDtBQUFBLHdDQUNFLHFFQUFDLDBDQUFEO0FBQU8scUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsRUFDd0MsR0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGLGVBT0UscUVBQUMsd0NBQUQ7QUFBSyxvQkFBSSxFQUFFLENBQVg7QUFBQSx3Q0FDRSxxRUFBQywwQ0FBRDtBQUFPLHFCQUFHLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLEVBQ3dDLEdBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFQRixlQVVFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsd0NBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixFQUN3QyxHQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVkYsZUFhRSxxRUFBQyx3Q0FBRDtBQUFLLG9CQUFJLEVBQUUsQ0FBWDtBQUFBLHdDQUNFLHFFQUFDLDBDQUFEO0FBQU8scUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsRUFDd0MsR0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWJGLGVBZ0JFLHFFQUFDLHdDQUFEO0FBQUssb0JBQUksRUFBRSxDQUFYO0FBQUEsd0NBQ0UscUVBQUMsMENBQUQ7QUFBTyxxQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixFQUN3QyxHQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGFBQVVBLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQXdCRCxTQXpCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EvREYsZUEyRkUscUVBQUMsVUFBRDtBQUFZLGFBQUssRUFBRXBCLEtBQUssQ0FBQ1UsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EzRkYsZUEyR0UscUVBQUMsd0NBQUQ7QUFBSyxjQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFiO0FBQXFCLGFBQUssRUFBRTtBQUFFVyxpQkFBTyxFQUFFO0FBQVgsU0FBNUI7QUFBQSxrQkFDRyxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLENBQVYsRUFBYSxDQUFiLEVBQWdCLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLEVBQTRCLEVBQTVCLEVBQWdDLEVBQWhDLEVBQW9DLEVBQXBDLEVBQXdDSCxHQUF4QyxDQUE0QyxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDNUQsOEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxnQkFBSSxFQUFFLENBQVg7QUFBQSxtQ0FDRSxxRUFBQyxLQUFELENBQ0E7QUFEQTtBQUFBLHNDQUdFLHFFQUFDLDBDQUFEO0FBQU8sbUJBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEYsZUFJRTtBQUFLLHFCQUFLLEVBQUU7QUFBRVQsdUJBQUssRUFBRSxNQUFUO0FBQWlCVSx5QkFBTyxFQUFFO0FBQTFCLGlCQUFaO0FBQUEsd0NBQ0UscUVBQUMsSUFBRDtBQUFNLHVCQUFLLEVBQUVyQixLQUFLLENBQUNVLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUUscUVBQUMseUNBQUQ7QUFDRSwyQkFBUyxNQURYO0FBRUUsOEJBQVksRUFBRSxDQUZoQjtBQUdFLHVCQUFLLEVBQUU7QUFBRVkseUJBQUssRUFBRXRCLEtBQUssQ0FBQ1UsS0FBTixDQUFZYTtBQUFyQjtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGFBQW1CSCxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGO0FBaUJELFNBbEJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTNHRixlQWdJRSxxRUFBQyx3Q0FBRDtBQUFLLGFBQUssRUFBRTtBQUFFSSx3QkFBYyxFQUFFO0FBQWxCLFNBQVo7QUFBQSwrQkFDRSxxRUFBQyxXQUFEO0FBQWEsZUFBSyxFQUFFeEIsS0FBSyxDQUFDVSxLQUExQjtBQUFpQyx3QkFBYyxFQUFFLEVBQWpEO0FBQXFELGVBQUssRUFBRTtBQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWhJRixlQW1JRSxxRUFBQyxVQUFEO0FBQVksYUFBSyxFQUFFVixLQUFLLENBQUNVLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbklGLGVBb0lFLHFFQUFDLHdDQUFEO0FBQUssY0FBTSxFQUFFLENBQUMsRUFBRCxFQUFLLEVBQUwsQ0FBYjtBQUF1QixhQUFLLEVBQUU7QUFBRVcsaUJBQU8sRUFBRTtBQUFYLFNBQTlCO0FBQUEsa0JBQ0csQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxDQUFWLEVBQWFILEdBQWIsQ0FBaUIsVUFBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQ2pDLDhCQUNFLHFFQUFDLHdDQUFEO0FBQUssZ0JBQUksRUFBRSxFQUFYO0FBQUEsbUNBQ0UscUVBQUMsS0FBRCxDQUNFO0FBQ0E7QUFGRjtBQUdFLG1CQUFLLEVBQUU7QUFBRUMsdUJBQU8sRUFBRSxDQUFYO0FBQWNWLHFCQUFLLEVBQUU7QUFBckIsZUFIVDtBQUFBLHFDQUtFLHFFQUFDLHdDQUFEO0FBQUEsd0NBQ0UscUVBQUMsU0FBRDtBQUFXLHNCQUFJLEVBQUUsRUFBakI7QUFBQSx5Q0FDRSxxRUFBQywwQ0FBRDtBQUNFLHVCQUFHLEVBQUMsdUJBRE47QUFFRSx5QkFBSyxFQUFFO0FBQUVBLDJCQUFLLEVBQUU7QUFBVDtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBT0UscUVBQUMsd0NBQUQ7QUFBSyxzQkFBSSxFQUFFLEVBQVg7QUFBQSwwQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixhQUFvQlMsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERjtBQXVCRCxTQXhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkosbUJBREY7QUFzS0Q7O0dBaEx1QnZCLEk7O0tBQUFBLEk7QUFpTHhCLElBQU00QixTQUFTLEdBQUdDLGlFQUFNLENBQUNDLHdDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEscUZBQWY7TUFBTUYsUztBQVFOLElBQU1HLFFBQVEsR0FBR0YseURBQU0sQ0FBQ0csR0FBVjtBQUFBO0FBQUE7QUFBQSw0VEFpQlU7QUFBQSxNQUFHbkIsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDYSxPQUFyQjtBQUFBLENBakJWLENBQWQ7TUFBTUssUTtBQXFCTixJQUFNRSxTQUFTLEdBQUdKLGlFQUFNLENBQUNLLDZDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsdUNBQWY7QUFJQSxJQUFNQyxLQUFLLEdBQUdOLGlFQUFNLENBQUNPLHlDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsc09BQVg7TUFBTUQsSztBQVFOLElBQU1FLElBQUksR0FBR1IseURBQU0sQ0FBQ0csR0FBVjtBQUFBO0FBQUE7QUFBQSxxTUFJWTtBQUFBLE1BQUduQixLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNhLE9BQXJCO0FBQUEsQ0FKWixDQUFWO01BQU1XLEk7QUFXTixJQUFNQyxVQUFVLEdBQUdULHlEQUFNLENBQUNHLEdBQVY7QUFBQTtBQUFBO0FBQUEsb1lBSUw7QUFBQSxNQUFHbkIsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDYSxPQUFyQjtBQUFBLENBSkssQ0FBaEI7TUFBTVksVTtBQWdCTixJQUFNQyxXQUFXLEdBQUdWLGlFQUFNLENBQUNXLCtDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsMGZBRU87QUFBQSxNQUFHM0IsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDYSxPQUFyQjtBQUFBLENBRlAsQ0FBakI7TUFBTWEsVyIsImZpbGUiOiJzdGF0aWMvY2h1bmtzLzQuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXJkLCBDYXJvdXNlbCwgQ29sLCBJbWFnZSwgUGFnaW5hdGlvbiwgUmF0ZSwgUm93IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuLy8gaW1wb3J0IHtcclxuLy8gICAgIERlc2t0b3BPdXRsaW5lZCxcclxuLy8gICAgIFBpZUNoYXJ0T3V0bGluZWQsXHJcbi8vICAgICBGaWxlT3V0bGluZWQsXHJcbi8vICAgICBUZWFtT3V0bGluZWQsXHJcbi8vICAgICBTYW1wbGVOZXh0QXJyb3csXHJcbi8vICAgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IFNhbXBsZU5leHRBcnJvdyBmcm9tIFwiQDJmZC9hbnQtZGVzaWduLWljb25zL2xpYi9TaW1wbGVJY29uc1wiO1xyXG5pbXBvcnQgeyBMYW5ndWFnZSB9IGZyb20gXCIuLi8uLi9sYW5ndWFnZXNcIjtcclxuLy8gaW1wb3J0IHsgU0VUX0xBTkdVQUdFIH0gZnJvbSBcIi4uLy4uL2xhbmd1YWdlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKHt9OiBQcm9wcyk6IFJlYWN0RWxlbWVudCB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgY29uc3QgW2lzTG9hZCwgc2V0aXNMb2FkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbGFuZywgc2V0bGFuZ10gPSB1c2VTdGF0ZTxhbnk+KCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRsYW5nKExhbmd1YWdlKHN0YXRlLmxhbmd1YWdlKSk7XHJcbiAgICBzZXRpc0xvYWQodHJ1ZSk7XHJcbiAgfSwgW3N0YXRlLmxhbmd1YWdlXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHt9LCBbbGFuZ10pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7aXNMb2FkICYmIChcclxuICAgICAgICA8Q29udGVudHMgdGhlbWU9e3N0YXRlLnRoZW1lfT5cclxuICAgICAgICAgIDxDYXJvdXNlbCBhdXRvcGxheT5cclxuICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgc3JjPVwiLi9pbWFnZXMvY2Fyb3VzZWwzLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAvLyBtYXhXaWR0aDogODAwLFxyXG4gICAgICAgICAgICAgICAgICAvLyBtaW5IZWlnaHQ6IDMwMCxcclxuICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IFwiYXV0b1wiLFxyXG4gICAgICAgICAgICAgICAgICBvYmplY3RGaXQ6IFwiY292ZXJcIixcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+PC9JbWFnZT5cclxuICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICBwcmV2aWV3PXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHNyYz1cIi4vaW1hZ2VzL2Nhcm91c2VsMy5wbmdcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgbWluV2lkdGg6IDgwMCxcclxuICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0OiAzMDAsXHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBcImF1dG9cIixcclxuICAgICAgICAgICAgICAgICAgb2JqZWN0Rml0OiBcImNvdmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPjwvSW1hZ2U+XHJcbiAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgcHJldmlldz17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBzcmM9XCIuL2ltYWdlcy9jYXJvdXNlbDMucG5nXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIG1pbldpZHRoOiA4MDAsXHJcbiAgICAgICAgICAgICAgICAgIG1pbkhlaWdodDogMzAwLFxyXG4gICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogXCJhdXRvXCIsXHJcbiAgICAgICAgICAgICAgICAgIG9iamVjdEZpdDogXCJjb3ZlclwiLFxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW46IDAsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID48L0ltYWdlPlxyXG4gICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgIDwvQ2Fyb3VzZWw+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlxyXG4gICAgICAgICAgICB7bGFuZy5SZWNvbW1lbmRlZFByb2R1Y3RzfVxyXG4gICAgICAgICAgPC9UZXh0SGVhZGVyPlxyXG4gICAgICAgICAgey8qIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTAsXHJcbiAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAxNixcclxuICAgICAgICAgICAgZm9udFNpemU6IDIwLFxyXG4gICAgICAgICAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcInNvbGlkIDVweCBcIixcclxuICAgICAgICAgICAgYm9yZGVyQ29sb3I6IHN0YXRlLnRoZW1lLnByaW1hcnksXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIOC4quC4tOC4meC4hOC5ieC4suC5geC4meC4sOC4meC4s1xyXG4gICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgIDxDYXJvdXNlbCBhdXRvcGxheT5cclxuICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2XS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi4vaW1hZ2VzL3Byb2R1Y3QxLnBuZ1wiIC8+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2ltYWdlcy9wcm9kdWN0MS5wbmdcIiAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvQ2Fyb3VzZWw+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PuC4quC4tOC4meC4hOC5ieC4suC4ouC4reC4lOC4meC4tOC4ouC4oTwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIHsvKiA8ZGl2XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDUwLFxyXG4gICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICBwYWRkaW5nTGVmdDogMTYsXHJcbiAgICAgICAgICAgIGZvbnRTaXplOiAyMCxcclxuICAgICAgICAgICAgZm9udFdlaWdodDogXCJib2xkXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckJvdHRvbTogXCJzb2xpZCA1cHggXCIsXHJcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBzdGF0ZS50aGVtZS5wcmltYXJ5LFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICDguKrguLTguJnguITguYnguLLguKLguK3guJTguJnguLTguKLguKFcclxuICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICA8Um93IGd1dHRlcj17WzgsIDhdfSBzdHlsZT17eyBwYWRkaW5nOiAxNiB9fT5cclxuICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyXS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17NH0ga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkc1xyXG4gICAgICAgICAgICAgICAgICAvLyB0aXRsZT17J3Byb2R1Y3QnK2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiwgcGFkZGluZzogNSB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXlzIHRoZW1lPXtzdGF0ZS50aGVtZX0+MjUwMC4wMDwvQnV5cz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93SGFsZlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBzdGF0ZS50aGVtZS5wcmltYXJ5IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmRzPlxyXG4gICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgIDxSb3cgc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIgfX0+XHJcbiAgICAgICAgICAgIDxQYWdpbmF0aW9ucyB0aGVtZT17c3RhdGUudGhlbWV9IGRlZmF1bHRDdXJyZW50PXsxMH0gdG90YWw9ezUwfSAvPlxyXG4gICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PuC4quC4tOC4meC4hOC5ieC4suC5guC4m+C4o+C5guC4oeC4iuC4seC5iOC4mTwvVGV4dEhlYWRlcj5cclxuICAgICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gc3R5bGU9e3sgcGFkZGluZzogMTYgfX0+XHJcbiAgICAgICAgICAgIHtbMSwgMiwgMywgNF0ubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8Q29sIHNwYW49ezI0fSBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGl0bGU9XCJEZWZhdWx0IHNpemUgY2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZXh0cmE9ezxhIGhyZWY9XCIjXCI+TW9yZXtpdGVtfTwvYT59XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgcGFkZGluZzogNSwgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbEltYWdlcyBzcGFuPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz1cIi4vaW1hZ2VzL3Byb2R1Y3QxLnBuZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbEltYWdlcz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgc3Bhbj17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD7guIrguLfguYjguK3guKrguLTguJnguITguYnguLI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPuC4o+C4suC4hOC4sjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+4Lij4Liy4Lii4Lil4Liw4LmA4Lit4Li14Lii4LiUPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZHM+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgIDwvQ29udGVudHM+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbmNvbnN0IENvbEltYWdlcyA9IHN0eWxlZChDb2wpYFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAuYW50LWltYWdlIHtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBDb250ZW50cyA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgfVxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNlY2VjO1xyXG4gIH1cclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IENhcm91c2VscyA9IHN0eWxlZChDYXJvdXNlbClgXHJcbiAgYm94LXNoYWRvdzogMHB4IDBweCAzcHggIzU0NmU3YTtcclxuYDtcclxuXHJcbmNvbnN0IENhcmRzID0gc3R5bGVkKENhcmQpYFxyXG4gIC5hbnQtY2FyZC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICB9XHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG5jb25zdCBCdXlzID0gc3R5bGVkLmRpdmBcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAwcHg7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBjb2xvcjogI2ZmZjtcclxuICBwYWRkaW5nOiA1cHg7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAtbW96LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gIGJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG5gO1xyXG5jb25zdCBUZXh0SGVhZGVyID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBjb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmctbGVmdDogMTZweDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuICBib3gtc2hhZG93OiAwIDIuOHB4IDIuMnB4IHJnYigwIDAgMCAvIDMlKSwgMCA2LjdweCA1LjNweCByZ2IoMCAwIDAgLyA1JSksXHJcbiAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7XHJcbmA7XHJcblxyXG5jb25zdCBQYWdpbmF0aW9ucyA9IHN0eWxlZChQYWdpbmF0aW9uKWBcclxuICAuYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXHJcbiAgLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwNTg1ZTcgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlN2ViZWUgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6Zmlyc3QtY2hpbGQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSBhIHtcclxuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5gO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9