(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([[5],{

/***/ "./src/components/pages/list-product.tsx":
/*!***********************************************!*\
  !*** ./src/components/pages/list-product.tsx ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ListProduct; });
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\list-product.tsx",
    _this = undefined,
    _s = $RefreshSig$();





var columns = [{
  title: "No.",
  dataIndex: "no" // width: 150,

}, {
  title: "ชื่อสินค้า",
  dataIndex: "productName" // width: 150,

}, {
  title: "ราคา",
  dataIndex: "ProductPrice"
}, {
  title: "จำนวน",
  dataIndex: "ProductQTY"
}, {
  title: "ราคารวม",
  dataIndex: "ProductTotal"
}, {
  title: "Action",
  dataIndex: "action",
  align: "center",
  width: 150,
  render: function render(text) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Row"], {
        gutter: 16,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Col"], {
          span: 12,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
            type: "primary",
            children: "EDIT"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Col"], {
          span: 12,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_4__["Button"], {
            type: "primary",
            children: "DEL"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, _this)
    }, void 0, false);
  }
}];
function ListProduct(_ref) {
  _s();

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var data = [];

  for (var i = 0; i < 100; i++) {
    data.push({
      key: i + 1,
      no: i + 1,
      productName: "product",
      ProductPrice: "1500.00",
      ProductQTY: 3,
      ProductTotal: "4500.00" // Active: ['delete','edit'],

    });
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(Tables, {
      theme: state.theme,
      dataSource: data,
      columns: columns // scroll={{ y: "calc(100vh - 240px)" }}

    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(ListProduct, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = ListProduct;
var Tables = Object(styled_components__WEBPACK_IMPORTED_MODULE_3__["default"])(antd__WEBPACK_IMPORTED_MODULE_4__["Table"]).withConfig({
  displayName: "list-product__Tables",
  componentId: "sc-112xzpm-0"
})(["padding:16px;.ant-table-thead th{border-radius:0px !important;color:#fff;background:", "!important;border-bottom:solid 0px #cdd8ed !important;position:sticky;top:0px;z-index:2;}.ant-pagination-item-active a{color:#fff !important;}.ant-table-tbody > tr > td{border-bottom:solid 1px ", " !important;border-radius:0px !important;}.ant-table-tbody > tr:hover > td{background:", " !important;color:#fff;border-top:solid 1px ", " !important;border-bottom:solid 1px ", " !important;}.ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-table-content{height:calc(100vh - 160px);overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", "!important;}}-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
}, function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
}, function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
}, function (_ref5) {
  var theme = _ref5.theme;
  return theme.toolbar;
}, function (_ref6) {
  var theme = _ref6.theme;
  return theme.toolbar;
}, function (_ref7) {
  var theme = _ref7.theme;
  return theme.primary;
}, function (_ref8) {
  var theme = _ref8.theme;
  return theme.primary;
});
_c2 = Tables;
var Scrolls = styled_components__WEBPACK_IMPORTED_MODULE_3__["default"].div.withConfig({
  displayName: "list-product__Scrolls",
  componentId: "sc-112xzpm-1"
})(["height:calc(100vh - 143px);padding:10px;margin-top:-10px;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:5px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:5px;background-color:", ";}"], function (_ref9) {
  var theme = _ref9.theme;
  return theme.primary;
});

var _c, _c2;

$RefreshReg$(_c, "ListProduct");
$RefreshReg$(_c2, "Tables");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvbGlzdC1wcm9kdWN0LnRzeCJdLCJuYW1lcyI6WyJjb2x1bW5zIiwidGl0bGUiLCJkYXRhSW5kZXgiLCJhbGlnbiIsIndpZHRoIiwicmVuZGVyIiwidGV4dCIsIkxpc3RQcm9kdWN0IiwidXNlQ29udGV4dCIsIkNvbnRleHQiLCJzdGF0ZSIsImRpc3BhdGNoIiwiZGF0YSIsImkiLCJwdXNoIiwia2V5Iiwibm8iLCJwcm9kdWN0TmFtZSIsIlByb2R1Y3RQcmljZSIsIlByb2R1Y3RRVFkiLCJQcm9kdWN0VG90YWwiLCJ0aGVtZSIsIlRhYmxlcyIsInN0eWxlZCIsIlRhYmxlIiwicHJpbWFyeSIsInRvb2xiYXIiLCJTY3JvbGxzIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFHQSxJQUFNQSxPQUFPLEdBQUcsQ0FDZDtBQUNFQyxPQUFLLEVBQUUsS0FEVDtBQUVFQyxXQUFTLEVBQUUsSUFGYixDQUdFOztBQUhGLENBRGMsRUFNZDtBQUNFRCxPQUFLLEVBQUUsWUFEVDtBQUVFQyxXQUFTLEVBQUUsYUFGYixDQUdFOztBQUhGLENBTmMsRUFXZDtBQUNFRCxPQUFLLEVBQUUsTUFEVDtBQUVFQyxXQUFTLEVBQUU7QUFGYixDQVhjLEVBZWQ7QUFDRUQsT0FBSyxFQUFFLE9BRFQ7QUFFRUMsV0FBUyxFQUFFO0FBRmIsQ0FmYyxFQW1CZDtBQUNFRCxPQUFLLEVBQUUsU0FEVDtBQUVFQyxXQUFTLEVBQUU7QUFGYixDQW5CYyxFQXVCZDtBQUNFRCxPQUFLLEVBQUUsUUFEVDtBQUVFQyxXQUFTLEVBQUUsUUFGYjtBQUdFQyxPQUFLLEVBQUUsUUFIVDtBQUlFQyxPQUFLLEVBQUUsR0FKVDtBQUtFQyxRQUFNLEVBQUUsZ0JBQUNDLElBQUQ7QUFBQSx3QkFDTjtBQUFBLDZCQUNFLHFFQUFDLHdDQUFEO0FBQUssY0FBTSxFQUFFLEVBQWI7QUFBQSxnQ0FDRSxxRUFBQyx3Q0FBRDtBQUFLLGNBQUksRUFBRSxFQUFYO0FBQUEsaUNBQ0UscUVBQUMsMkNBQUQ7QUFBUSxnQkFBSSxFQUFDLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBSUUscUVBQUMsd0NBQUQ7QUFBSyxjQUFJLEVBQUUsRUFBWDtBQUFBLGlDQUNFLHFFQUFDLDJDQUFEO0FBQVEsZ0JBQUksRUFBQyxTQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixxQkFETTtBQUFBO0FBTFYsQ0F2QmMsQ0FBaEI7QUEyQ2UsU0FBU0MsV0FBVCxPQUE4QztBQUFBOztBQUFBOztBQUFBLG9CQUMvQkMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FEcUI7QUFBQSxNQUNuREMsS0FEbUQsZUFDbkRBLEtBRG1EO0FBQUEsTUFDNUNDLFFBRDRDLGVBQzVDQSxRQUQ0Qzs7QUFHM0QsTUFBTUMsSUFBSSxHQUFHLEVBQWI7O0FBQ0EsT0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEdBQXBCLEVBQXlCQSxDQUFDLEVBQTFCLEVBQThCO0FBQzVCRCxRQUFJLENBQUNFLElBQUwsQ0FBVTtBQUNSQyxTQUFHLEVBQUVGLENBQUMsR0FBRyxDQUREO0FBRVJHLFFBQUUsRUFBRUgsQ0FBQyxHQUFHLENBRkE7QUFHUkksaUJBQVcsRUFBRSxTQUhMO0FBSVJDLGtCQUFZLEVBQUUsU0FKTjtBQUtSQyxnQkFBVSxFQUFFLENBTEo7QUFNUkMsa0JBQVksRUFBRSxTQU5OLENBUVI7O0FBUlEsS0FBVjtBQVVEOztBQUVELHNCQUNFO0FBQUEsMkJBRUUscUVBQUMsTUFBRDtBQUNFLFdBQUssRUFBRVYsS0FBSyxDQUFDVyxLQURmO0FBRUUsZ0JBQVUsRUFBRVQsSUFGZDtBQUdFLGFBQU8sRUFBRVosT0FIWCxDQUlFOztBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRixtQkFERjtBQVlEOztHQTdCdUJPLFc7O0tBQUFBLFc7QUE4QnhCLElBQU1lLE1BQU0sR0FBR0MsaUVBQU0sQ0FBQ0MsMENBQUQsQ0FBVDtBQUFBO0FBQUE7QUFBQSx3Z0RBTU07QUFBQSxNQUFHSCxLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNJLE9BQXJCO0FBQUEsQ0FOTixFQWtCbUI7QUFBQSxNQUFHSixLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNJLE9BQXJCO0FBQUEsQ0FsQm5CLEVBdUJNO0FBQUEsTUFBR0osS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDSSxPQUFyQjtBQUFBLENBdkJOLEVBeUJnQjtBQUFBLE1BQUdKLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0ssT0FBckI7QUFBQSxDQXpCaEIsRUEwQm1CO0FBQUEsTUFBR0wsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDSyxPQUFyQjtBQUFBLENBMUJuQixFQTZCWTtBQUFBLE1BQUdMLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0ksT0FBckI7QUFBQSxDQTdCWixFQWtFYztBQUFBLE1BQUdKLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0ksT0FBckI7QUFBQSxDQWxFZCxDQUFaO01BQU1ILE07QUE2RU4sSUFBTUssT0FBTyxHQUFHSix5REFBTSxDQUFDSyxHQUFWO0FBQUE7QUFBQTtBQUFBLHlXQW1CVztBQUFBLE1BQUdQLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ0ksT0FBckI7QUFBQSxDQW5CWCxDQUFiIiwiZmlsZSI6InN0YXRpYy9jaHVua3MvNS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgVGFibGUsIElucHV0LCBCdXR0b24sIFBvcGNvbmZpcm0sIEZvcm0sIFJvdywgQ29sIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRm9ybUluc3RhbmNlIH0gZnJvbSBcImFudGQvbGliL2Zvcm1cIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0XCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuY29uc3QgY29sdW1ucyA9IFtcclxuICB7XHJcbiAgICB0aXRsZTogXCJOby5cIixcclxuICAgIGRhdGFJbmRleDogXCJub1wiLFxyXG4gICAgLy8gd2lkdGg6IDE1MCxcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiBcIuC4iuC4t+C5iOC4reC4quC4tOC4meC4hOC5ieC4slwiLFxyXG4gICAgZGF0YUluZGV4OiBcInByb2R1Y3ROYW1lXCIsXHJcbiAgICAvLyB3aWR0aDogMTUwLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6IFwi4Lij4Liy4LiE4LiyXCIsXHJcbiAgICBkYXRhSW5kZXg6IFwiUHJvZHVjdFByaWNlXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICB0aXRsZTogXCLguIjguLPguJnguKfguJlcIixcclxuICAgIGRhdGFJbmRleDogXCJQcm9kdWN0UVRZXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICB0aXRsZTogXCLguKPguLLguITguLLguKPguKfguKFcIixcclxuICAgIGRhdGFJbmRleDogXCJQcm9kdWN0VG90YWxcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiBcIkFjdGlvblwiLFxyXG4gICAgZGF0YUluZGV4OiBcImFjdGlvblwiLFxyXG4gICAgYWxpZ246IFwiY2VudGVyXCIsXHJcbiAgICB3aWR0aDogMTUwLFxyXG4gICAgcmVuZGVyOiAodGV4dDogc3RyaW5nKSA9PiAoXHJcbiAgICAgIDw+XHJcbiAgICAgICAgPFJvdyBndXR0ZXI9ezE2fT5cclxuICAgICAgICAgIDxDb2wgc3Bhbj17MTJ9PlxyXG4gICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCI+RURJVDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICA8Q29sIHNwYW49ezEyfT5cclxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiPkRFTDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPC9Sb3c+XHJcbiAgICAgIDwvPlxyXG4gICAgKSxcclxuICB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGlzdFByb2R1Y3Qoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlLCBkaXNwYXRjaCB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuXHJcbiAgY29uc3QgZGF0YSA9IFtdO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTAwOyBpKyspIHtcclxuICAgIGRhdGEucHVzaCh7XHJcbiAgICAgIGtleTogaSArIDEsXHJcbiAgICAgIG5vOiBpICsgMSxcclxuICAgICAgcHJvZHVjdE5hbWU6IFwicHJvZHVjdFwiLFxyXG4gICAgICBQcm9kdWN0UHJpY2U6IFwiMTUwMC4wMFwiLFxyXG4gICAgICBQcm9kdWN0UVRZOiAzLFxyXG4gICAgICBQcm9kdWN0VG90YWw6IFwiNDUwMC4wMFwiLFxyXG5cclxuICAgICAgLy8gQWN0aXZlOiBbJ2RlbGV0ZScsJ2VkaXQnXSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHsvKiA8U2Nyb2xscyB0aGVtZT17c3RhdGUudGhlbWV9PiAqL31cclxuICAgICAgPFRhYmxlc1xyXG4gICAgICAgIHRoZW1lPXtzdGF0ZS50aGVtZX1cclxuICAgICAgICBkYXRhU291cmNlPXtkYXRhfVxyXG4gICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgLy8gc2Nyb2xsPXt7IHk6IFwiY2FsYygxMDB2aCAtIDI0MHB4KVwiIH19XHJcbiAgICAgID48L1RhYmxlcz5cclxuICAgICAgey8qIDwvU2Nyb2xscz4gKi99XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbmNvbnN0IFRhYmxlcyA9IHN0eWxlZChUYWJsZSlgXHJcbiAgcGFkZGluZzogMTZweDtcclxuICAvKiBoZWlnaHQ6IDEwMCU7ICovXHJcbiAgLmFudC10YWJsZS10aGVhZCB0aCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAwcHggI2NkZDhlZCAhaW1wb3J0YW50O1xyXG4gICAgcG9zaXRpb246IHN0aWNreTtcclxuICAgIHRvcDogMHB4O1xyXG4gICAgei1pbmRleDogMjtcclxuICB9XHJcblxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSBhIHtcclxuICAgIGNvbG9yOiAjZmZmICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAuYW50LXRhYmxlLXRib2R5ID4gdHIgPiB0ZCB7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAuYW50LXRhYmxlLXRib2R5ID4gdHI6aG92ZXIgPiB0ZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9ICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJvcmRlci10b3A6IHNvbGlkIDFweCAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnRvb2xiYXJ9ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS50b29sYmFyfSAhaW1wb3J0YW50O1xyXG4gIH1cclxuICAuYW50LXBhZ2luYXRpb24taXRlbS1hY3RpdmUge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fSFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6YWZ0ZXIsXHJcbiAgLmFudC1wYWdpbmF0aW9uLWp1bXAtcHJldjphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1uZXh0OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwNTg1ZTcgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlN2ViZWUgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWxpbms6Zmlyc3QtY2hpbGQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbiAgfVxyXG4gIC5hbnQtdGFibGUtY29udGVudCB7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxNjBweCk7XHJcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICAgIHdpZHRoOiAxNXB4O1xyXG4gICAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgICB9XHJcbiAgICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gICAgICBib3gtc2hhZG93OiAwcHggMHB4IDVweCAjMDAwMDAwO1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNlY2VjO1xyXG4gICAgfVxyXG5cclxuICAgIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUucHJpbWFyeX0haW1wb3J0YW50O1xyXG4gICAgfVxyXG4gIH1cclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcbiAgLW1vei1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG5cclxuICBib3gtc2hhZG93OiAwIDIuOHB4IDIuMnB4IHJnYigwIDAgMCAvIDMlKSwgMCA2LjdweCA1LjNweCByZ2IoMCAwIDAgLyA1JSksXHJcbiAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgIDAgNDEuOHB4IDMzLjRweCByZ2IoMCAwIDAgLyAwJSksIDAgMTAwcHggODBweCByZ2IoMCAwIDAgLyAwJSk7XHJcbmA7XHJcblxyXG5jb25zdCBTY3JvbGxzID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAxNDNweCk7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBtYXJnaW4tdG9wOiAtMTBweDtcclxuICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgIHdpZHRoOiAxNXB4O1xyXG4gICAgaGVpZ2h0OiAxNXB4O1xyXG4gIH1cclxuICA6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogaW5zZXQgMCAwIDZweCByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMHB4IDVweCAjMDAwMDAwO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VjZWNlYztcclxuICB9XHJcblxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5wcmltYXJ5fTtcclxuICB9XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=