(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([[1],{

/***/ "./src/components/pages/setting.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/setting.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Setting; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var _utils_local_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils/local-storage */ "./src/utils/local-storage.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../constants */ "./src/constants/index.ts");
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ant-design/icons */ "./node_modules/@ant-design/icons/es/index.js");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\setting.tsx",
    _s = $RefreshSig$();








var primarys = [{
  colorName: "#7f0000"
}, {
  colorName: "#b71c1c"
}, {
  colorName: "#880e4f"
}, {
  colorName: "#560027"
}, {
  colorName: "#311b92"
}, {
  colorName: "#1a237e"
}, {
  colorName: "#0d47a1"
}, {
  colorName: "#002f6c"
}, {
  colorName: "#263238"
}, {
  colorName: "#004d40"
}, {
  colorName: "#00363a"
}, {
  colorName: "#006064"
}, {
  colorName: "#4a148c"
}, {
  colorName: "#38006b"
}, {
  colorName: "#212121"
}, {
  colorName: "#003300"
}, {
  colorName: "#003d00"
}, {
  colorName: "#524c00"
}, {
  colorName: "#1c313a"
}, {
  colorName: "#29434e"
}];
function Setting(_ref) {
  _s();

  var _this = this;

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_2__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_3__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  var setTheme = function setTheme(color) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].THEME, JSON.stringify(color));

    console.log("Theme => ", color);
    dispatch({
      type: "SET_PRIMARY",
      payload: {
        primary: color
      }
    });
  };

  var setLanguage = function setLanguage(lang) {
    Object(_utils_local_storage__WEBPACK_IMPORTED_MODULE_6__["_setStorage"])(_constants__WEBPACK_IMPORTED_MODULE_7__["KEY_STORAGE"].LANG, JSON.stringify(lang));

    dispatch({
      type: "SET_LANGUAGE",
      payload: {
        language: lang
      }
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING PRIMARY"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: primarys.map(function (row, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
          span: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
            type: "primary",
            style: {
              width: "100%",
              backgroundColor: row.colorName,
              borderColor: row.colorName
            },
            onClick: function onClick() {
              return setTheme(row.colorName);
            },
            children: row.colorName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 15
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 13
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TextHeader, {
      theme: state.theme,
      children: "SETTING LANGUAGE"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Row"], {
      gutter: [16, 16],
      style: {
        padding: 10
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("EN");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, this), "ENGLISH"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Col"], {
        span: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_5__["Button"], {
          type: "primary",
          style: {
            width: "100%"
          },
          onClick: function onClick() {
            return setLanguage("TH");
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ant_design_icons__WEBPACK_IMPORTED_MODULE_8__["GlobalOutlined"], {
            style: {
              fontSize: 20
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 13
          }, this), "THAI"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Setting, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Setting;
var TextHeader = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "setting__TextHeader",
  componentId: "sc-11vdu53-0"
})(["height:50px;width:100%;display:flex;color:", ";align-items:center;padding-left:16px;font-size:20px;font-weight:bold;-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c2 = TextHeader;

var _c, _c2;

$RefreshReg$(_c, "Setting");
$RefreshReg$(_c2, "TextHeader");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./src/utils/local-storage.ts":
/*!************************************!*\
  !*** ./src/utils/local-storage.ts ***!
  \************************************/
/*! exports provided: _setStorage, _getStorage, _deleteStorage, _deleteAllStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_setStorage", function() { return _setStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_getStorage", function() { return _getStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteStorage", function() { return _deleteStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_deleteAllStorage", function() { return _deleteAllStorage; });
var _setStorage = function _setStorage(key, body) {
  localStorage.setItem(key, body);
};
var _getStorage = function _getStorage(key) {
  var boby = localStorage.getItem(key);

  try {
    return JSON.parse(boby);
  } catch (error) {
    return boby;
  }
};
var _deleteStorage = function _deleteStorage(key) {
  localStorage.removeItem(key);
};
var _deleteAllStorage = function _deleteAllStorage() {
  localStorage.clear();
};

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvc2V0dGluZy50c3giLCJ3ZWJwYWNrOi8vX05fRS8uL3NyYy91dGlscy9sb2NhbC1zdG9yYWdlLnRzIl0sIm5hbWVzIjpbInByaW1hcnlzIiwiY29sb3JOYW1lIiwiU2V0dGluZyIsInVzZUNvbnRleHQiLCJDb250ZXh0Iiwic3RhdGUiLCJkaXNwYXRjaCIsInNldFRoZW1lIiwiY29sb3IiLCJfc2V0U3RvcmFnZSIsIktFWV9TVE9SQUdFIiwiVEhFTUUiLCJKU09OIiwic3RyaW5naWZ5IiwiY29uc29sZSIsImxvZyIsInR5cGUiLCJwYXlsb2FkIiwicHJpbWFyeSIsInNldExhbmd1YWdlIiwibGFuZyIsIkxBTkciLCJsYW5ndWFnZSIsInRoZW1lIiwicGFkZGluZyIsIm1hcCIsInJvdyIsImluZGV4Iiwid2lkdGgiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXJDb2xvciIsImZvbnRTaXplIiwiVGV4dEhlYWRlciIsInN0eWxlZCIsImRpdiIsImtleSIsImJvZHkiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiX2dldFN0b3JhZ2UiLCJib2J5IiwiZ2V0SXRlbSIsInBhcnNlIiwiZXJyb3IiLCJfZGVsZXRlU3RvcmFnZSIsInJlbW92ZUl0ZW0iLCJfZGVsZXRlQWxsU3RvcmFnZSIsImNsZWFyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLElBQU1BLFFBQVEsR0FBRyxDQUNmO0FBQUVDLFdBQVMsRUFBRTtBQUFiLENBRGUsRUFFZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUZlLEVBR2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FIZSxFQUlmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBSmUsRUFLZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQUxlLEVBTWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FOZSxFQU9mO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBUGUsRUFRZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVJlLEVBU2Y7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FUZSxFQVVmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBVmUsRUFXZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQVhlLEVBWWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FaZSxFQWFmO0FBQUVBLFdBQVMsRUFBRTtBQUFiLENBYmUsRUFjZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWRlLEVBZWY7QUFBRUEsV0FBUyxFQUFFO0FBQWIsQ0FmZSxFQWdCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWhCZSxFQWlCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWpCZSxFQWtCZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQWxCZSxFQW1CZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQW5CZSxFQW9CZjtBQUFFQSxXQUFTLEVBQUU7QUFBYixDQXBCZSxDQUFqQjtBQXVCZSxTQUFTQyxPQUFULE9BQTBDO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsb0JBQzNCQyx3REFBVSxDQUFDQyxnREFBRCxDQURpQjtBQUFBLE1BQy9DQyxLQUQrQyxlQUMvQ0EsS0FEK0M7QUFBQSxNQUN4Q0MsUUFEd0MsZUFDeENBLFFBRHdDOztBQUV2RCxNQUFNQyxRQUFRLEdBQUcsU0FBWEEsUUFBVyxDQUFDQyxLQUFELEVBQVc7QUFDMUJDLDRFQUFXLENBQUNDLHNEQUFXLENBQUNDLEtBQWIsRUFBb0JDLElBQUksQ0FBQ0MsU0FBTCxDQUFlTCxLQUFmLENBQXBCLENBQVg7O0FBQ0FNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBeUJQLEtBQXpCO0FBRUFGLFlBQVEsQ0FBQztBQUNQVSxVQUFJLEVBQUUsYUFEQztBQUVQQyxhQUFPLEVBQUU7QUFDUEMsZUFBTyxFQUFFVjtBQURGO0FBRkYsS0FBRCxDQUFSO0FBTUQsR0FWRDs7QUFXQSxNQUFNVyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDQyxJQUFELEVBQVU7QUFDNUJYLDRFQUFXLENBQUNDLHNEQUFXLENBQUNXLElBQWIsRUFBbUJULElBQUksQ0FBQ0MsU0FBTCxDQUFlTyxJQUFmLENBQW5CLENBQVg7O0FBRUFkLFlBQVEsQ0FBQztBQUNQVSxVQUFJLEVBQUUsY0FEQztBQUVQQyxhQUFPLEVBQUU7QUFDUEssZ0JBQVEsRUFBRUY7QUFESDtBQUZGLEtBQUQsQ0FBUjtBQU1ELEdBVEQ7O0FBVUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxVQUFEO0FBQVksV0FBSyxFQUFFZixLQUFLLENBQUNrQixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLGdCQUNHeEIsUUFBUSxDQUFDeUIsR0FBVCxDQUFhLFVBQUNDLEdBQUQsRUFBTUMsS0FBTixFQUFnQjtBQUM1Qiw0QkFDRSxxRUFBQyx3Q0FBRDtBQUFpQixjQUFJLEVBQUUsQ0FBdkI7QUFBQSxpQ0FDRSxxRUFBQywyQ0FBRDtBQUNFLGdCQUFJLEVBQUMsU0FEUDtBQUVFLGlCQUFLLEVBQUU7QUFDTEMsbUJBQUssRUFBRSxNQURGO0FBRUxDLDZCQUFlLEVBQUVILEdBQUcsQ0FBQ3pCLFNBRmhCO0FBR0w2Qix5QkFBVyxFQUFFSixHQUFHLENBQUN6QjtBQUhaLGFBRlQ7QUFPRSxtQkFBTyxFQUFFO0FBQUEscUJBQU1NLFFBQVEsQ0FBQ21CLEdBQUcsQ0FBQ3pCLFNBQUwsQ0FBZDtBQUFBLGFBUFg7QUFBQSxzQkFTR3lCLEdBQUcsQ0FBQ3pCO0FBVFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFdBQVUwQixLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFlRCxPQWhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRixlQXFCRSxxRUFBQyxVQUFEO0FBQVksV0FBSyxFQUFFdEIsS0FBSyxDQUFDa0IsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyQkYsZUFzQkUscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUFiO0FBQXVCLFdBQUssRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUE5QjtBQUFBLDhCQUNFLHFFQUFDLHdDQUFEO0FBQUssWUFBSSxFQUFFLENBQVg7QUFBQSwrQkFDRSxxRUFBQywyQ0FBRDtBQUNFLGNBQUksRUFBQyxTQURQO0FBRUUsZUFBSyxFQUFFO0FBQUVJLGlCQUFLLEVBQUU7QUFBVCxXQUZUO0FBR0UsaUJBQU8sRUFBRTtBQUFBLG1CQUFNVCxXQUFXLENBQUMsSUFBRCxDQUFqQjtBQUFBLFdBSFg7QUFBQSxrQ0FLRSxxRUFBQyxnRUFBRDtBQUNFLGlCQUFLLEVBQUU7QUFBRVksc0JBQVEsRUFBRTtBQUFaO0FBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFhRSxxRUFBQyx3Q0FBRDtBQUFLLFlBQUksRUFBRSxDQUFYO0FBQUEsK0JBQ0UscUVBQUMsMkNBQUQ7QUFDRSxjQUFJLEVBQUMsU0FEUDtBQUVFLGVBQUssRUFBRTtBQUFFSCxpQkFBSyxFQUFFO0FBQVQsV0FGVDtBQUdFLGlCQUFPLEVBQUU7QUFBQSxtQkFBTVQsV0FBVyxDQUFDLElBQUQsQ0FBakI7QUFBQSxXQUhYO0FBQUEsa0NBS0UscUVBQUMsZ0VBQUQ7QUFDRSxpQkFBSyxFQUFFO0FBQUVZLHNCQUFRLEVBQUU7QUFBWjtBQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXRCRjtBQUFBLGtCQURGO0FBbUREOztHQTFFdUI3QixPOztLQUFBQSxPO0FBNEV4QixJQUFNOEIsVUFBVSxHQUFHQyx5REFBTSxDQUFDQyxHQUFWO0FBQUE7QUFBQTtBQUFBLG9ZQUlMO0FBQUEsTUFBR1gsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDTCxPQUFyQjtBQUFBLENBSkssQ0FBaEI7TUFBTWMsVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3R047QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLElBQU12QixXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDMEIsR0FBRCxFQUFjQyxJQUFkLEVBQStCO0FBQ3REQyxjQUFZLENBQUNDLE9BQWIsQ0FBcUJILEdBQXJCLEVBQTBCQyxJQUExQjtBQUNELENBRkk7QUFJRSxJQUFNRyxXQUFXLEdBQUcsU0FBZEEsV0FBYyxDQUFDSixHQUFELEVBQWlCO0FBQzFDLE1BQU1LLElBQUksR0FBR0gsWUFBWSxDQUFDSSxPQUFiLENBQXFCTixHQUFyQixDQUFiOztBQUNBLE1BQUk7QUFDRixXQUFPdkIsSUFBSSxDQUFDOEIsS0FBTCxDQUFXRixJQUFYLENBQVA7QUFDRCxHQUZELENBRUUsT0FBT0csS0FBUCxFQUFjO0FBQ2QsV0FBT0gsSUFBUDtBQUNEO0FBQ0YsQ0FQTTtBQVNBLElBQU1JLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ1QsR0FBRCxFQUFpQjtBQUM3Q0UsY0FBWSxDQUFDUSxVQUFiLENBQXdCVixHQUF4QjtBQUNELENBRk07QUFJQSxJQUFNVyxpQkFBaUIsR0FBRyxTQUFwQkEsaUJBQW9CLEdBQU07QUFDckNULGNBQVksQ0FBQ1UsS0FBYjtBQUNELENBRk0iLCJmaWxlIjoic3RhdGljL2NodW5rcy8xLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0RWxlbWVudCwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQnV0dG9uLCBDb2wsIFJvdyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IF9zZXRTdG9yYWdlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2xvY2FsLXN0b3JhZ2VcIjtcclxuaW1wb3J0IHsgS0VZX1NUT1JBR0UgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzXCI7XHJcbmltcG9ydCB7IEdsb2JhbE91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmNvbnN0IHByaW1hcnlzID0gW1xyXG4gIHsgY29sb3JOYW1lOiBcIiM3ZjAwMDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiNiNzFjMWNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM4ODBlNGZcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM1NjAwMjdcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMzMTFiOTJcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMxYTIzN2VcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwZDQ3YTFcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDJmNmNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyNjMyMzhcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDRkNDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDM2M2FcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDYwNjRcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM0YTE0OGNcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMzODAwNmJcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyMTIxMjFcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDMzMDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMwMDNkMDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiM1MjRjMDBcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMxYzMxM2FcIiB9LFxyXG4gIHsgY29sb3JOYW1lOiBcIiMyOTQzNGVcIiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2V0dGluZyh7fTogUHJvcHMpOiBSZWFjdEVsZW1lbnQge1xyXG4gIGNvbnN0IHsgc3RhdGUsIGRpc3BhdGNoIH0gPSB1c2VDb250ZXh0KENvbnRleHQpO1xyXG4gIGNvbnN0IHNldFRoZW1lID0gKGNvbG9yKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5USEVNRSwgSlNPTi5zdHJpbmdpZnkoY29sb3IpKTtcclxuICAgIGNvbnNvbGUubG9nKFwiVGhlbWUgPT4gXCIsIGNvbG9yKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX1BSSU1BUllcIixcclxuICAgICAgcGF5bG9hZDoge1xyXG4gICAgICAgIHByaW1hcnk6IGNvbG9yLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICBjb25zdCBzZXRMYW5ndWFnZSA9IChsYW5nKSA9PiB7XHJcbiAgICBfc2V0U3RvcmFnZShLRVlfU1RPUkFHRS5MQU5HLCBKU09OLnN0cmluZ2lmeShsYW5nKSk7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9MQU5HVUFHRVwiLFxyXG4gICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgbGFuZ3VhZ2U6IGxhbmcsXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8VGV4dEhlYWRlciB0aGVtZT17c3RhdGUudGhlbWV9PlNFVFRJTkcgUFJJTUFSWTwvVGV4dEhlYWRlcj5cclxuICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBzdHlsZT17eyBwYWRkaW5nOiAxMCB9fT5cclxuICAgICAgICB7cHJpbWFyeXMubWFwKChyb3csIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8Q29sIGtleT17aW5kZXh9IHNwYW49ezN9PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiByb3cuY29sb3JOYW1lLFxyXG4gICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogcm93LmNvbG9yTmFtZSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaGVtZShyb3cuY29sb3JOYW1lKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7cm93LmNvbG9yTmFtZX1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L1Jvdz5cclxuICAgICAgPFRleHRIZWFkZXIgdGhlbWU9e3N0YXRlLnRoZW1lfT5TRVRUSU5HIExBTkdVQUdFPC9UZXh0SGVhZGVyPlxyXG4gICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IHN0eWxlPXt7IHBhZGRpbmc6IDEwIH19PlxyXG4gICAgICAgIDxDb2wgc3Bhbj17M30+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExhbmd1YWdlKFwiRU5cIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxHbG9iYWxPdXRsaW5lZFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiAyMH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIEVOR0xJU0hcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDxDb2wgc3Bhbj17M30+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldExhbmd1YWdlKFwiVEhcIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxHbG9iYWxPdXRsaW5lZFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiAyMH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIFRIQUlcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvQ29sPlxyXG4gICAgICA8L1Jvdz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IFRleHRIZWFkZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNTBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMzVweCAyMHB4ICM3Nzc7XHJcbiAgLW1vei1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIGJveC1zaGFkb3c6IDAgMi44cHggMi4ycHggcmdiKDAgMCAwIC8gMyUpLCAwIDYuN3B4IDUuM3B4IHJnYigwIDAgMCAvIDUlKSxcclxuICAgIDAgMTIuNXB4IDEwcHggcmdiKDAgMCAwIC8gNiUpLCAwIDM5LjNweCAxNy45cHggcmdiKDAgMCAwIC8gMCUpLFxyXG4gICAgMCA0MS44cHggMzMuNHB4IHJnYigwIDAgMCAvIDAlKSwgMCAxMDBweCA4MHB4IHJnYigwIDAgMCAvIDAlKTtcclxuYDtcclxuIiwiZXhwb3J0IGNvbnN0IF9zZXRTdG9yYWdlID0gKGtleTogc3RyaW5nLCBib2R5OiBzdHJpbmcpID0+IHtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgYm9keSk7XHJcbiAgfTtcclxuICBcclxuICBleHBvcnQgY29uc3QgX2dldFN0b3JhZ2UgPSAoa2V5OiBzdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGJvYnkgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgcmV0dXJuIEpTT04ucGFyc2UoYm9ieSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICByZXR1cm4gYm9ieTtcclxuICAgIH1cclxuICB9O1xyXG4gIFxyXG4gIGV4cG9ydCBjb25zdCBfZGVsZXRlU3RvcmFnZSA9IChrZXk6IHN0cmluZykgPT4ge1xyXG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KTtcclxuICB9O1xyXG4gIFxyXG4gIGV4cG9ydCBjb25zdCBfZGVsZXRlQWxsU3RvcmFnZSA9ICgpID0+IHtcclxuICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xyXG4gIH07XHJcbiAgIl0sInNvdXJjZVJvb3QiOiIifQ==