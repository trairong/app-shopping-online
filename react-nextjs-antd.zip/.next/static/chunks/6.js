(window["webpackJsonp_N_E"] = window["webpackJsonp_N_E"] || []).push([[6],{

/***/ "./src/components/pages/product.tsx":
/*!******************************************!*\
  !*** ./src/components/pages/product.tsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Product; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/esm/objectDestructuringEmpty */ "./node_modules/@babel/runtime/helpers/esm/objectDestructuringEmpty.js");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd */ "./node_modules/antd/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../context */ "./src/context/index.tsx");




var _jsxFileName = "D:\\template\\react\\react-nextjs-antd\\src\\components\\pages\\product.tsx",
    _s = $RefreshSig$(),
    _this = undefined,
    _s2 = $RefreshSig$();





function Product(_ref) {
  _s();

  Object(_babel_runtime_helpers_esm_objectDestructuringEmpty__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref);

  var _useContext = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext.state,
      dispatch = _useContext.dispatch;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Tabss, {
      defaultActiveKey: "1",
      centered: true,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E01\u0E35\u0E15\u0E49\u0E32\u0E23\u0E4C",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, this)
      }, "1", false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E40\u0E2A\u0E37\u0E49\u0E2D\u0E1C\u0E49\u0E32",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 11
        }, this)
      }, "2", false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanes, {
        theme: state.theme,
        tab: "\u0E2B\u0E21\u0E27\u0E14\u0E40\u0E21\u0E35\u0E22\u0E19\u0E49\u0E2D\u0E22",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabDetail, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, this)
      }, "3", false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

_s(Product, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c = Product;

var TabDetail = function TabDetail() {
  _s2();

  var _useContext2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useContext"])(_context__WEBPACK_IMPORTED_MODULE_5__["Context"]),
      state = _useContext2.state,
      dispatch = _useContext2.dispatch;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
      gutter: [8, 8],
      style: {
        padding: 16
      },
      children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18].map(function (item, index) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Col"], {
          span: 4,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Cards // title={'product'+item}
          , {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Image"], {
              src: "./images/product1.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 19
            }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                width: "100%",
                padding: 5
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Buys, {
                theme: state.theme,
                children: "2500.00"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 21
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Rate"], {
                allowHalf: true,
                defaultValue: 3,
                style: {
                  color: state.theme.primary
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 42,
                columnNumber: 21
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 19
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 36,
            columnNumber: 17
          }, _this)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 15
        }, _this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(antd__WEBPACK_IMPORTED_MODULE_2__["Row"], {
      style: {
        justifyContent: "center"
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Paginations, {
        theme: state.theme,
        defaultCurrent: 10,
        total: 50
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 7
    }, _this)]
  }, void 0, true);
};

_s2(TabDetail, "QMdo+h1+fLbTriZQ0QN6uukzyow=");

_c2 = TabDetail;
var Paginations = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Pagination"]).withConfig({
  displayName: "product__Paginations",
  componentId: "sc-1261jbi-0"
})([".ant-pagination-item-active{background-color:", "!important;border-radius:0 !important;font-weight:bold;}.ant-pagination-item{border-radius:0 !important;font-weight:bold;}.ant-pagination-item-link:after,.ant-pagination-jump-prev:after,.ant-pagination-jump-next:after{background-color:#0585e7 !important;border-radius:0 !important;border:1px solid #e7ebee !important;}.ant-pagination-item-link:first-child{border-radius:0 !important;color:#000;}.ant-pagination-item-active a{color:#fff !important;}"], function (_ref2) {
  var theme = _ref2.theme;
  return theme.primary;
});
_c3 = Paginations;
var TabPanes = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Tabs"].TabPane).withConfig({
  displayName: "product__TabPanes",
  componentId: "sc-1261jbi-1"
})(["height:calc(100vh - 143px);margin-top:-10px;overflow-y:auto;overflow-x:hidden;::-webkit-scrollbar{width:15px;height:15px;}::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 6px rgba(0,0,0,0.5);border-radius:0px;box-shadow:0px 0px 5px #000000;background-color:#ececec;}::-webkit-scrollbar-thumb{border-radius:0px;background-color:", ";}"], function (_ref3) {
  var theme = _ref3.theme;
  return theme.primary;
});
_c4 = TabPanes;
var Cards = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Card"]).withConfig({
  displayName: "product__Cards",
  componentId: "sc-1261jbi-2"
})([".ant-card-body{padding:5px;}-webkit-box-shadow:0 35px 20px #777;-moz-box-shadow:0 35px 20px #777;box-shadow:0 2.8px 2.2px rgb(0 0 0 / 3%),0 6.7px 5.3px rgb(0 0 0 / 5%),0 12.5px 10px rgb(0 0 0 / 6%),0 39.3px 17.9px rgb(0 0 0 / 0%),0 41.8px 33.4px rgb(0 0 0 / 0%),0 100px 80px rgb(0 0 0 / 0%);"]);
_c5 = Cards;
var Tabss = Object(styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(antd__WEBPACK_IMPORTED_MODULE_2__["Tabs"]).withConfig({
  displayName: "product__Tabss",
  componentId: "sc-1261jbi-3"
})([".ant-tabs-nav{}.ant-tabs-nav-wrap{padding:15px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;}"]);
_c6 = Tabss;
var Buys = styled_components__WEBPACK_IMPORTED_MODULE_4__["default"].div.withConfig({
  displayName: "product__Buys",
  componentId: "sc-1261jbi-4"
})(["position:absolute;top:0px;right:0;background-color:", ";color:#fff;padding:5px;-webkit-box-shadow:0 10px 6px -6px #777;-moz-box-shadow:0 10px 6px -6px #777;box-shadow:0 10px 6px -6px #777;"], function (_ref4) {
  var theme = _ref4.theme;
  return theme.primary;
});
_c7 = Buys;

var _c, _c2, _c3, _c4, _c5, _c6, _c7;

$RefreshReg$(_c, "Product");
$RefreshReg$(_c2, "TabDetail");
$RefreshReg$(_c3, "Paginations");
$RefreshReg$(_c4, "TabPanes");
$RefreshReg$(_c5, "Cards");
$RefreshReg$(_c6, "Tabss");
$RefreshReg$(_c7, "Buys");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvcGFnZXMvcHJvZHVjdC50c3giXSwibmFtZXMiOlsiUHJvZHVjdCIsInVzZUNvbnRleHQiLCJDb250ZXh0Iiwic3RhdGUiLCJkaXNwYXRjaCIsInRoZW1lIiwiVGFiRGV0YWlsIiwicGFkZGluZyIsIm1hcCIsIml0ZW0iLCJpbmRleCIsIndpZHRoIiwiY29sb3IiLCJwcmltYXJ5IiwianVzdGlmeUNvbnRlbnQiLCJQYWdpbmF0aW9ucyIsInN0eWxlZCIsIlBhZ2luYXRpb24iLCJUYWJQYW5lcyIsIlRhYnMiLCJUYWJQYW5lIiwiQ2FyZHMiLCJDYXJkIiwiVGFic3MiLCJCdXlzIiwiZGl2Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBSWUsU0FBU0EsT0FBVCxPQUEwQztBQUFBOztBQUFBOztBQUFBLG9CQUMzQkMsd0RBQVUsQ0FBQ0MsZ0RBQUQsQ0FEaUI7QUFBQSxNQUMvQ0MsS0FEK0MsZUFDL0NBLEtBRCtDO0FBQUEsTUFDeENDLFFBRHdDLGVBQ3hDQSxRQUR3Qzs7QUFFdkQsc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyxLQUFEO0FBQU8sc0JBQWdCLEVBQUMsR0FBeEI7QUFBNEIsY0FBUSxNQUFwQztBQUFBLDhCQUNFLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVELEtBQUssQ0FBQ0UsS0FBdkI7QUFBOEIsV0FBRyxFQUFDLG9FQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQW9ELEdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVGLEtBQUssQ0FBQ0UsS0FBdkI7QUFBOEIsV0FBRyxFQUFDLDBFQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQXFELEdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKRixlQU9FLHFFQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUVGLEtBQUssQ0FBQ0UsS0FBdkI7QUFBOEIsV0FBRyxFQUFDLDBFQUFsQztBQUFBLCtCQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFNBQXFELEdBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQWVEOztHQWpCdUJMLE87O0tBQUFBLE87O0FBbUJ4QixJQUFNTSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxHQUFNO0FBQUE7O0FBQUEscUJBQ01MLHdEQUFVLENBQUNDLGdEQUFELENBRGhCO0FBQUEsTUFDZEMsS0FEYyxnQkFDZEEsS0FEYztBQUFBLE1BQ1BDLFFBRE8sZ0JBQ1BBLFFBRE87O0FBRXRCLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxZQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixDQUFiO0FBQXFCLFdBQUssRUFBRTtBQUFFRyxlQUFPLEVBQUU7QUFBWCxPQUE1QjtBQUFBLGdCQUNHLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkIsRUFBc0IsQ0FBdEIsRUFBeUIsQ0FBekIsRUFBNEIsRUFBNUIsRUFBZ0MsRUFBaEMsRUFBb0MsRUFBcEMsRUFBd0MsRUFBeEMsRUFBNEMsRUFBNUMsRUFBZ0QsRUFBaEQsRUFBb0QsRUFBcEQsRUFBd0QsRUFBeEQsRUFBNEQsRUFBNUQsRUFBZ0VDLEdBQWhFLENBQ0MsVUFBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQ2YsNEJBQ0UscUVBQUMsd0NBQUQ7QUFBSyxjQUFJLEVBQUUsQ0FBWDtBQUFBLGlDQUNFLHFFQUFDLEtBQUQsQ0FDQTtBQURBO0FBQUEsb0NBR0UscUVBQUMsMENBQUQ7QUFBTyxpQkFBRyxFQUFDO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRixFQUd3QyxHQUh4QyxlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFQyxxQkFBSyxFQUFFLE1BQVQ7QUFBaUJKLHVCQUFPLEVBQUU7QUFBMUIsZUFBWjtBQUFBLHNDQUNFLHFFQUFDLElBQUQ7QUFBTSxxQkFBSyxFQUFFSixLQUFLLENBQUNFLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUUscUVBQUMseUNBQUQ7QUFDRSx5QkFBUyxNQURYO0FBRUUsNEJBQVksRUFBRSxDQUZoQjtBQUdFLHFCQUFLLEVBQUU7QUFBRU8sdUJBQUssRUFBRVQsS0FBSyxDQUFDRSxLQUFOLENBQVlRO0FBQXJCO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsV0FBbUJILEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREY7QUFpQkQsT0FuQkY7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUF3QkUscUVBQUMsd0NBQUQ7QUFBSyxXQUFLLEVBQUU7QUFBRUksc0JBQWMsRUFBRTtBQUFsQixPQUFaO0FBQUEsNkJBQ0UscUVBQUMsV0FBRDtBQUFhLGFBQUssRUFBRVgsS0FBSyxDQUFDRSxLQUExQjtBQUFpQyxzQkFBYyxFQUFFLEVBQWpEO0FBQXFELGFBQUssRUFBRTtBQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXhCRixlQTJCRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBM0JGLGVBNEJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE1QkY7QUFBQSxrQkFERjtBQWdDRCxDQWxDRDs7SUFBTUMsUzs7TUFBQUEsUztBQW1DTixJQUFNUyxXQUFXLEdBQUdDLGlFQUFNLENBQUNDLCtDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEsMGZBRU87QUFBQSxNQUFHWixLQUFILFNBQUdBLEtBQUg7QUFBQSxTQUFlQSxLQUFLLENBQUNRLE9BQXJCO0FBQUEsQ0FGUCxDQUFqQjtNQUFNRSxXO0FBMkJOLElBQU1HLFFBQVEsR0FBR0YsaUVBQU0sQ0FBQ0cseUNBQUksQ0FBQ0MsT0FBTixDQUFUO0FBQUE7QUFBQTtBQUFBLDRWQW1CVTtBQUFBLE1BQUdmLEtBQUgsU0FBR0EsS0FBSDtBQUFBLFNBQWVBLEtBQUssQ0FBQ1EsT0FBckI7QUFBQSxDQW5CVixDQUFkO01BQU1LLFE7QUFzQk4sSUFBTUcsS0FBSyxHQUFHTCxpRUFBTSxDQUFDTSx5Q0FBRCxDQUFUO0FBQUE7QUFBQTtBQUFBLDJTQUFYO01BQU1ELEs7QUFZTixJQUFNRSxLQUFLLEdBQUdQLGlFQUFNLENBQUNHLHlDQUFELENBQVQ7QUFBQTtBQUFBO0FBQUEscUtBQVg7TUFBTUksSztBQWdCTixJQUFNQyxJQUFJLEdBQUdSLHlEQUFNLENBQUNTLEdBQVY7QUFBQTtBQUFBO0FBQUEscU1BSVk7QUFBQSxNQUFHcEIsS0FBSCxTQUFHQSxLQUFIO0FBQUEsU0FBZUEsS0FBSyxDQUFDUSxPQUFyQjtBQUFBLENBSlosQ0FBVjtNQUFNVyxJIiwiZmlsZSI6InN0YXRpYy9jaHVua3MvNi5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENhcmQsIENvbCwgSW1hZ2UsIFBhZ2luYXRpb24sIFJhdGUsIFJvdywgVGFicyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBSZWFjdEVsZW1lbnQsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0XCI7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb2R1Y3Qoe306IFByb3BzKTogUmVhY3RFbGVtZW50IHtcclxuICBjb25zdCB7IHN0YXRlLCBkaXNwYXRjaCB9ID0gdXNlQ29udGV4dChDb250ZXh0KTtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFRhYnNzIGRlZmF1bHRBY3RpdmVLZXk9XCIxXCIgY2VudGVyZWQ+XHJcbiAgICAgICAgPFRhYlBhbmVzIHRoZW1lPXtzdGF0ZS50aGVtZX0gdGFiPVwi4Lir4Lih4Lin4LiU4LiB4Li14LiV4LmJ4Liy4Lij4LmMXCIga2V5PVwiMVwiPlxyXG4gICAgICAgICAgPFRhYkRldGFpbCAvPlxyXG4gICAgICAgIDwvVGFiUGFuZXM+XHJcbiAgICAgICAgPFRhYlBhbmVzIHRoZW1lPXtzdGF0ZS50aGVtZX0gdGFiPVwi4Lir4Lih4Lin4LiU4LmA4Liq4Li34LmJ4Lit4Lic4LmJ4LiyXCIga2V5PVwiMlwiPlxyXG4gICAgICAgICAgPFRhYkRldGFpbCAvPlxyXG4gICAgICAgIDwvVGFiUGFuZXM+XHJcbiAgICAgICAgPFRhYlBhbmVzIHRoZW1lPXtzdGF0ZS50aGVtZX0gdGFiPVwi4Lir4Lih4Lin4LiU4LmA4Lih4Li14Lii4LiZ4LmJ4Lit4LiiXCIga2V5PVwiM1wiPlxyXG4gICAgICAgICAgPFRhYkRldGFpbCAvPlxyXG4gICAgICAgIDwvVGFiUGFuZXM+XHJcbiAgICAgIDwvVGFic3M+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBUYWJEZXRhaWwgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBzdGF0ZSwgZGlzcGF0Y2ggfSA9IHVzZUNvbnRleHQoQ29udGV4dCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxSb3cgZ3V0dGVyPXtbOCwgOF19IHN0eWxlPXt7IHBhZGRpbmc6IDE2IH19PlxyXG4gICAgICAgIHtbMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTAsIDExLCAxMiwgMTMsIDE0LCAxNSwgMTYsIDE3LCAxOF0ubWFwKFxyXG4gICAgICAgICAgKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPENvbCBzcGFuPXs0fSBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgIDxDYXJkc1xyXG4gICAgICAgICAgICAgICAgLy8gdGl0bGU9eydwcm9kdWN0JytpdGVtfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiLi9pbWFnZXMvcHJvZHVjdDEucG5nXCIgLz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBwYWRkaW5nOiA1IH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXlzIHRoZW1lPXtzdGF0ZS50aGVtZX0+MjUwMC4wMDwvQnV5cz5cclxuICAgICAgICAgICAgICAgICAgICA8UmF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dIYWxmXHJcbiAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogc3RhdGUudGhlbWUucHJpbWFyeSB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9DYXJkcz5cclxuICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICApfVxyXG4gICAgICA8L1Jvdz5cclxuICAgICAgPFJvdyBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICA8UGFnaW5hdGlvbnMgdGhlbWU9e3N0YXRlLnRoZW1lfSBkZWZhdWx0Q3VycmVudD17MTB9IHRvdGFsPXs1MH0gLz5cclxuICAgICAgPC9Sb3c+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcbmNvbnN0IFBhZ2luYXRpb25zID0gc3R5bGVkKFBhZ2luYXRpb24pYFxyXG4gIC5hbnQtcGFnaW5hdGlvbi1pdGVtLWFjdGl2ZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9IWltcG9ydGFudDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxuICAuYW50LXBhZ2luYXRpb24taXRlbSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazphZnRlcixcclxuICAuYW50LXBhZ2luYXRpb24tanVtcC1wcmV2OmFmdGVyLFxyXG4gIC5hbnQtcGFnaW5hdGlvbi1qdW1wLW5leHQ6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzA1ODVlNyAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2U3ZWJlZSAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tbGluazpmaXJzdC1jaGlsZCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogIzAwMDtcclxuICB9XHJcbiAgLmFudC1wYWdpbmF0aW9uLWl0ZW0tYWN0aXZlIGEge1xyXG4gICAgY29sb3I6ICNmZmYgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG5gO1xyXG5jb25zdCBUYWJQYW5lcyA9IHN0eWxlZChUYWJzLlRhYlBhbmUpYFxyXG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDE0M3B4KTtcclxuICAvKiBwYWRkaW5nOiAxMHB4OyAqL1xyXG4gIG1hcmdpbi10b3A6IC0xMHB4O1xyXG4gIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gICAgd2lkdGg6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgfVxyXG4gIDo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggNXB4ICMwMDAwMDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWNlY2VjO1xyXG4gIH1cclxuXHJcbiAgOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIH1cclxuYDtcclxuY29uc3QgQ2FyZHMgPSBzdHlsZWQoQ2FyZClgXHJcbiAgLmFudC1jYXJkLWJvZHkge1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gIH1cclxuXHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDM1cHggMjBweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAzNXB4IDIwcHggIzc3NztcclxuXHJcbiAgYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgMCAxMi41cHggMTBweCByZ2IoMCAwIDAgLyA2JSksIDAgMzkuM3B4IDE3LjlweCByZ2IoMCAwIDAgLyAwJSksXHJcbiAgICAwIDQxLjhweCAzMy40cHggcmdiKDAgMCAwIC8gMCUpLCAwIDEwMHB4IDgwcHggcmdiKDAgMCAwIC8gMCUpO1xyXG5gO1xyXG5jb25zdCBUYWJzcyA9IHN0eWxlZChUYWJzKWBcclxuICAuYW50LXRhYnMtbmF2IHtcclxuICAgIC8qIHBhZGRpbmc6IDIwcHg7ICovXHJcbiAgfVxyXG4gIC5hbnQtdGFicy1uYXYtd3JhcCB7XHJcbiAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgLyogYm94LXNoYWRvdzogMHB4IDBweCA1cHggIzAwMDAwMDsgKi9cclxuXHJcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gICAgLW1vei1ib3gtc2hhZG93OiAwIDEwcHggNnB4IC02cHggIzc3NztcclxuICAgIGJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gICAgLyogYm94LXNoYWRvdzogMCAyLjhweCAyLjJweCByZ2IoMCAwIDAgLyAzJSksIDAgNi43cHggNS4zcHggcmdiKDAgMCAwIC8gNSUpLFxyXG4gICAgICAwIDEyLjVweCAxMHB4IHJnYigwIDAgMCAvIDYlKSwgMCAzOS4zcHggMTcuOXB4IHJnYigwIDAgMCAvIDAlKSxcclxuICAgICAgMCA0MS44cHggMzMuNHB4IHJnYigwIDAgMCAvIDAlKSwgMCAxMDBweCA4MHB4IHJnYigwIDAgMCAvIDAlKTsgKi9cclxuICB9XHJcbmA7XHJcbmNvbnN0IEJ1eXMgPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDBweDtcclxuICByaWdodDogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLnByaW1hcnl9O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHBhZGRpbmc6IDVweDtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMTBweCA2cHggLTZweCAjNzc3O1xyXG4gIC1tb3otYm94LXNoYWRvdzogMCAxMHB4IDZweCAtNnB4ICM3Nzc7XHJcbiAgYm94LXNoYWRvdzogMCAxMHB4IDZweCAtNnB4ICM3Nzc7XHJcbmA7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=