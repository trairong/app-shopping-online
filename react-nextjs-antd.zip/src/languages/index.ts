const langTH = {
  TITLE: ["ค้นหา", "Search"],
  RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"],
};

export const Language = (lang: string) => {
  let SetLanguage: any = {};
  let indexTH = 0;
  let indexEN = 1;

  const Language = {
    Home: ["หน้าแรก", "HOME"],
    ProductType: ["หมวดสินค้า", "PRODUCT TYPE"],
    ProductList: ["สินค้าที่เลือก", "PRODUCT LIST"],
    ProductHistory: ["สินค้าที่สั่งซื้อแล้ว", "PRODUCT HISTORY"],
    ProductShipping: ["สินค้ากำลังจัดส่ง", "PRODUCT SHIPPING"],
    Setting: ["ตั้งค้า", "SETTING"],
    Search: ["ค้นหา", "Search"],
    RecommendedProducts: ["สินค้าแนะนำ", "Recommended Products"],
  };
  const getTH = () => {
      SetLanguage.Home = Language.Home[indexTH];
      SetLanguage.ProductType = Language.ProductType[indexTH];
      SetLanguage.ProductList = Language.ProductList[indexTH];
      SetLanguage.ProductHistory = Language.ProductHistory[indexTH];
      SetLanguage.ProductShipping = Language.ProductShipping[indexTH];
      SetLanguage.Setting = Language.Setting[indexTH];
      SetLanguage.Search = Language.Search[indexTH];
      SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexTH];
    return SetLanguage;
  };
  const getEN = () => {
      SetLanguage.Home = Language.Home[indexEN];
      SetLanguage.ProductType = Language.ProductType[indexEN];
      SetLanguage.ProductList = Language.ProductList[indexEN];
      SetLanguage.ProductHistory = Language.ProductHistory[indexEN];
      SetLanguage.ProductShipping = Language.ProductShipping[indexEN];
      SetLanguage.Setting = Language.Setting[indexEN];
      SetLanguage.Search = Language.Search[indexEN];
      SetLanguage.RecommendedProducts = Language.RecommendedProducts[indexEN];
    return SetLanguage;
  };

  if (lang.toUpperCase() == "TH") {
    return getTH();
  }
  return getEN();
};
