import React, { ReactElement } from 'react'

interface Props {
    
}

export default function CFooter({}: Props): ReactElement {
    return (
        <div>
            Footers
        </div>
    )
}
