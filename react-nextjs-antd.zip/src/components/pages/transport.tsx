import React, { ReactElement } from "react";

interface Props {}

export default function Transport({}: Props): ReactElement {
  return <div>Transport</div>;
}
