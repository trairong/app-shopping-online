import React, { ReactElement } from 'react'

interface Props {
    
}

export default function History({}: Props): ReactElement {
    return (
        <div>
            History
        </div>
    )
}
