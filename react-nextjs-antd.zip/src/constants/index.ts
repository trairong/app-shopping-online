const NODE_ENV = process.env.NODE_ENV;

export const HOST = {
  URL: NODE_ENV.trim() === "development" ? "http://localhost:3000" : "",
  API: {
    AUTH: {
      GETPRODUCT: "/api/product",
    },
  },
};

export const ROUTE_MENU = {
  HOME: "pages/home",
  PRODUCT: "pages/product",
  LIST_PRODUCT: "pages/list-product",
  HISTORY: "pages/history",
  TRANSPORT: "pages/transport",
  SETTING: "pages/setting",
};

export const KEY_STORAGE = {
  THEME: "SET_THEME",
  LANG: "SET_LANGUAGE",
};
