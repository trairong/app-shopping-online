import React, { ReactElement } from 'react'

interface Props {
    
}

export default function Homes({}: Props): ReactElement {
    return (
        <div>
            Home
        </div>
    )
}
